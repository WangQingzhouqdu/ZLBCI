@echo off
setlocal
cd /d "%~dp0"
echo Install a native iPhone development build before using this launcher.
echo For a standalone Release app, Metro is not required.
if not exist "node_modules\expo\package.json" call npm.cmd ci
if errorlevel 1 goto failed
call npm.cmd start
pause
exit /b
:failed
echo Dependency installation failed. Check the error above.
pause
exit /b 1
