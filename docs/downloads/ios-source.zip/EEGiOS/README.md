# 脑电采集 · iOS 公开源码包

这是八通道 ESP32-S3 + ADS1299 BLE 客户端的精简源码，使用 React Native / Expo，面向 iPhone 与 iPad。提供实时波形、参数控制、Butterworth 滤波、CSV 本地记录与导出、合成信号演示。

**交付的是可构建源码，不包含已签名 IPA。** 原资料明确 iPhone 安装、真实 BLE 与 iOS 文件接口尚未实机验证。本次网页文档整理未重新运行应用构建与测试。

## Mac 真机构建

使用项目锁文件安装依赖。随附构建脚本提示 Node.js 24 LTS、Xcode 26.4 或兼容更新版本。完成 Xcode 首次运行、Command Line Tools 与 iOS SDK 安装；连接并信任 iPhone，按系统提示启用开发者模式，并配置自己的开发账号。

```bash
bash build-ios-on-mac.command
```

脚本依次执行 `npm ci`、类型检查、测试和 `npx expo run:ios --device --configuration Release`。Release 构建含运行代码，安装后不依赖 Metro。

若需在 Xcode 配置签名：

```bash
npx expo prebuild --platform ios
open ios/*.xcworkspace
```

在 Signing & Capabilities 中选择自己的 Team。若需要修改应用标识，先更改 `app.json` 中的 `ios.bundleIdentifier` 再重新生成工程。不要复制 Windows 的 node_modules；在 Mac 上重新运行 npm ci。

## Windows 演示与开发检查

`01-Preview-Demo.cmd` 打开网页演示。网页和 Expo Go 不包含本项目原生 BLE 模块，无法连接真实板卡；网页 CSV 暂存内存，刷新前请导出。

```bash
npm ci
npm run typecheck
npm run lint
npm test
npm run doctor
npm run export:ios
```

`export:ios` 只导出 JavaScript / Hermes 与资源，不生成可安装 IPA。`02-Start-iPhone-Dev.cmd` 用于已有开发构建的 Metro 调试；独立 Release App 不需要该服务。

## 采集与记录

设备页扫描并允许蓝牙权限；先从 250 SPS、24 倍增益验证链路。在波形页开始采集，收到有效数据后进入记录页选择并开始记录。硬件参数修改会暂停采集并结束当前记录，之后需重新启动。

iOS 采用前台采集，进入后台时停止并结束记录；返回前台需手动启动。首包等待阈值 5 秒，连续无有效包阈值 2 秒。采样率设置为 250/500/1000/2000/4000 SPS，实际吞吐需联调。

独立 App 保存到 Documents/EEG，可通过系统分享或“文件 → 我的 iPhone → 脑电采集 → EEG”导出。CSV time_s 为记录相对秒数，sample_index 为设备无符号 32 位序号，原始与滤波通道单位为 µV。卸载前应导出需要保留的文件。

## 公开包范围

只包含源码、资源、测试、依赖锁文件、构建与预览脚本。未包含 node_modules、原生生成工程、构建产物、验证日志、签名材料、凭据或采集记录。业务源码保持资料原样；此 README 为公开包重写。
