import React, { useEffect, useState, useSyncExternalStore } from 'react';
import {
  ActivityIndicator, Modal, Platform, Pressable, ScrollView, StyleSheet,
  Switch, Text, TextInput, View, useWindowDimensions,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import Svg, { Circle, Line, Path, Rect } from 'react-native-svg';
import { session } from './src/session/controller';
import { DEFAULT_HARDWARE, type HardwareSettings, type SessionSnapshot } from './src/session/types';
import { DEFAULT_FILTER, type FilterSettings } from './src/core/filter';
import type { RecordingMode } from './src/platform/recordings';

const C = {
  bg: '#09121C', panel: '#111E2B', inset: '#0C1824', line: '#243445',
  text: '#EAF2F6', muted: '#91A5B7', dim: '#60798E', mint: '#79E3B5',
  amber: '#F1BC71', red: '#FF8791',
};
const CH = ['#79E3B5', '#76C8FA', '#AAA6FF', '#E4A0DB', '#F3BB77', '#D3DE8C', '#FF9DAD', '#8EDBD7'];
type IconName = 'wave' | 'device' | 'settings' | 'file' | 'play' | 'pause' | 'record' | 'share' | 'chevron' | 'close';
type Tab = 'wave' | 'device' | 'settings' | 'file';
type Action = () => void | Promise<void>;
const act = (action: Action) => { Promise.resolve().then(action).catch(e => session.setError(e instanceof Error ? e.message : String(e))); };
const duration = (seconds: number) => {
  const s = Math.max(0, Math.floor(seconds || 0));
  return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map(x => String(x).padStart(2, '0')).join(':');
};
const count = (n: number) => Math.round(n || 0).toLocaleString();
const size = (n: number) => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1024).toFixed(1) + ' KB';

function Icon({ name, color = C.muted, size: dimension = 22 }: { name: IconName; color?: string; size?: number }) {
  const paths: Partial<Record<IconName, string>> = {
    wave: 'M2 12h4l3-8 5 16 3-8h5',
    device: 'M8 5l9 7-9 7V5zm4-3v20M5 8l12 12M5 16L17 4',
    settings: 'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6',
    file: 'M6 3h8l4 4v14H6V3zm8 0v5h4M9 12h6M9 16h6',
    play: 'M8 5l11 7-11 7V5z',
    pause: 'M8 5v14M16 5v14',
    share: 'M12 16V3m-4 4 4-4 4 4M5 13v8h14v-8',
    chevron: 'm8 5 7 7-7 7',
    close: 'm6 6 12 12M6 18 18 6',
  };
  return <Svg width={dimension} height={dimension} viewBox="0 0 24 24" fill="none">
    {name === 'record' ? <Circle cx={12} cy={12} r={7} fill={color} /> :
      <Path d={paths[name]} stroke={color} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" />}
  </Svg>;
}

function Button({ title, onPress, icon, kind = 'primary', disabled = false, loading = false }: {
  title: string; onPress: () => void; icon?: IconName; kind?: 'primary' | 'secondary' | 'danger'; disabled?: boolean; loading?: boolean;
}) {
  const color = kind === 'primary' ? '#08201B' : kind === 'danger' ? C.red : C.text;
  return <Pressable accessibilityRole="button" accessibilityLabel={title} disabled={disabled || loading}
    onPress={onPress} style={({ pressed }) => [s.button, kind === 'primary' ? s.primary : s.secondary,
      kind === 'danger' && { borderColor: '#663641' }, (disabled || loading) && s.disabled, pressed && { opacity: 0.7 }]}>
    {loading ? <ActivityIndicator color={color} size="small" /> : icon && <Icon name={icon} color={color} size={19} />}
    <Text style={[s.buttonText, { color }]}>{title}</Text>
  </Pressable>;
}

function Panel({ title, eyebrow, children, right }: { title?: string; eyebrow?: string; children: React.ReactNode; right?: React.ReactNode }) {
  return <View style={s.panel}>
    {(title || eyebrow) && <View style={s.panelHead}><View style={{ flex: 1 }}>
      {eyebrow && <Text style={s.eyebrow}>{eyebrow}</Text>}
      {title && <Text style={s.panelTitle}>{title}</Text>}
    </View>{right}</View>}
    {children}
  </View>;
}

function Chips<T extends string | number>({ value, options, onChange }: {
  value: T; options: { label: string; value: T }[]; onChange: (value: T) => void;
}) {
  return <View style={s.chips}>{options.map(option => <Pressable key={option.value}
    accessibilityRole="button" accessibilityState={{ selected: value === option.value }}
    onPress={() => onChange(option.value)} style={[s.chip, value === option.value && s.chipSelected]}>
    <Text style={[s.chipText, value === option.value && { color: C.mint }]}>{option.label}</Text>
  </Pressable>)}</View>;
}

function Select({ label, value, options, onChange }: {
  label: string; value: string | number; options: { label: string; value: string | number }[];
  onChange: (value: string | number) => void;
}) {
  const [open, setOpen] = useState(false);
  return <View style={s.field}>
    <Text style={s.fieldLabel}>{label}</Text>
    <Pressable accessibilityRole="button" accessibilityLabel={label + ' ' + (options.find(o => o.value === value)?.label ?? value)}
      onPress={() => setOpen(true)} style={s.select}>
      <Text style={s.selectText}>{options.find(o => o.value === value)?.label ?? value}</Text><Icon name="chevron" size={15} />
    </Pressable>
    <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
      <View style={s.modalBackdrop}>
        <Pressable accessibilityLabel="关闭选择" style={StyleSheet.absoluteFill} onPress={() => setOpen(false)} />
        <View style={s.modalCard}><Text style={s.panelTitle}>{label}</Text>
          <ScrollView>{options.map(option => <Pressable key={option.value} style={s.option}
            accessibilityRole="button" accessibilityState={{ selected: option.value === value }}
            onPress={() => { onChange(option.value); setOpen(false); }}>
            <Text style={[s.body, option.value === value && { color: C.mint }]}>{option.label}</Text>
            {option.value === value && <Text style={{ color: C.mint }}>✓</Text>}
          </Pressable>)}</ScrollView>
          <Button title="取消" kind="secondary" onPress={() => setOpen(false)} />
        </View>
      </View>
    </Modal>
  </View>;
}

function Toggle({ title, subtitle, value, onChange }: { title: string; subtitle?: string; value: boolean; onChange: (v: boolean) => void }) {
  return <View style={s.toggle}><View style={{ flex: 1 }}><Text style={s.body}>{title}</Text>
    {subtitle && <Text style={s.hint}>{subtitle}</Text>}</View>
    <Switch accessibilityLabel={title} value={value} onValueChange={onChange} trackColor={{ false: '#354658', true: '#3D9978' }} thumbColor={value ? C.mint : '#C2CED8'} />
  </View>;
}

function WaveRow({ channel, enabled, revision, filtered, range, leadOff, onToggle }: {
  channel: number; enabled: boolean; revision: number; filtered: boolean; range: number; leadOff: boolean; onToggle: () => void;
}) {
  const [width, setWidth] = useState(300);
  // revision intentionally invalidates the sampled trace when the session emits.
  void revision;
  const points = enabled ? session.plot(channel, filtered, Math.min(400, Math.max(80, Math.floor(width)))) : [];
  const finite = points.filter(p => Number.isFinite(p.y));
  const limit = range || Math.max(10, ...finite.map(p => Math.abs(p.y))) * 1.1;
  let drawing = false;
  let d = '';
  for (const point of points) {
    if (!Number.isFinite(point.y)) { drawing = false; continue; }
    const x = point.x * 1000;
    const y = 30 - Math.max(-1, Math.min(1, point.y / limit)) * 25;
    d += (drawing ? ' L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1);
    drawing = true;
  }
  return <View style={[s.waveRow, !enabled && { opacity: 0.35 }]}>
    <Pressable style={s.channelLabel} accessibilityRole="button" accessibilityLabel={'通道 ' + (channel + 1)}
      accessibilityState={{ selected: enabled }} onPress={onToggle}>
      <View style={[s.channelDot, { backgroundColor: leadOff ? C.red : CH[channel] }]} />
      <Text style={[s.channelText, { color: CH[channel] }]}>CH{channel + 1}</Text>
      {leadOff && <Text style={s.leadWarning}>脱落</Text>}
    </Pressable>
    <View style={s.trace} onLayout={e => setWidth(e.nativeEvent.layout.width)}>
      <Svg width="100%" height={60} viewBox="0 0 1000 60" preserveAspectRatio="none">
        <Rect width={1000} height={60} fill={C.inset} />
        {[0, 200, 400, 600, 800, 1000].map(x => <Line key={x} x1={x} y1={0} x2={x} y2={60} stroke="#1A2B3A" strokeWidth={1} />)}
        <Line x1={0} y1={30} x2={1000} y2={30} stroke="#233443" strokeWidth={1} />
        {d && <Path d={d} fill="none" stroke={CH[channel]} strokeWidth={1.35} vectorEffect="non-scaling-stroke" />}
      </Svg>
      {finite.length === 0 && channel === 3 && <Text style={s.traceEmpty}>{enabled ? '等待采集信号' : '通道已隐藏'}</Text>}
    </View>
  </View>;
}

function Metrics({ data }: { data: SessionSnapshot }) {
  return <View style={s.metrics}>
    {[{ label: '实际样本率', value: count(data.stats.sampleRate), unit: 'SPS' },
      { label: '接收时长', value: duration(data.stats.elapsed), unit: '' },
      { label: '丢失样本', value: count(data.stats.lostSamples), unit: '' }].map(item =>
      <View key={item.label} style={s.metric}><Text style={s.metricLabel}>{item.label}</Text>
        <Text style={s.metricValue}>{item.value}<Text style={s.metricUnit}> {item.unit}</Text></Text>
      </View>)}
  </View>;
}

function WaveScreen({ data, setTab }: { data: SessionSnapshot; setTab: (tab: Tab) => void }) {
  const [filtered, setFiltered] = useState(true);
  const [range, setRange] = useState(100);
  const [visible, setVisible] = useState(Array<boolean>(8).fill(true));
  return <View style={s.stack}>
    <View style={s.sectionTitle}><View><Text style={s.eyebrow}>LIVE MONITOR</Text><Text style={s.pageTitle}>实时信号</Text></View>
      <View style={s.statePill}><View style={[s.statusDot, { backgroundColor: data.streaming ? C.mint : C.dim }]} />
        <Text style={s.badgeText}>{data.starting ? '等待首包' : data.streaming ? '正在采集' : data.connection === 'connected' ? '已暂停' : '待连接'}</Text></View>
    </View>
    <Metrics data={data} />
    <View style={s.actionRow}>
      <View style={{ flex: 1 }}><Button title={data.streaming || data.starting ? '暂停采集' : '开始采集'}
        icon={data.streaming ? 'pause' : 'play'} disabled={data.connection !== 'connected' || data.busy}
        onPress={() => act(() => data.streaming || data.starting ? session.pause() : session.start())} /></View>
      <View style={{ flex: 1 }}><Button title={data.recording ? '保存记录' : '记录数据'} kind={data.recording ? 'danger' : 'secondary'}
        icon={data.recording ? 'pause' : 'record'} disabled={!data.recording && (!data.streaming || data.starting)}
        onPress={() => data.recording ? act(() => session.stopRecording()) : setTab('file')} /></View>
    </View>
    {data.connection !== 'connected' && <View style={s.connectPrompt}>
      <Text style={s.hint}>连接采集板，或先用模拟信号体验完整流程。</Text>
      <View style={s.actionRow}><Button title="连接设备" kind="secondary" icon="device" onPress={() => setTab('device')} />
        <Button title="体验演示" kind="secondary" icon="wave" onPress={() => act(async () => { await session.useDemo(); await session.start(); })} /></View>
    </View>}
    <View style={s.wavePanel}>
      <View style={s.waveToolbar}><Text style={s.panelTitle}>8 通道波形</Text><Text style={s.hint}>μV · {data.actualFs || '—'} SPS</Text></View>
      <View style={s.waveControls}>
        <Chips value={filtered ? 'filt' : 'raw'} onChange={v => setFiltered(v === 'filt')}
          options={[{ label: '滤波', value: 'filt' }, { label: '原始', value: 'raw' }]} />
        <Select label="时间窗" value={data.windowSeconds} onChange={v => session.setWindow(Number(v))}
          options={[1, 2, 5, 10, 20].map(v => ({ label: v + ' 秒', value: v }))} />
        <Select label="幅度" value={range} onChange={v => setRange(Number(v))}
          options={[0, 10, 25, 50, 100, 250, 500, 1000, 5000].map(v => ({ label: v ? '±' + v + ' μV' : '自动', value: v }))} />
      </View>
      {visible.map((enabled, i) => <WaveRow key={i} channel={i} enabled={enabled} filtered={filtered} range={range}
        revision={data.revision} leadOff={data.hardware.leadOff && !!((data.leadOffP | data.leadOffN) & (1 << i))}
        onToggle={() => setVisible(v => v.map((b, index) => index === i ? !b : b))} />)}
      <View style={s.timeAxis}><Text style={s.small}>−{data.windowSeconds}s</Text><Text style={s.small}>−{data.windowSeconds / 2}s</Text><Text style={s.small}>现在</Text></View>
      <View style={s.waveFooter}><View style={[s.statusDot, { backgroundColor: C.mint }]} />
        <Text style={[s.hint, { flex: 1 }]}>{filtered ? data.filterDescription : '原始信号 · 未滤波'}{data.mode === 'demo' ? ' · 模拟数据' : ''}</Text>
      </View>
    </View>
    <View style={s.telemetry}>
      <Text style={s.small}>{count(data.stats.packetRate)} 包/s</Text>
      <Text style={s.small}>{(data.stats.bytesPerSecond / 1024).toFixed(1)} KB/s</Text>
      <Text style={[s.small, data.stats.invalidPackets > 0 && { color: C.amber }]}>误码 {count(data.stats.invalidPackets)}</Text>
      <Text style={[s.small, data.stats.overflowPackets > 0 && { color: C.amber }]}>溢出 {count(data.stats.overflowPackets)}</Text>
    </View>
    <Text style={s.hint}>点 CH 标签隐藏通道。缺失样本留白；显示降采样不影响 CSV 的完整记录。</Text>
  </View>;
}

function DeviceScreen({ data }: { data: SessionSnapshot }) {
  const [onlyEeg, setOnlyEeg] = useState(true);
  return <View style={s.stack}>
    <View><Text style={s.eyebrow}>CONNECTION</Text><Text style={s.pageTitle}>设备连接</Text></View>
    <Panel title={data.device?.name ?? '尚未连接采集设备'} eyebrow="ESP32-S3 + ADS1299"
      right={<Icon name="device" color={C.mint} size={28} />}>
      <Text selectable style={s.hint}>{data.device?.id ?? '通过低功耗蓝牙直接接收八通道信号'}</Text>
      {data.connection === 'connected' && <View style={s.stack}>
        <View style={s.infoRow}><Text style={s.hint}>当前连接</Text><Text style={s.body}>{data.mode === 'demo' ? '模拟设备' : '蓝牙设备'}</Text></View>
        <View style={s.infoRow}><Text style={s.hint}>包头采样率 / 增益</Text><Text style={s.body}>{data.actualFs || '—'} SPS / ×{data.actualGain || '—'}</Text></View>
        {data.deviceStatus.mtu != null && <View style={s.infoRow}><Text style={s.hint}>MTU / 固件</Text><Text style={s.body}>{String(data.deviceStatus.mtu)} / {String(data.deviceStatus.fw ?? '—')}</Text></View>}
        <Button title="断开连接" kind="danger" disabled={data.busy} onPress={() => act(() => session.disconnect())} />
      </View>}
    </Panel>
    <Panel title="附近的采集设备">
      <Toggle title="只显示 EEG 设备" subtitle="匹配设备名称或采集服务 UUID" value={onlyEeg} onChange={setOnlyEeg} />
      <Button title={data.scanning ? '正在扫描…' : '扫描蓝牙设备'} icon="device" loading={data.scanning}
        disabled={data.busy || data.connection === 'connected'} onPress={() => act(() => session.scan(onlyEeg))} />
      {data.devices.length === 0 && <Text style={s.emptyText}>让采集板靠近 iPhone 并保持开机。若已连接电脑，请先断开电脑端。</Text>}
      {data.devices.map(device => <Pressable key={device.id} style={s.deviceRow} accessibilityRole="button"
        disabled={data.busy || data.connection !== 'disconnected'} onPress={() => act(() => session.connect(device))}>
        <View style={s.deviceIcon}><Icon name="device" color={C.mint} /></View>
        <View style={{ flex: 1 }}><Text style={s.body}>{device.name}</Text><Text numberOfLines={1} style={s.small}>{device.id}</Text></View>
        <Text style={s.hint}>{device.rssi} dBm</Text><Icon name="chevron" size={16} />
      </Pressable>)}
      <Text style={s.hint}>真实蓝牙采集需在 iPhone 上安装独立 App。浏览器和 Expo Go 提供模拟演示。</Text>
    </Panel>
    <Panel title="无硬件演示" eyebrow="DEMO MODE">
      <Text style={s.hint}>生成合成的八通道脑电信号，体验波形、滤波与 CSV 记录。所有演示文件都带有模拟标记。</Text>
      <Button title="连接模拟设备" kind="secondary" icon="wave" disabled={data.busy}
        onPress={() => act(() => session.useDemo())} />
    </Panel>
    <Panel title="连接日志" right={<Text style={s.small}>最近 {Math.min(data.logs.length, 8)} 条</Text>}>
      {data.logs.length === 0 && <Text style={s.hint}>连接与采集事件将显示在这里。</Text>}
      {data.logs.slice(-8).reverse().map((log, i) => <View key={i} style={s.logRow}>
        <Text style={s.logTime}>{log.time}</Text><Text style={[s.hint, { flex: 1 }]}>{log.message}</Text>
      </View>)}
    </Panel>
  </View>;
}

function SettingsScreen({ data }: { data: SessionSnapshot }) {
  const [hardware, setHardware] = useState<HardwareSettings>(() => ({ ...data.hardware }));
  const [filter, setFilter] = useState<FilterSettings>(() => ({ ...data.filter }));
  const [hp, setHp] = useState(String(data.filter.highPass));
  const [lp, setLp] = useState(String(data.filter.lowPass));
  const [q, setQ] = useState(String(data.filter.notchQ));
  const hardwareField = <K extends keyof HardwareSettings>(key: K, value: HardwareSettings[K]) => setHardware(v => ({ ...v, [key]: value }));
  const restore = () => {
    setHardware({ ...DEFAULT_HARDWARE }); setFilter({ ...DEFAULT_FILTER });
    setHp(String(DEFAULT_FILTER.highPass)); setLp(String(DEFAULT_FILTER.lowPass)); setQ(String(DEFAULT_FILTER.notchQ));
  };
  return <View style={s.stack}>
    <View style={s.sectionTitle}><View><Text style={s.eyebrow}>ACQUISITION</Text><Text style={s.pageTitle}>采集与滤波</Text></View>
      <Pressable accessibilityRole="button" onPress={restore}><Text style={s.link}>恢复默认草稿</Text></Pressable></View>
    <Panel title="采集板参数" eyebrow="HARDWARE">
      <View style={s.formRow}><Select label="采样率" value={hardware.sampleRate}
        options={[250, 500, 1000, 2000, 4000].map(v => ({ label: v + ' SPS', value: v }))}
        onChange={v => hardwareField('sampleRate', Number(v))} />
        <Select label="增益" value={hardware.gain} options={[1, 2, 4, 6, 8, 12, 24].map(v => ({ label: '×' + v, value: v }))}
          onChange={v => hardwareField('gain', Number(v))} /></View>
      <Select label="输入模式" value={hardware.mode} onChange={v => hardwareField('mode', v as HardwareSettings['mode'])}
        options={[{ label: '正常电极输入', value: 'NORMAL' }, { label: '输入短路 · 本底噪声', value: 'SHORT' },
          { label: '内部方波测试', value: 'TEST' }, { label: '电源电压 MVDD', value: 'MVDD' }, { label: '芯片温度 TEMP', value: 'TEMP' }]} />
      <Toggle title="SRB1 共模参考" value={hardware.srb1} onChange={v => hardwareField('srb1', v)} />
      <Toggle title="BIAS 偏置驱动" value={hardware.bias} onChange={v => hardwareField('bias', v)} />
      <Toggle title="导联脱落检测" value={hardware.leadOff} onChange={v => hardwareField('leadOff', v)} />
      <Text style={s.hint}>应用参数会暂停采集并保存当前记录。建议先用 250 SPS 完成设备联调。</Text>
      <Button title="应用采集参数" disabled={data.connection !== 'connected' || data.busy}
        onPress={() => act(() => session.applyHardware(hardware))} />
    </Panel>
    <Panel title="实时数字滤波" eyebrow="SIGNAL PROCESSING">
      <Toggle title="启用滤波" subtitle="原始数据始终保留，显示可随时切换" value={filter.enabled} onChange={enabled => setFilter(f => ({ ...f, enabled }))} />
      <View style={s.formRow}>{[{ label: '高通 Hz', value: hp, setter: setHp }, { label: '低通 Hz', value: lp, setter: setLp }].map(field =>
        <View style={s.field} key={field.label}><Text style={s.fieldLabel}>{field.label}</Text>
          <TextInput accessibilityLabel={field.label} style={s.textInput} value={field.value} onChangeText={field.setter}
            keyboardType="decimal-pad" selectTextOnFocus /></View>)}</View>
      <View style={s.formRow}><Select label="Butterworth 阶数" value={filter.order}
        options={[2, 4, 6, 8].map(v => ({ label: v + ' 阶', value: v }))} onChange={v => setFilter(f => ({ ...f, order: Number(v) }))} />
        <Select label="工频陷波" value={filter.notchHz} options={[{ label: '关闭', value: 0 }, { label: '50 Hz', value: 50 }, { label: '60 Hz', value: 60 }]}
          onChange={v => setFilter(f => ({ ...f, notchHz: Number(v) }))} /></View>
      <View style={s.formRow}><Select label="陷波谐波数" value={filter.harmonics}
        options={[1, 2, 3, 4, 5].map(v => ({ label: String(v), value: v }))} onChange={v => setFilter(f => ({ ...f, harmonics: Number(v) }))} />
        <View style={s.field}><Text style={s.fieldLabel}>陷波 Q</Text><TextInput accessibilityLabel="陷波 Q" style={s.textInput}
          value={q} onChangeText={setQ} keyboardType="decimal-pad" selectTextOnFocus /></View></View>
      <Text style={s.hint}>高通或低通设为 0 表示关闭该项。应用滤波设置会保存当前记录并重置滤波状态。</Text>
      <Button title="应用滤波设置" kind="secondary" disabled={data.busy}
        onPress={() => act(() => session.applyFilter({ ...filter, highPass: Number(hp), lowPass: Number(lp), notchQ: Number(q) }))} />
      <Text style={[s.hint, { color: C.mint }]}>当前：{data.filterDescription}</Text>
    </Panel>
    <Panel title="设备报告">
      <Text style={s.hint}>参数写入与设备实际状态分别显示。收到的数据包以包头采样率和增益换算微伏。</Text>
      {Object.keys(data.deviceStatus).length === 0 ? <Text style={s.small}>尚未收到状态通知</Text> :
        <Text selectable style={s.code}>{JSON.stringify(data.deviceStatus, null, 2)}</Text>}
    </Panel>
  </View>;
}

function RecordsScreen({ data }: { data: SessionSnapshot }) {
  const [mode, setMode] = useState<RecordingMode>('both');
  return <View style={s.stack}>
    <View><Text style={s.eyebrow}>LOCAL RECORDINGS</Text><Text style={s.pageTitle}>数据记录</Text></View>
    <Panel title={data.recording ? '正在记录' : '新建记录'} right={<Icon name="record" color={data.recording ? C.red : C.dim} />}>
      <Chips value={mode} onChange={setMode} options={[{ label: '原始 + 滤波', value: 'both' }, { label: '仅原始', value: 'raw' }, { label: '仅滤波', value: 'filt' }]} />
      <View style={s.recordCounter}><Text style={s.largeNumber}>{count(data.recordedSamples)}</Text><Text style={s.hint}>已记录样本 / 通道</Text></View>
      <Text style={s.hint}>{data.mode === 'demo' ? '模拟信号 · 文件将标记 demo=true' : '采集板信号 · 全部收到的有效样本'}{data.recording ? ' · 记录格式在下一次记录时生效' : ''}</Text>
      <Button title={data.recording ? '停止记录并保存' : '开始记录'} icon={data.recording ? 'pause' : 'record'}
        kind={data.recording ? 'danger' : 'primary'} disabled={!data.recording && (!data.streaming || data.starting)}
        onPress={() => act(() => data.recording ? session.stopRecording() : session.startRecording(mode))} />
      {!data.streaming && <Text style={s.hint}>先在“波形”页开始采集，再开启记录。</Text>}
    </Panel>
    <Panel title="已保存文件" right={<Pressable accessibilityRole="button" onPress={() => act(() => session.refreshRecordings())}><Text style={s.link}>刷新</Text></Pressable>}>
      {data.recordings.length === 0 && <View style={s.emptyRecord}><Icon name="file" size={36} color={C.dim} />
        <Text style={s.body}>还没有记录</Text><Text style={s.hint}>保存的 CSV 会出现在这里</Text></View>}
      {data.recordings.map(file => <View key={file.id} style={s.recordRow}>
        <View style={s.recordFileHead}><Icon name="file" color={C.mint} /><View style={{ flex: 1 }}>
          <Text style={s.fileName} numberOfLines={2}>{file.name}</Text><Text style={s.small}>{new Date(file.createdAt).toLocaleString()}</Text></View>
          {file.demo && <Text style={s.demoSmall}>模拟</Text>}</View>
        <View style={s.infoRow}><Text style={s.hint}>{count(file.samples)} 样本 · {size(file.bytes)}</Text>
          <Pressable accessibilityRole="button" accessibilityLabel={'导出 ' + file.name} disabled={data.recording}
            style={s.shareButton} onPress={() => act(() => session.share(file))}>
            <Icon name="share" size={17} color={C.mint} /><Text style={s.link}>导出 CSV</Text></Pressable></View>
      </View>)}
    </Panel>
    <Text style={s.hint}>{Platform.OS === 'web'
      ? '网页演示记录暂存在内存，刷新前请导出。iPhone 独立 App 将记录保存到本机“文件”。'
      : 'CSV 保存在本机，可从“文件 → 我的 iPhone → 脑电采集 → EEG”查看，也可通过系统分享导出。数据不会自动上传。'}</Text>
    <Text style={s.hint}>时间列从本次记录的首个样本起计，单位秒；通道单位 μV。丢样留下时间间隔，不补造数据。暂停、断开、重配或进入后台时自动结束记录。</Text>
  </View>;
}

function Shell() {
  const data = useSyncExternalStore(session.subscribe, session.getSnapshot, session.getSnapshot);
  const [tab, setTab] = useState<Tab>('wave');
  const { width } = useWindowDimensions();
  // The singleton follows the JS runtime; AppState handles foreground suspension.
  // Disposing on effect replay would invalidate it during Fast Refresh/StrictMode.
  useEffect(() => { session.init(); }, []);
  const tabs: { id: Tab; label: string }[] = [{ id: 'wave', label: '波形' }, { id: 'device', label: '设备' }, { id: 'settings', label: '参数' }, { id: 'file', label: '记录' }];
  return <SafeAreaView style={s.safe} edges={['top', 'left', 'right', 'bottom']}>
    <StatusBar style="light" />
    <View style={[s.app, width > 800 && s.wideApp]}>
      <View style={s.header}><View style={s.brandMark}><Icon name="wave" color={C.mint} size={26} /></View>
        <View style={{ flex: 1 }}><Text style={s.brandTitle}>脑电采集</Text><Text style={s.brandSub}>EEG MOBILE / 8 CHANNELS</Text></View>
        {data.mode === 'demo' ? <View style={s.demoBadge}><Text style={s.demoText}>模拟数据</Text></View> :
          <View style={s.connectionBadge}><View style={[s.statusDot, { backgroundColor: data.connection === 'connected' ? C.mint : C.dim }]} />
            <Text style={s.small}>{data.connection === 'connected' ? '已连接' : data.connection === 'connecting' ? '连接中' : '未连接'}</Text></View>}
      </View>
      {data.error && <View style={s.errorBanner}><Text style={s.errorText}>{data.error}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel="关闭提示" onPress={() => session.setError(null)}><Icon name="close" color={C.red} size={20} /></Pressable></View>}
      <ScrollView key={tab} style={s.scroll} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
        {tab === 'wave' && <WaveScreen data={data} setTab={setTab} />}
        {tab === 'device' && <DeviceScreen data={data} />}
        {tab === 'settings' && <SettingsScreen data={data} />}
        {tab === 'file' && <RecordsScreen data={data} />}
        <Text style={s.pageFoot}>ESP32-S3 · ADS1299 · {data.mode === 'demo' ? 'DEMO' : 'BLUETOOTH LE'}</Text>
      </ScrollView>
      <View style={s.tabBar}>{tabs.map(item => <Pressable key={item.id} accessibilityRole="button" accessibilityLabel={item.label + '页面'}
        accessibilityState={{ selected: tab === item.id }} onPress={() => setTab(item.id)} style={s.tab}>
        <View style={[s.tabIcon, tab === item.id && { backgroundColor: '#17362F' }]}><Icon name={item.id} color={tab === item.id ? C.mint : C.dim} size={21} /></View>
        <Text style={[s.tabText, tab === item.id && { color: C.mint }]}>{item.label}{item.id === 'file' && data.recording ? ' ·' : ''}</Text>
      </Pressable>)}</View>
    </View>
  </SafeAreaView>;
}

export default function App() { return <SafeAreaProvider><Shell /></SafeAreaProvider>; }

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg }, app: { flex: 1, width: '100%', maxWidth: 740, alignSelf: 'center' },
  wideApp: { borderLeftWidth: 1, borderRightWidth: 1, borderColor: C.line },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 22, paddingVertical: 18, borderBottomWidth: 1, borderColor: '#192A39' },
  brandMark: { width: 43, height: 43, borderRadius: 13, backgroundColor: '#16352E', alignItems: 'center', justifyContent: 'center' },
  brandTitle: { color: C.text, fontSize: 18, fontWeight: '700', letterSpacing: 1 }, brandSub: { color: C.dim, fontSize: 9, letterSpacing: 1.6, marginTop: 5 },
  connectionBadge: { flexDirection: 'row', alignItems: 'center', gap: 7 }, statusDot: { width: 6, height: 6, borderRadius: 3 },
  demoBadge: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, backgroundColor: '#3B3022' },
  demoText: { fontSize: 11, fontWeight: '600', color: C.amber }, demoSmall: { fontSize: 10, color: C.amber },
  scroll: { flex: 1 }, content: { padding: 20, paddingBottom: 28 }, stack: { gap: 18 },
  sectionTitle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  eyebrow: { fontSize: 10, fontWeight: '600', letterSpacing: 1.8, color: C.dim, marginBottom: 7 },
  pageTitle: { fontSize: 28, color: C.text, fontWeight: '700', letterSpacing: 1 },
  statePill: { paddingVertical: 7, paddingHorizontal: 10, gap: 7, borderRadius: 20, backgroundColor: '#15232E', flexDirection: 'row', alignItems: 'center' },
  badgeText: { color: C.muted, fontSize: 11 },
  metrics: { flexDirection: 'row', paddingVertical: 17, borderRadius: 15, backgroundColor: C.panel, borderWidth: 1, borderColor: '#1D2D3C' },
  metric: { flex: 1, paddingHorizontal: 12 }, metricLabel: { color: C.muted, fontSize: 10, marginBottom: 9 },
  metricValue: { color: C.text, fontSize: 19, fontWeight: '600', fontVariant: ['tabular-nums'] }, metricUnit: { color: C.dim, fontSize: 9 },
  actionRow: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' }, button: { minHeight: 47, borderRadius: 11, paddingHorizontal: 15, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1 },
  primary: { backgroundColor: C.mint, borderColor: C.mint }, secondary: { backgroundColor: '#172737', borderColor: '#2B3F50' },
  buttonText: { fontSize: 13, fontWeight: '700' }, disabled: { opacity: 0.4 }, connectPrompt: { gap: 12, padding: 15, backgroundColor: '#111F2C', borderRadius: 12 },
  panel: { padding: 18, borderRadius: 16, backgroundColor: C.panel, borderWidth: 1, borderColor: '#203140', gap: 15 },
  panelHead: { flexDirection: 'row', alignItems: 'center', gap: 12 }, panelTitle: { color: C.text, fontSize: 16, fontWeight: '600' },
  body: { color: C.text, fontSize: 13, lineHeight: 21 }, hint: { color: C.muted, fontSize: 11, lineHeight: 18 },
  small: { color: C.dim, fontSize: 10, lineHeight: 16 }, link: { color: C.mint, fontSize: 12, fontWeight: '600' },
  chips: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' }, chip: { paddingHorizontal: 13, paddingVertical: 8, backgroundColor: '#0C1824', borderRadius: 8, borderWidth: 1, borderColor: '#213546' },
  chipSelected: { backgroundColor: '#1B3C32', borderColor: '#376550' }, chipText: { color: C.muted, fontSize: 12 },
  field: { flex: 1, gap: 7, minWidth: 80 }, fieldLabel: { color: C.muted, fontSize: 11 },
  select: { minHeight: 43, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 9, borderWidth: 1, borderColor: '#2B4052', backgroundColor: C.inset, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 5 },
  selectText: { fontSize: 12, color: C.text, flexShrink: 1 }, formRow: { flexDirection: 'row', gap: 12 },
  textInput: { minHeight: 44, borderRadius: 9, borderWidth: 1, borderColor: '#2B4052', backgroundColor: C.inset, color: C.text, fontSize: 15, padding: 12 },
  toggle: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 5 },
  wavePanel: { borderWidth: 1, borderColor: C.line, backgroundColor: C.inset, borderRadius: 15, overflow: 'hidden' },
  waveToolbar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 15 },
  waveControls: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 12, paddingBottom: 14 },
  waveRow: { flexDirection: 'row', height: 60, alignItems: 'center' }, channelLabel: { width: 44, alignItems: 'center', gap: 4 },
  channelDot: { height: 3, width: 13, borderRadius: 2 }, channelText: { fontSize: 9, fontWeight: '600' }, leadWarning: { color: C.red, fontSize: 8 },
  trace: { flex: 1 }, traceEmpty: { position: 'absolute', top: 21, alignSelf: 'center', fontSize: 11, color: C.dim, backgroundColor: C.inset, paddingHorizontal: 8 },
  timeAxis: { flexDirection: 'row', justifyContent: 'space-between', marginLeft: 44, paddingHorizontal: 5, paddingVertical: 8 },
  waveFooter: { flexDirection: 'row', alignItems: 'center', gap: 8, borderTopWidth: 1, borderColor: '#1E3040', padding: 12 },
  telemetry: { flexDirection: 'row', justifyContent: 'space-between', gap: 5, flexWrap: 'wrap' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, alignItems: 'center' },
  deviceRow: { flexDirection: 'row', gap: 10, alignItems: 'center', paddingVertical: 13, borderTopWidth: 1, borderColor: C.line },
  deviceIcon: { width: 38, height: 42, alignItems: 'center', justifyContent: 'center', borderRadius: 10, backgroundColor: '#18372F' },
  emptyText: { color: C.dim, fontSize: 12, lineHeight: 21, paddingVertical: 20, textAlign: 'center' },
  logRow: { flexDirection: 'row', gap: 12 }, logTime: { color: C.dim, fontSize: 10, lineHeight: 18, width: 59 },
  code: { color: C.muted, fontSize: 11, lineHeight: 18, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  recordCounter: { alignItems: 'center', paddingVertical: 20, gap: 8 }, largeNumber: { color: C.text, fontSize: 43, fontWeight: '300', fontVariant: ['tabular-nums'] },
  emptyRecord: { paddingVertical: 28, gap: 12, alignItems: 'center' }, recordRow: { gap: 14, paddingVertical: 15, borderTopWidth: 1, borderColor: C.line },
  recordFileHead: { flexDirection: 'row', alignItems: 'center', gap: 10 }, fileName: { color: C.text, fontSize: 12, lineHeight: 18, marginBottom: 4 },
  shareButton: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 5 },
  pageFoot: { color: '#456076', fontSize: 9, textAlign: 'center', letterSpacing: 1.4, marginTop: 30 },
  tabBar: { flexDirection: 'row', backgroundColor: '#0D1925', borderTopWidth: 1, borderColor: '#243445', paddingVertical: 9 },
  tab: { flex: 1, alignItems: 'center', gap: 5 }, tabIcon: { width: 48, height: 30, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  tabText: { fontSize: 10, color: C.dim }, errorBanner: { margin: 14, marginBottom: 0, padding: 13, borderRadius: 10, backgroundColor: '#40282D', flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  errorText: { color: '#FFC2C6', fontSize: 12, lineHeight: 20, flex: 1 },
  modalBackdrop: { flex: 1, backgroundColor: '#00000099', justifyContent: 'center', alignItems: 'center', padding: 26 },
  modalCard: { maxHeight: '80%', width: '100%', maxWidth: 430, borderRadius: 18, backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, padding: 22, gap: 16 },
  option: { paddingVertical: 16, borderBottomWidth: 1, borderColor: C.line, flexDirection: 'row', justifyContent: 'space-between' },
});
