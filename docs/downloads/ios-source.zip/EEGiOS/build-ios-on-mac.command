#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(uname -s)" != "Darwin" ]; then
  echo "Run this script on your Mac, not Windows."
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 24 LTS, then run this script again."
  exit 1
fi
if ! xcodebuild -version; then
  echo "Install and open Xcode 26.4 or newer; select its Command Line Tools."
  exit 1
fi
xcrun --sdk iphoneos --show-sdk-path
echo "Installing the exact dependencies from package-lock.json..."
npm ci
npm run typecheck
npm test
echo "Connect and trust your iPhone, enable Developer Mode, then select your device."
echo "Use your Apple development team when Xcode asks for signing."
echo "A Release build includes JavaScript and runs without Metro or a computer."
npx expo run:ios --device --configuration Release
