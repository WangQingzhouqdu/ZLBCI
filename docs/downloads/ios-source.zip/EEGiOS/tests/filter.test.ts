import assert from 'node:assert/strict';
import test from 'node:test';
import fixtures from './scipy-fixtures.json';
import { DEFAULT_FILTER, EegFilter } from '../src/core/filter';

function signal(fs: number, count: number): number[][] {
  return Array.from({ length: count }, (_, i) => {
    const t = i / fs;
    return [Math.fround(750 + 35 * Math.sin(2 * Math.PI * 10 * t) + 12 * Math.sin(2 * Math.PI * 50 * t) +
      7 * Math.cos(2 * Math.PI * 60 * t) + 4 * Math.sin(2 * Math.PI * 100 * t))];
  });
}

// Golden values generated independently with SciPy 1.15.3. Ported from the
// existing Android tests, including desktop float32 input and output rounding.
for (const fixture of fixtures.cases) {
  test(`streaming SOS matches independently generated SciPy vector: ${fixture.name}`, () => {
    const filter = new EegFilter();
    filter.configure(fixture.fs, { ...DEFAULT_FILTER, ...fixture.settings });
    const output = filter.process(signal(fixture.fs, 4096));
    fixtures.indices.forEach((index, j) => {
      assert.ok(Math.abs(fixture.expected[j] - output[index][0]) < .003,
        `${fixture.name}[${index}]: expected ${fixture.expected[j]}, actual ${output[index][0]}`);
    });
    assert.ok(output.every((sample) => Number.isFinite(sample[0])));
  });
}

test('filter default settings exactly match the supplied desktop UI', () => {
  assert.deepEqual(DEFAULT_FILTER, {
    enabled: true, highPass: .5, lowPass: 45, order: 4, notchHz: 50, harmonics: 2, notchQ: 30,
  });
  assert.ok(new EegFilter().description.includes('0.5–45'));
  assert.ok(new EegFilter().description.includes('50/100'));
});

test('chunk boundaries do not change output, and reset restores startup', () => {
  const input = signal(250, 1500);
  const whole = new EegFilter().process(input);
  const filter = new EegFilter();
  let offset = 0;
  for (const size of [1, 7, 40, 251, 13, 1, 511, 676]) {
    assert.deepEqual(filter.process(input.slice(offset, offset + size)), whole.slice(offset, offset + size));
    offset += size;
  }
  assert.equal(offset, input.length);
  filter.reset();
  assert.deepEqual(filter.process([input[0]]), [whole[0]]);
});

test('steady-state initialization removes large DC independently on all eight channels', () => {
  const input = Array.from({ length: 1000 }, () => Array.from({ length: 8 }, (_, ch) => (ch - 4) * 100000));
  assert.ok(new EegFilter().process(input).every((sample) => sample.every((v) => Math.abs(v) < .01)));
  const lowpass = new EegFilter();
  lowpass.configure(250, { ...DEFAULT_FILTER, highPass: 0, lowPass: 30, notchHz: 0 });
  const out = lowpass.process(input);
  assert.ok(out.every((sample, i) => sample.every((v, ch) => Math.abs(v - input[i][ch]) < .01)));
});

test('response preserves 10 Hz alpha and attenuates 50/100 Hz mains plus baseline drift', () => {
  const gain = (hz: number) => {
    const input = Array.from({ length: 6000 }, (_, i) => [Math.fround(Math.sin(2 * Math.PI * hz * i / 250))]);
    const output = new EegFilter().process(input);
    const power = output.slice(3000).reduce((sum, sample) => sum + sample[0] ** 2, 0);
    return Math.sqrt(2 * power / 3000);
  };
  assert.ok(Math.abs(gain(10) - 1) < .02);
  assert.ok(gain(50) < .001);
  assert.ok(gain(100) < .001);
  assert.ok(gain(.05) < .01);
});

test('disabled filter returns independent copies and NaN does not poison subsequent samples', () => {
  const filter = new EegFilter();
  filter.configure(250, { ...DEFAULT_FILTER, enabled: false });
  const input = [[42]];
  const output = filter.process(input);
  assert.deepEqual(output, input);
  output[0][0] = 99;
  assert.equal(input[0][0], 42);
  assert.deepEqual(filter.process([]), []);
  filter.configure(250, DEFAULT_FILTER);
  const recovered = filter.process([[NaN], [1000], [1001]]);
  assert.ok(Number.isNaN(recovered[0][0]));
  assert.ok(Math.abs(recovered[1][0]) < .001);
  assert.ok(Number.isFinite(recovered[2][0]));
});

test('invalid settings throw without replacing a working filter; Nyquist boundaries match desktop behavior', () => {
  const filter = new EegFilter();
  assert.throws(() => filter.configure(0, DEFAULT_FILTER));
  assert.throws(() => filter.configure(250, { ...DEFAULT_FILTER, notchQ: 0 }));
  assert.throws(() => filter.configure(250, { ...DEFAULT_FILTER, order: 9 }));
  assert.throws(() => filter.configure(250, { ...DEFAULT_FILTER, lowPass: Infinity }));
  assert.throws(() => filter.process([[1], [1, 2]]));
  filter.configure(250, { ...DEFAULT_FILTER, highPass: 0, lowPass: 125, notchHz: 0 });
  assert.equal(filter.description, '直通');
  assert.deepEqual(filter.process([[42]]), [[42]]);
  filter.configure(250, { ...DEFAULT_FILTER, highPass: 10, lowPass: 5 });
  assert.ok(filter.description.startsWith('高通'));
  filter.configure(250, { ...DEFAULT_FILTER, notchHz: 60, harmonics: 5 });
  assert.ok(filter.description.endsWith('陷波 60 Hz'));
});
