import assert from 'node:assert/strict';
import test from 'node:test';
import { PacketTracker, WaveformBuffer } from '../src/core/buffer';
import type { EegPacket } from '../src/core/protocol';

const rows = (values: number[]) => values.map((value) => Array(8).fill(value));
function packet(seq: number, sampleIndex: number, sampleCount = 10, sampleRate = 250): EegPacket {
  return {
    seq, sampleIndex, sampleCount, sampleRate, channelCount: 8, gain: 24, leadOffP: 0, leadOffN: 0,
    flags: 2, samples: rows(Array(sampleCount).fill(0)), byteCount: 15 + sampleCount * 24, overflow: false, streaming: true,
  };
}
function close(actual: number, expected: number) { assert.ok(Math.abs(actual - expected) < 1e-10, `${actual} != ${expected}`); }

test('tracker uses sample time, preserves real loss, rejects duplicate and stale notifications', () => {
  const tracker = new PacketTracker();
  assert.deepEqual(tracker.accept(packet(100, 1000)), {
    accepted: true, gapSamples: 0, lostPackets: 0, discontinuity: false, firstSampleTime: 0,
  });
  const lost = tracker.accept(packet(103, 1030));
  assert.equal(lost.gapSamples, 20);
  assert.equal(lost.lostPackets, 2);
  assert.equal(lost.discontinuity, true);
  close(lost.firstSampleTime, .12);
  assert.equal(tracker.accept(packet(103, 1030)).accepted, false);
  assert.equal(tracker.accept(packet(102, 1020)).accepted, false);
  close(tracker.accept(packet(104, 1040)).firstSampleTime, .16);
});

test('tracker handles simultaneous uint16 seq / uint32 sample wrap without false loss', () => {
  const tracker = new PacketTracker();
  tracker.accept(packet(65535, 0xfffffffc, 4));
  const p = tracker.accept(packet(0, 0, 4));
  assert.equal(p.accepted, true);
  assert.equal(p.gapSamples, 0);
  assert.equal(p.lostPackets, 0);
  assert.equal(p.discontinuity, false);
  close(p.firstSampleTime, .016);
  const gap = tracker.accept(packet(2, 8, 4));
  assert.equal(gap.gapSamples, 4);
  assert.equal(gap.lostPackets, 1);
  close(gap.firstSampleTime, .048);
});

test('firmware sample-index reset, sample-rate change, and explicit reset never create enormous time gaps', () => {
  const tracker = new PacketTracker();
  tracker.accept(packet(10, 123000));
  const restart = tracker.accept(packet(11, 0));
  assert.equal(restart.discontinuity, true);
  assert.equal(restart.gapSamples, 0);
  close(restart.firstSampleTime, .04);
  const rateChange = tracker.accept(packet(12, 0, 20, 500));
  assert.equal(rateChange.discontinuity, true);
  assert.equal(rateChange.gapSamples, 0);
  close(rateChange.firstSampleTime, .08);
  close(tracker.accept(packet(13, 20, 20, 500)).firstSampleTime, .12);
  tracker.reset();
  close(tracker.accept(packet(1, 0)).firstSampleTime, 0);
});

test('tracker resets on gain changes, handles seq gaps separately from sample gaps, and ignores invalid packets', () => {
  const tracker = new PacketTracker();
  tracker.accept(packet(1, 0));
  const gap = tracker.accept(packet(3, 10));
  assert.equal(gap.gapSamples, 0);
  assert.equal(gap.lostPackets, 1);
  const changed = tracker.accept({ ...packet(4, 20), gain: 12 });
  assert.equal(changed.discontinuity, true);
  assert.equal(changed.gapSamples, 0);
  assert.equal(tracker.accept(packet(5, 30, 0)).accepted, false);
  assert.equal(tracker.accept(packet(5, 30, 10, NaN)).accepted, false);
});

test('ring is right-aligned while filling, wraps in sample order, and retains latest huge batch', () => {
  const buffer = new WaveformBuffer(5);
  assert.deepEqual(buffer.plot(0, 5), []);
  buffer.push(rows([1, 2]));
  assert.deepEqual(buffer.plot(0, 5), [{ x: .75, y: 1 }, { x: 1, y: 2 }]);
  buffer.push(rows([3, 4, 5, 6, 7]));
  assert.deepEqual(buffer.plot(0, 5).map((p) => p.y), [3, 4, 5, 6, 7]);
  buffer.push(rows([8, 9, 10, 11, 12, 13, 14]));
  assert.deepEqual(buffer.plot(0, 5).map((p) => p.y), [10, 11, 12, 13, 14]);
  buffer.reset(3);
  buffer.push(rows([8, 9]));
  assert.deepEqual(buffer.plot(7, 3), [{ x: .5, y: 8 }, { x: 1, y: 9 }]);
});

test('min/max downsampling preserves narrow positive and negative peaks in time order', () => {
  const buffer = new WaveformBuffer(1000);
  const data = Array(1000).fill(0);
  data[202] = 999;
  data[207] = -888;
  buffer.push(rows(data));
  const plot = buffer.plot(0, 10);
  assert.ok(plot.length <= 20);
  assert.ok(plot.some((p) => p.y === 999));
  assert.ok(plot.some((p) => p.y === -888));
  assert.ok(plot.findIndex((p) => p.y === 999) < plot.findIndex((p) => p.y === -888));
  assert.ok(plot.every((p, i) => p.x >= 0 && p.x <= 1 && (!i || p.x >= plot[i - 1].x)));
});

test('a sub-pixel missing span remains a NaN path break rather than a fabricated waveform', () => {
  const buffer = new WaveformBuffer(100);
  buffer.push(rows(Array(49).fill(4)));
  buffer.gap(1);
  buffer.push(rows(Array(50).fill(8)));
  const plot = buffer.plot(0, 1);
  const gap = plot.findIndex((p) => Number.isNaN(p.y));
  assert.ok(gap > 0 && gap < plot.length - 1);
  assert.equal(plot[gap - 1].y, 4);
  assert.equal(plot[gap + 1].y, 8);
  close(plot[gap].x, 49 / 99);
  buffer.gap(1e9);
  assert.ok(buffer.plot(0, 10).every((p) => Number.isNaN(p.y)));
  buffer.push(rows([42]));
  assert.equal(buffer.plot(0, 100).at(-1)?.y, 42);
});

test('ring validates channel layout/capacity and handles fractional pixel widths', () => {
  assert.throws(() => new WaveformBuffer(Infinity));
  const buffer = new WaveformBuffer(7);
  assert.throws(() => buffer.push([[1, 2]]));
  assert.throws(() => buffer.gap(-1));
  assert.throws(() => buffer.plot(8, 3));
  buffer.push(rows([1, 2, 3, 4, 5, 6, 7]));
  assert.deepEqual(buffer.plot(0, 0), []);
  const plotted = buffer.plot(0, 3);
  assert.equal(plotted[0].y, 1);
  assert.equal(plotted.at(-1)?.y, 7);
});
