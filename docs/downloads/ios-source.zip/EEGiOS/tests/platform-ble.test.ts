import assert from 'node:assert/strict';
import test from 'node:test';
import type { BleCallbacks, DiscoveredDevice } from '../src/platform/ble';
import { RX_UUID, SERVICE_UUID, STATUS_UUID, TX_UUID } from '../src/core/protocol';
import { loadPlatform, tick } from './platform-fixtures';

type BleModule = typeof import('../src/platform/ble');
type Event = { peripheral?: string; [name: string]: unknown };
const device: DiscoveredDevice = { id: 'board-id', name: 'EEG-board', rssi: -60 };

function createBleFixture(missing = false) {
  const events = new Map<string, Set<(event: Event) => void>>();
  const actions: string[] = [];
  const writes: string[] = [];
  const pending: { resolve(): void; reject(error: Error): void }[] = [];
  const state = { delayedWrites: false, delayDisconnect: false, connected: false, connectPromise: null as Promise<void> | null };
  const emit = (name: string, event: Event) => { for (const callback of events.get(name) ?? []) callback(event); };
  const on = (name: string) => (callback: (event: Event) => void) => {
    const handlers = events.get(name) ?? new Set();
    handlers.add(callback);
    events.set(name, handlers);
    return { remove: () => handlers.delete(callback) };
  };
  const manager = {
    start: async () => { actions.push('start'); }, checkState: async () => 'on',
    scan: async () => { actions.push('scan'); }, stopScan: async () => { actions.push('stopScan'); },
    connect: async () => { actions.push('connect'); await state.connectPromise; state.connected = true; },
    disconnect: async (id: string) => {
      actions.push('disconnect-request');
      if (!state.delayDisconnect) { state.connected = false; emit('disconnect', { peripheral: id }); }
    },
    isPeripheralConnected: async () => state.connected,
    retrieveServices: async () => ({ characteristics: [
      { service: SERVICE_UUID, characteristic: RX_UUID, properties: { Write: 'Write' } },
      { service: SERVICE_UUID, characteristic: TX_UUID, properties: { Notify: 'Notify' } },
      { service: SERVICE_UUID, characteristic: STATUS_UUID, properties: { Notify: 'Notify' } },
    ] }),
    startNotification: async (_id: string, _service: string, characteristic: string) => { actions.push(`notify:${characteristic}`); },
    write: (_id: string, _service: string, _characteristic: string, bytes: number[]) => {
      const value = String.fromCharCode(...bytes);
      actions.push(`write:${value.trim()}`);
      writes.push(value);
      return state.delayedWrites ? new Promise<void>((resolve, reject) => pending.push({ resolve, reject })) : Promise.resolve();
    },
    onDiscoverPeripheral: on('discover'), onStopScan: on('stop'), onDidUpdateState: on('state'),
    onDisconnectPeripheral: on('disconnect'), onDidUpdateValueForCharacteristic: on('value'),
  };
  const observations = { devices: [] as DiscoveredDevice[], data: [] as Uint8Array[], status: [] as Record<string, unknown>[], logs: [] as string[], disconnections: 0 };
  const callbacks: BleCallbacks = {
    onDevice: (value) => { observations.devices.push(value); }, onData: (value) => { observations.data.push(value); },
    onStatus: (value) => { observations.status.push(value); }, onLog: (value) => { observations.logs.push(value); },
    onDisconnect: () => { observations.disconnections++; }, onScanning: () => undefined,
  };
  const api = loadPlatform<BleModule>('ble.ts', {
    'react-native': { Platform: { OS: 'ios' }, PermissionsAndroid: {} },
    '../core/protocol': { RX_UUID, SERVICE_UUID, STATUS_UUID, TX_UUID },
    'react-native-ble-manager': missing ? new Error('Missing native module') : { default: manager },
  });
  return { api, transport: new api.BleTransport(callbacks), callbacks, observations, emit, actions, writes, pending, state, events };
}

test('BLE constructor stays usable without native module; hardware action explains Expo Go limitation', async () => {
  const fixture = createBleFixture(true);
  assert.equal(fixture.actions.length, 0);
  await assert.rejects(fixture.transport.scan(true), /Expo Go/);
  fixture.transport.dispose();
});

test('BLE scans EEG advertisements and subscribes before INFO; foreign data and bad status are isolated', async () => {
  const f = createBleFixture();
  await f.transport.scan(true);
  f.emit('discover', { id: 'other', name: 'Other', rssi: -50, advertising: {} });
  f.emit('discover', { id: 'named', name: 'EEG-board', rssi: -70, advertising: {} });
  f.emit('discover', { id: 'service', name: 'Board', rssi: -60, advertising: { serviceUUIDs: [SERVICE_UUID.toUpperCase()] } });
  assert.equal(f.observations.devices.length, 2);
  await f.transport.connect(device);
  assert.equal(f.actions.filter((action) => action === 'start').length, 1);
  assert.ok(f.actions.indexOf(`notify:${TX_UUID}`) < f.actions.indexOf('write:INFO'));
  assert.ok(f.actions.indexOf(`notify:${STATUS_UUID}`) < f.actions.indexOf('write:INFO'));
  assert.equal(f.writes[0], 'INFO\n');
  const value = { peripheral: device.id, service: SERVICE_UUID, characteristic: TX_UUID, value: [165, 90, 1] };
  f.emit('value', { ...value, peripheral: 'other' }); f.emit('value', { ...value, service: 'wrong' });
  assert.equal(f.observations.data.length, 0);
  f.emit('value', value); assert.equal(f.observations.data.length, 1);
  f.emit('value', { ...value, characteristic: STATUS_UUID, value: [123, 125] });
  f.emit('value', { ...value, characteristic: STATUS_UUID, value: [123] });
  assert.equal(f.observations.status.length, 1);
  assert.ok(f.observations.logs.some((log) => log.includes('无法解析')));
  await f.transport.disconnect(); f.transport.dispose();
});

test('BLE commands are serialized and an in-flight command is invalidated on disconnect', async () => {
  const f = createBleFixture(); await f.transport.connect(device);
  f.state.delayedWrites = true;
  const first = f.transport.send('SR:500'); const second = f.transport.send('GAIN:24');
  await tick(); assert.equal(f.pending.length, 1); assert.equal(f.writes.length, 2);
  f.pending.shift()!.resolve(); await first; await tick(); assert.equal(f.writes.length, 3);
  f.pending.shift()!.resolve(); await second;
  const late = f.transport.send('START'); const canceled = assert.rejects(late, /取消/);
  await tick(); await f.transport.disconnect(); f.pending.shift()!.resolve(); await canceled;
  assert.equal(f.observations.disconnections, 1);
  f.transport.dispose();
  assert.ok([...f.events.values()].every((handlers) => handlers.size === 0));
});

test('BLE cancellation prevents a delayed connect from subscribing or sending commands', async () => {
  const f = createBleFixture(); let resolveConnect: () => void = () => undefined;
  f.state.connectPromise = new Promise<void>((resolve) => { resolveConnect = resolve; });
  const connecting = f.transport.connect(device); const canceled = assert.rejects(connecting, /取消/);
  await tick(); await f.transport.disconnect(); resolveConnect(); await canceled;
  assert.equal(f.actions.filter((action) => action.startsWith('notify:')).length, 0);
  assert.equal(f.writes.length, 0); f.transport.dispose();
});

test('BLE waits for actual native disconnection before a new session may scan', async () => {
  const f = createBleFixture(); await f.transport.connect(device);
  f.state.delayDisconnect = true;
  f.transport.dispose();
  const next = new f.api.BleTransport(f.callbacks);
  const scan = next.scan(true);
  await tick();
  assert.ok(f.actions.includes('disconnect-request'));
  assert.equal(f.actions.filter((action) => action === 'scan').length, 0, 'cancel request is not a disconnect acknowledgement');
  f.state.connected = false; f.emit('disconnect', { peripheral: device.id });
  await scan;
  assert.equal(f.actions.filter((action) => action === 'scan').length, 1);
  next.dispose(); await tick();
});
