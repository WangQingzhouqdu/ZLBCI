import assert from 'node:assert/strict';
import test from 'node:test';
import { crc8, GAINS, parsePacket, SAMPLE_RATES } from '../src/core/protocol';

/** Independent bitwise encoder, so parser tests cannot validate their own CRC implementation. */
function packet(options: { seq?: number; index?: number; flags?: number; gain?: number; values?: number[] } = {}): Uint8Array {
  const { seq = 12, index = 42, flags = 2, gain = 6, values = Array(8).fill(0) } = options;
  const bytes = new Uint8Array(15 + values.length * 3);
  bytes.set([0xa5, 0x5a, seq & 255, seq >>> 8, 8, values.length / 8]);
  for (let i = 0; i < 4; i++) bytes[6 + i] = (index >>> (8 * i)) & 255;
  bytes.set([0x81, 0x42, flags, gain], 10);
  values.forEach((v, i) => bytes.set([(v >>> 16) & 255, (v >>> 8) & 255, v & 255], 14 + 3 * i));
  let crc = 0;
  for (let i = 0; i < bytes.length - 1; i++) {
    crc ^= bytes[i];
    for (let bit = 0; bit < 8; bit++) crc = crc & 128 ? ((crc << 1) ^ 7) & 255 : (crc << 1) & 255;
  }
  bytes[bytes.length - 1] = crc;
  return bytes;
}

test('CRC-8 standard check value and empty input', () => {
  assert.equal(crc8(new TextEncoder().encode('123456789')), 0xf4);
  assert.equal(crc8(new Uint8Array()), 0);
});

test('signed 24-bit extrema, little-endian unsigned counters, flags, channel masks and float32 scaling', () => {
  const values = [-8388608, -1, 0, 1, 8388607, 123456, -654321, 0];
  const p = parsePacket(packet({ seq: 65535, index: 0xffffffff, flags: 0x63, values }));
  assert.ok(p);
  assert.equal(p.seq, 65535);
  assert.equal(p.sampleIndex, 0xffffffff);
  assert.equal(p.channelCount, 8);
  assert.equal(p.sampleCount, 1);
  assert.equal(p.gain, 24);
  assert.equal(p.sampleRate, 16000);
  assert.equal(p.leadOffP, 0x81);
  assert.equal(p.leadOffN, 0x42);
  assert.equal(p.streaming, true);
  assert.equal(p.overflow, true);
  assert.equal(p.byteCount, 39);
  const scale = Math.fround(4500000 / (24 * 8388608));
  assert.deepEqual(p.samples[0], values.map((v) => Math.fround(v * scale)));
  assert.equal(p.samples[0][0], -187500);
  assert.equal(p.samples[0][4], 187499.984375);
});

test('all gain/rate codes including desktop reserved-code fallbacks', () => {
  for (let code = 0; code < 8; code++) assert.equal(parsePacket(packet({ gain: code }))?.gain, GAINS[code] ?? 24);
  for (let code = 0; code < 16; code++) assert.equal(parsePacket(packet({ flags: code << 4 }))?.sampleRate, SAMPLE_RATES[code] ?? 250);
});

test('every truncated packet and corrupted fields/checksum are rejected', () => {
  const full = packet({ values: Array.from({ length: 24 }, (_, i) => i - 10) });
  for (let length = 0; length < full.length; length++) assert.equal(parsePacket(full.slice(0, length)), null, `length=${length}`);
  for (const offset of [0, 4, 5, 20, full.length - 1]) {
    const broken = full.slice();
    broken[offset] ^= 1;
    assert.equal(parsePacket(broken), null, `offset=${offset}`);
  }
  const extra = new Uint8Array(full.length + 2);
  extra.set(full);
  extra.set([99, 100], full.length);
  const p = parsePacket(extra);
  assert.ok(p);
  assert.equal(p.samples.length, 3);
  assert.equal(p.samples[1][2], 0);
  assert.equal(p.byteCount, full.length);
  assert.ok(p.samples[2][7] > p.samples[0][0]);
});

test('parser honors Uint8Array slice offsets and unsigned one-byte sample counts', () => {
  for (const count of [1, 127, 128, 255]) {
    const source = packet({ values: Array.from({ length: count * 8 }, (_, i) => i - 1000) });
    const backing = new Uint8Array(source.length + 27);
    backing.set(source, 13);
    const p = parsePacket(backing.subarray(13, 13 + source.length));
    assert.ok(p);
    assert.equal(p.sampleCount, count);
    assert.equal(p.samples.length, count);
    assert.equal(p.byteCount, 15 + 24 * count);
  }
});
