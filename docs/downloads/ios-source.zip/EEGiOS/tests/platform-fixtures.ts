import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { runInNewContext } from 'node:vm';
import ts from 'typescript';

/** Load production TypeScript with only its native boundary replaced. */
export function loadPlatform<T>(name: string, mocks: Record<string, unknown>, replacements: [string, string][] = []): T {
  let source = readFileSync(fileURLToPath(new URL(`../src/platform/${name}`, import.meta.url)), 'utf8');
  for (const [from, to] of replacements) source = source.replace(from, to);
  const javascript = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText;
  const module = { exports: {} };
  runInNewContext(javascript, {
    module, exports: module.exports,
    require: (id: string) => {
      if (!(id in mocks)) throw new Error(`Unexpected runtime dependency: ${id}`);
      const value = mocks[id];
      if (value instanceof Error) throw value;
      return value;
    },
    TextEncoder, TextDecoder, Uint8Array, Blob, URL, Date, Math, Set, Map, Promise,
    Error, Number, Array, String, JSON, setTimeout, clearTimeout,
  }, { filename: name });
  return module.exports as T;
}

export const tick = () => new Promise<void>((resolve) => setImmediate(resolve));

export function createFileSystemFixture() {
  const files = new Map<string, Uint8Array>();
  const state = { handlesClosed: 0, rejectWrites: false, sharedUri: '', handlesOpened: 0 };
  const path = (parts: (string | { uri: string })[]) => parts.map((part) => typeof part === 'string' ? part : part.uri).join('/').replace(/\/+$/, '');
  class Directory {
    uri: string;
    constructor(...parts: (string | { uri: string })[]) { this.uri = path(parts); }
    get exists() { return true; }
    create() {}
    list() { return [...files.keys()].filter((name) => name.startsWith(`${this.uri}/`)).map((name) => new File(name)); }
  }
  class File {
    uri: string;
    constructor(...parts: (string | { uri: string })[]) { this.uri = path(parts); }
    get name() { return this.uri.split('/').at(-1)!; }
    get size() { return files.get(this.uri)?.length ?? 0; }
    get creationTime() { return 1_000; }
    get modificationTime() { return 1_000; }
    get exists() { return files.has(this.uri); }
    create() { if (this.exists) throw new Error('File already exists'); files.set(this.uri, new Uint8Array()); }
    write(value: string) { files.set(this.uri, new TextEncoder().encode(value)); }
    textSync() { return new TextDecoder().decode(files.get(this.uri)); }
    open(mode: string) {
      if (!['w', 'r'].includes(mode)) throw new Error(`Unexpected FileMode: ${mode}`);
      const file = this;
      let offset = 0;
      let closed = false;
      state.handlesOpened++;
      return {
        get offset() { return closed ? null : offset; },
        set offset(value: number | null) { offset = value ?? offset; },
        readBytes(length: number) {
          if (closed || mode !== 'r') throw new Error('Handle is not readable');
          const bytes = files.get(file.uri)!.slice(offset, offset + length);
          offset += bytes.length;
          return bytes;
        },
        writeBytes(bytes: Uint8Array) {
          if (closed || mode !== 'w') throw new Error('Handle is not writable');
          if (state.rejectWrites) throw new Error('Disk full');
          const existing = files.get(file.uri)!;
          const next = new Uint8Array(Math.max(existing.length, offset + bytes.length));
          next.set(existing);
          next.set(bytes, offset);
          files.set(file.uri, next);
          offset += bytes.length;
        },
        close() { if (!closed) state.handlesClosed++; closed = true; },
      };
    }
  }
  return {
    files, state, File,
    mocks: {
      'expo-file-system': { Directory, File, FileMode: { WriteOnly: 'w', ReadOnly: 'r' }, Paths: { document: 'documents' } },
      'expo-sharing': { isAvailableAsync: async () => true, shareAsync: async (uri: string) => { state.sharedUri = uri; } },
    },
  };
}
