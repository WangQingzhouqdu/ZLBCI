import assert from 'node:assert/strict';
import test from 'node:test';
import type { RecordingMode } from '../src/platform/recordings';
import { createFileSystemFixture, loadPlatform } from './platform-fixtures';

type NativeRecordings = typeof import('../src/platform/recordings');
type WebRecordings = typeof import('../src/platform/recordings.web');
const row = [1.123456789, 2, 3, 4, 5, 6, 7, 8];
const filtered = row.map((value) => value * 2);

for (const [mode, columns] of [['both', 18], ['raw', 10], ['filt', 10]] as [RecordingMode, number][]) {
  test(`CSV ${mode} preserves precision, uint32 wrap and missing-sample time gaps`, async () => {
    const fixture = createFileSystemFixture();
    const api = loadPlatform<NativeRecordings>('recordings.ts', fixture.mocks);
    const recorder = new api.CsvRecorder();
    recorder.start({ demo: true, device: 'board\nname', sampleRate: 250, filter: { highPass: 0.5 } }, mode);
    recorder.append([row, row], [filtered, filtered], 0xffffffff, 20, 250);
    recorder.append([row], [filtered], 4, 20.024, 250);
    assert.equal(api.listRecordings().length, 0, 'active files cannot be exported');
    const entry = recorder.stop()!;
    assert.equal(recorder.active, false);
    assert.equal(recorder.sampleCount, 3);
    assert.equal(recorder.stop(), null, 'stop is idempotent');
    assert.equal(entry.samples, 3);
    assert.equal(fixture.state.handlesClosed, 1);
    const csv = new fixture.File(entry.uri).textSync();
    const lines = csv.trim().split('\n').filter((line) => !line.startsWith('#'));
    assert.equal(lines.length, 4);
    assert.equal(lines[0].split(',').length, columns);
    assert.equal(lines[1].split(',')[0], '0');
    assert.equal(lines[1].split(',')[1], '4294967295');
    assert.equal(lines[2].split(',')[1], '0');
    assert.ok(Math.abs(Number(lines[3].split(',')[0]) - 0.024) < 1e-9);
    if (mode !== 'filt') assert.ok(csv.includes('1.123456789'));
    assert.ok(csv.includes('# device: board name'));
    await api.shareRecording(entry);
    assert.equal(fixture.state.sharedUri, entry.uri);
  });
}

test('CSV write failure closes its handle and retains earlier samples for recovery', () => {
  const fixture = createFileSystemFixture();
  const api = loadPlatform<NativeRecordings>('recordings.ts', fixture.mocks);
  const recorder = new api.CsvRecorder();
  recorder.start({ demo: true }, 'both');
  recorder.append([row], [filtered], 0, 0, 250);
  fixture.state.rejectWrites = true;
  assert.throws(() => recorder.append([row], [filtered], 1, 0.004, 250), /已写入部分保留/);
  assert.equal(recorder.active, false);
  assert.equal(recorder.sampleCount, 1);
  assert.equal(fixture.state.handlesClosed, 1);
  fixture.state.rejectWrites = false;
  const recoveredApi = loadPlatform<NativeRecordings>('recordings.ts', fixture.mocks);
  const recovered = recoveredApi.listRecordings();
  assert.equal(recovered.length, 1);
  assert.equal(recovered[0].samples, 1);
  assert.equal(fixture.state.handlesOpened, fixture.state.handlesClosed);
});

test('CSV files remain discoverable without sidecar metadata after an interrupted app', () => {
  const fixture = createFileSystemFixture();
  const api = loadPlatform<NativeRecordings>('recordings.ts', fixture.mocks);
  const recorder = new api.CsvRecorder();
  recorder.start({ demo: true }, 'raw');
  recorder.append([row, row], [filtered, filtered], 12, 1, 250);
  const entry = recorder.stop()!;
  fixture.files.delete(`documents/EEG/${entry.id}.json`);
  const afterRestart = loadPlatform<NativeRecordings>('recordings.ts', fixture.mocks).listRecordings();
  assert.equal(afterRestart.length, 1);
  assert.equal(afterRestart[0].samples, 2);
  assert.equal(afterRestart[0].demo, true);
  assert.equal(afterRestart[0].createdAt, entry.createdAt);
});

test('Web recording memory budget stops and preserves the existing CSV segment', () => {
  // Scale only the constant so the exact production boundary path runs without
  // allocating 100 MB for a unit test.
  const api = loadPlatform<WebRecordings>('recordings.web.ts', {}, [['100 * 1024 * 1024', '2048']]);
  const recorder = new api.CsvRecorder();
  recorder.start({ demo: true }, 'both');
  assert.throws(() => {
    for (let sample = 0; sample < 100; sample++) recorder.append([row], [filtered], sample, sample / 250, 250);
  }, /100 MB/);
  assert.equal(recorder.active, false);
  const entry = api.listRecordings()[0];
  assert.ok(entry.samples > 0);
  assert.ok(entry.bytes <= 2048);
  URL.revokeObjectURL(entry.uri);
});
