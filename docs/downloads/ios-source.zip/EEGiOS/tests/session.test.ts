import assert from 'node:assert/strict';
import test from 'node:test';
import { EegSession, DEFAULT_HARDWARE, type SessionDependencies } from '../src/session/controller';
import { crc8 } from '../src/core/protocol';
import type { RecordingEntry } from '../src/platform/recordings';

function packet(seq: number, index: number, options: { count?: number; rateCode?: number; gainCode?: number; streaming?: boolean; overflow?: boolean } = {}) {
  const count = options.count ?? 10;
  const bytes = new Uint8Array(15 + 24 * count);
  bytes.set([0xa5, 0x5a, seq & 255, seq >>> 8, 8, count]);
  new DataView(bytes.buffer).setUint32(6, index, true);
  bytes[12] = ((options.rateCode ?? 0) << 4) | (options.streaming === false ? 0 : 2) | Number(options.overflow === true);
  bytes[13] = options.gainCode ?? 6;
  for (let sample = 0; sample < count; sample++) {
    for (let channel = 0; channel < 8; channel++) bytes[14 + sample * 24 + channel * 3 + 2] = sample + channel;
  }
  bytes[bytes.length - 1] = crc8(bytes.subarray(0, -1));
  return bytes;
}

function harness() {
  let callbacks!: Parameters<SessionDependencies['createTransport']>[0];
  let appState!: (value: string) => void;
  let now = 0;
  let disposed = 0;
  let failCommand = '';
  const commands: string[] = [];
  const awake: boolean[] = [];
  const saved: RecordingEntry[] = [];
  const writes: { index: number; time: number; fs: number; count: number }[] = [];
  const metadata: Record<string, unknown>[] = [];
  const recorder = {
    active: false, sampleCount: 0,
    start(info: Record<string, unknown>) { this.active = true; this.sampleCount = 0; metadata.push(info); },
    append(raw: number[][], _filtered: number[][], index: number, time: number, fs: number) {
      writes.push({ index, time, fs, count: raw.length });
      this.sampleCount += raw.length;
    },
    stop(): RecordingEntry | null {
      if (!this.active) return null;
      this.active = false;
      const entry = { id: `${saved.length}`, name: 'test.csv', uri: 'test.csv', createdAt: '', samples: this.sampleCount, bytes: 0, demo: metadata.at(-1)?.demo === true };
      saved.push(entry);
      return entry;
    },
  };
  const session = new EegSession({
    createTransport(next) {
      callbacks = next;
      return {
        async scan() { callbacks.onScanning(true); }, async connect() {},
        async disconnect() {}, dispose() { disposed++; },
        async send(command) { commands.push(command); if (command === failCommand) throw new Error('injected write failure'); },
      };
    },
    createRecorder: () => recorder,
    listRecordings: () => saved.slice(),
    shareRecording: async () => {},
    subscribeAppState(listener) { appState = listener; return () => {}; },
    async setKeepAwake(enabled) { awake.push(enabled); },
    now: () => now, commandDelayMs: 0,
  });
  // Timer boundaries are explicit, making 5s/2s watchdog tests deterministic.
  const tick = () => (session as unknown as { tick(): void }).tick();
  return {
    session, recorder, commands, saved, writes, metadata, awake,
    send: (bytes: Uint8Array) => callbacks.onData(bytes),
    status: (data: Record<string, unknown>) => callbacks.onStatus(data),
    device: (id: number) => callbacks.onDevice({ id: String(id), name: `EEG ${id}`, rssi: -50 }),
    app: (value: string) => appState(value),
    advance(ms: number) { now += ms; tick(); }, tick,
    get disposed() { return disposed; }, failOn(command: string) { failCommand = command; },
    async connect() { await session.connect({ id: 'test', name: 'EEG', rssi: -50 }); },
  };
}

test('START waits for valid data and stale status cannot fake a live stream', async () => {
  const h = harness();
  try {
    await h.connect();
    assert.equal(h.session.getSnapshot().actualFs, 0);
    assert.deepEqual(h.commands, ['STOP', 'SR:250', 'GAIN:24', 'MODE:NORMAL', 'SRB1:1', 'BIAS:1', 'LOFF:0']);
    await h.session.start();
    assert.equal(h.session.getSnapshot().starting, true);
    assert.equal(h.session.getSnapshot().streaming, false);
    h.status({ streaming: true, lost: 999, fs: 16000 });
    h.tick();
    assert.equal(h.session.getSnapshot().streaming, false);
    assert.equal(h.session.getSnapshot().stats.lostSamples, 0);
    h.send(packet(1, 0));
    h.tick();
    assert.equal(h.session.getSnapshot().actualFs, 250);
    assert.equal(h.session.getSnapshot().streaming, true);
    assert.equal(h.session.getSnapshot().starting, false);
    await Promise.resolve();
    assert.deepEqual(h.awake, [true]);
  } finally { h.session.dispose(); }
});

test('CSV keeps packet gaps, rejects duplicates/out of order, and plot contains a blank span', async () => {
  const h = harness();
  try {
    await h.connect();
    await h.session.start();
    h.send(packet(10, 0));
    h.tick();
    await h.session.startRecording('both');
    h.send(packet(11, 10));
    h.send(packet(11, 10, { rateCode: 1 })); // A stale header must not change actual fs.
    h.send(packet(10, 0));
    h.send(packet(13, 30, { overflow: true }));
    h.tick();
    assert.equal(h.recorder.active, true);
    assert.deepEqual(h.writes.map(write => write.index), [10, 30]);
    assert.ok(Math.abs(h.writes[1].time - h.writes[0].time - 0.08) < 1e-12);
    assert.equal(h.session.getSnapshot().actualFs, 250);
    assert.equal(h.session.getSnapshot().stats.lostSamples, 10);
    assert.equal(h.session.getSnapshot().stats.lostPackets, 1);
    assert.equal(h.session.getSnapshot().stats.samples, 30);
    assert.equal(h.session.getSnapshot().stats.overflowPackets, 1);
    assert.ok(h.session.plot(0, false, 100).some(point => Number.isNaN(point.y)));
    await h.session.pause();
    assert.equal(h.saved[0].samples, 20);
  } finally { h.session.dispose(); }
});

test('5-second first-packet and 2-second interruption timeouts pause and finish CSV', async () => {
  const h = harness();
  try {
    await h.connect();
    await h.session.start();
    h.advance(4999);
    assert.equal(h.session.getSnapshot().starting, true);
    h.advance(1);
    assert.equal(h.session.getSnapshot().starting, false);
    assert.match(h.session.getSnapshot().error!, /5 秒/);
    assert.equal(h.commands.at(-1), 'STOP');
    await h.session.start();
    h.send(packet(50, 0));
    await h.session.startRecording('raw');
    h.send(packet(51, 10));
    h.advance(2000);
    assert.equal(h.recorder.active, false);
    assert.equal(h.saved[0].samples, 10);
    assert.match(h.session.getSnapshot().error!, /2 秒/);
  } finally { h.session.dispose(); }
});

test('inactive keeps sampling; background sends STOP, closes CSV and requires explicit restart', async () => {
  const h = harness();
  try {
    await h.connect();
    await h.session.start();
    h.send(packet(0, 0));
    await h.session.startRecording('raw');
    h.app('inactive');
    h.send(packet(1, 10));
    assert.equal(h.recorder.active, true);
    h.app('background');
    assert.equal(h.recorder.active, false);
    assert.equal(h.commands.at(-1), 'STOP');
    assert.equal(h.session.getSnapshot().streaming, false);
    h.app('active');
    h.send(packet(2, 20));
    h.tick();
    assert.equal(h.session.getSnapshot().stats.samples, 20);
    assert.equal(h.saved[0].samples, 10);
    assert.equal(h.session.getSnapshot().streaming, false);
  } finally { h.session.dispose(); }
});

test('actual header rate change closes the recording without changing requested hardware settings', async () => {
  const h = harness();
  try {
    await h.connect();
    await h.session.start();
    h.send(packet(3, 0));
    await h.session.startRecording('both');
    h.send(packet(4, 10));
    h.send(packet(5, 0, { rateCode: 1, gainCode: 5 }));
    h.tick();
    assert.equal(h.saved.length, 1);
    assert.equal(h.recorder.active, false);
    assert.equal(h.session.getSnapshot().actualFs, 500);
    assert.equal(h.session.getSnapshot().actualGain, 12);
    assert.equal(h.session.getSnapshot().hardware.sampleRate, 250);
    assert.equal(h.session.getSnapshot().stats.lostSamples, 0);
  } finally { h.session.dispose(); }
});

test('partial hardware command failure disconnects and prevents subsequent START', async () => {
  const h = harness();
  try {
    await h.connect();
    h.failOn('GAIN:12');
    await assert.rejects(h.session.applyHardware({ ...DEFAULT_HARDWARE, gain: 12 }), /配置未完整发送/);
    assert.equal(h.session.getSnapshot().connection, 'disconnected');
    assert.equal(h.disposed, 1);
    await assert.rejects(h.session.start(), /先连接/);
    assert.equal(h.commands.includes('START'), false);
  } finally { h.session.dispose(); }
});

test('each START resets packet tracking when firmware reuses sequence and sample index', async () => {
  const h = harness();
  try {
    await h.connect();
    await h.session.start();
    h.send(packet(1, 0));
    h.send(packet(2, 10));
    await h.session.pause();
    await h.session.start();
    h.send(packet(1, 0));
    h.tick();
    assert.equal(h.session.getSnapshot().stats.samples, 10);
    assert.equal(h.session.getSnapshot().stats.lostSamples, 0);
  } finally { h.session.dispose(); }
});

test('snapshots remain stable until UI tick; device inventory is bounded', async () => {
  const h = harness();
  try {
    await h.session.scan(true);
    const before = h.session.getSnapshot();
    for (let id = 0; id < 200; id++) h.device(id);
    assert.equal(h.session.getSnapshot(), before);
    h.tick();
    assert.notEqual(h.session.getSnapshot(), before);
    assert.equal(h.session.getSnapshot().devices.length, 100);
  } finally { h.session.dispose(); }
});

test('demo is opt-in, generates eight-channel samples, and marks recordings as demo', async () => {
  const h = harness();
  try {
    assert.equal(h.session.getSnapshot().connection, 'disconnected');
    await h.session.useDemo();
    assert.equal(h.session.getSnapshot().streaming, false);
    await h.session.start();
    (h.session as unknown as { demoTick(): void }).demoTick();
    h.tick();
    await h.session.startRecording('both');
    (h.session as unknown as { demoTick(): void }).demoTick();
    await h.session.pause();
    assert.equal(h.saved[0].demo, true);
    assert.equal(h.saved[0].samples, 10);
    assert.equal(h.metadata[0].demo, true);
    assert.equal(h.commands.length, 0);
    assert.ok(h.session.plot(7, false, 100).every(point => Number.isFinite(point.y)));
  } finally { h.session.dispose(); }
});

test('disconnect during initial setup cancels the pending connection before transport creation', async () => {
  const h = harness();
  try {
    const connection = h.connect();
    await h.session.disconnect();
    await assert.rejects(connection, /操作已取消/);
    assert.equal(h.commands.length, 0);
    assert.equal(h.session.getSnapshot().connection, 'disconnected');
    assert.equal(h.session.getSnapshot().busy, false);
  } finally { h.session.dispose(); }
});
