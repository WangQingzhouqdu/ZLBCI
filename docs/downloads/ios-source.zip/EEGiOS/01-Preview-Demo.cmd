@echo off
setlocal
cd /d "%~dp0"
if not exist "node_modules\expo\package.json" call npm.cmd ci
if errorlevel 1 goto failed
call npm.cmd run web
pause
exit /b
:failed
echo Dependency installation failed. Check the error above.
pause
exit /b 1
