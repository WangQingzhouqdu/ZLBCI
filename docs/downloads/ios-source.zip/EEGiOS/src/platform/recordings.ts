import { Directory, File, FileMode, Paths, type FileHandle } from 'expo-file-system';
import * as Sharing from 'expo-sharing';

export type RecordingMode = 'both' | 'raw' | 'filt';
export type RecordingEntry = {
  id: string;
  name: string;
  uri: string;
  createdAt: string;
  samples: number;
  bytes: number;
  demo: boolean;
};

const encoder = new TextEncoder();
const activeUris = new Set<string>();
const recoveryCache = new Map<string, RecordingEntry>();
const message = (error: unknown) => error instanceof Error ? error.message : String(error);
const directory = () => new Directory(Paths.document, 'EEG');
const oneLine = (value: string) => value.replace(/[\r\n\u2028\u2029]/g, ' ');

function csvHeader(metadata: Record<string, unknown>, mode: RecordingMode, createdAt: string): string {
  const lines = ['# EEG iOS recording', `# createdAt: ${createdAt}`];
  for (const [key, value] of Object.entries(metadata)) {
    lines.push(`# ${oneLine(key)}: ${oneLine(typeof value === 'string' ? value : JSON.stringify(value) ?? String(value))}`);
  }
  lines.push('# unit: microvolt (uV)', '# time_s: seconds since the first recorded sample; device gaps are preserved',
    '# sample_index: unsigned 32-bit device index; wraps at 4294967296',
    '# missing_samples: omitted, never interpolated', `# recording_mode: ${mode}`);
  const columns = ['time_s', 'sample_index'];
  if (mode !== 'filt') for (let channel = 1; channel <= 8; channel++) columns.push(`raw_ch${channel}`);
  if (mode !== 'raw') for (let channel = 1; channel <= 8; channel++) columns.push(`filt_ch${channel}`);
  return `${lines.join('\n')}\n${columns.join(',')}\n`;
}

function assertSamples(raw: number[][], filtered: number[][], firstSampleTime: number, fs: number): void {
  if (!Number.isFinite(fs) || fs <= 0 || !Number.isFinite(firstSampleTime)) throw new Error('记录采样率或时间无效');
  if (raw.length !== filtered.length || raw.some((row) => row.length !== 8) || filtered.some((row) => row.length !== 8)) {
    throw new Error('记录必须包含对应的八通道原始与滤波数据');
  }
}

function writeIndex(entry: RecordingEntry, complete: boolean): void {
  const index = new File(directory(), `${entry.id}.json`);
  index.write(JSON.stringify({ ...entry, complete }));
}

/** Incremental local storage. No upload or cloud operation is performed. */
export class CsvRecorder {
  active = false;
  sampleCount = 0;
  private mode: RecordingMode = 'both';
  private file: File | null = null;
  private handle: FileHandle | null = null;
  private entry: RecordingEntry | null = null;
  private origin: number | null = null;
  private lastTime = -Infinity;
  private bytesWritten = 0;
  private writeFailed = false;

  start(metadata: Record<string, unknown>, mode: RecordingMode): void {
    if (this.active) throw new Error('已有正在进行的记录');
    if (!['both', 'raw', 'filt'].includes(mode)) throw new Error('记录模式无效');
    const createdAt = new Date().toISOString();
    const header = encoder.encode(csvHeader(metadata, mode, createdAt));
    const folder = directory();
    folder.create({ intermediates: true, idempotent: true });
    const id = `eeg_${metadata.demo === true ? 'demo_' : ''}${createdAt.replace(/[-:.]/g, '')}_${Math.random().toString(36).slice(2, 8)}`;
    const file = new File(folder, `${id}.csv`);
    file.create();
    let handle: FileHandle | null = null;
    try {
      handle = file.open(FileMode.WriteOnly);
      handle.writeBytes(header);
    } catch (error) {
      try { handle?.close(); } catch { /* Keep whatever reached disk. */ }
      throw new Error(`无法开始 CSV 记录：${message(error)}`);
    }
    this.file = file;
    this.handle = handle;
    this.mode = mode;
    this.sampleCount = 0;
    this.origin = null;
    this.lastTime = -Infinity;
    this.bytesWritten = header.byteLength;
    this.writeFailed = false;
    this.entry = { id, name: file.name, uri: file.uri, createdAt, samples: 0, bytes: header.byteLength, demo: metadata.demo === true };
    this.active = true;
    activeUris.add(file.uri);
    // CSV is authoritative; a lost sidecar never makes the recording disappear.
    try { writeIndex(this.entry, false); } catch { /* listRecordings can recover it. */ }
  }

  append(raw: number[][], filtered: number[][], sampleIndex: number, firstSampleTime: number, fs: number): void {
    if (!this.active || !this.handle) throw new Error('尚未开始记录');
    try {
      assertSamples(raw, filtered, firstSampleTime, fs);
      if (!Number.isInteger(sampleIndex) || sampleIndex < 0 || sampleIndex > 0xffffffff) throw new Error('设备样本序号无效');
      if (raw.length === 0) return;
      if (this.origin === null) this.origin = firstSampleTime;
      const start = firstSampleTime - this.origin;
      if (start < this.lastTime - 1e-9) throw new Error('设备记录时间倒退，已停止当前文件以保留时间轴');
      const rows = new Array<string>(raw.length);
      for (let sample = 0; sample < raw.length; sample++) {
        const values: number[] = [start + sample / fs, (sampleIndex + sample) >>> 0];
        if (this.mode !== 'filt') values.push(...raw[sample]);
        if (this.mode !== 'raw') values.push(...filtered[sample]);
        // Do not round measurements or discard samples for display performance.
        rows[sample] = values.join(',');
      }
      const bytes = encoder.encode(`${rows.join('\n')}\n`);
      this.handle.writeBytes(bytes);
      this.bytesWritten += bytes.byteLength;
      this.sampleCount += raw.length;
      this.lastTime = start + (raw.length - 1) / fs;
    } catch (error) {
      this.writeFailed = true;
      try { this.stop(); } catch { /* Preserve the initial failure and CSV. */ }
      throw new Error(`CSV 记录已停止，已写入部分保留在本机：${message(error)}`);
    }
  }

  stop(): RecordingEntry | null {
    if (!this.active || !this.entry || !this.file) return null;
    this.active = false;
    const handle = this.handle;
    this.handle = null;
    let closeError: unknown;
    try { handle?.close(); } catch (error) { closeError = error; this.writeFailed = true; }
    activeUris.delete(this.file.uri);
    let bytes = this.bytesWritten;
    try { bytes = this.file.size; } catch { /* Last successful write count remains available. */ }
    const entry = { ...this.entry, samples: this.sampleCount, bytes };
    this.entry = entry;
    try { writeIndex(entry, !this.writeFailed); } catch { /* Recover metadata from CSV on next listing. */ }
    if (!this.writeFailed) recoveryCache.set(entry.uri, entry);
    this.file = null;
    if (closeError) throw new Error(`记录文件关闭失败，已写入内容保留：${message(closeError)}`);
    return entry;
  }
}

/** Stream through a surviving CSV in bounded chunks after an interrupted run. */
function recoverEntry(file: File): RecordingEntry {
  const handle = file.open(FileMode.ReadOnly);
  let samples = 0;
  let firstByte = -1;
  let header = '';
  try {
    while ((handle.offset ?? 0) < file.size) {
      const bytes = handle.readBytes(64 * 1024);
      if (bytes.length === 0) break;
      if (header === '') header = new TextDecoder().decode(bytes);
      for (const byte of bytes) {
        if (firstByte === -1 && byte !== 10 && byte !== 13) firstByte = byte;
        if (byte === 10) {
          // Data rows start with time_s, whereas comments and the column header do not.
          if ((firstByte >= 48 && firstByte <= 57) || firstByte === 45) samples++;
          firstByte = -1;
        }
      }
    }
  } finally { handle.close(); }
  const created = /^# createdAt: (.+)$/m.exec(header)?.[1]?.trim();
  return {
    id: file.name.replace(/\.csv$/i, ''), name: file.name, uri: file.uri,
    createdAt: created && Number.isFinite(Date.parse(created)) ? created : new Date(file.creationTime ?? file.modificationTime ?? Date.now()).toISOString(),
    samples, bytes: file.size, demo: /^# demo: true\s*$/m.test(header) || file.name.startsWith('eeg_demo_'),
  };
}

export function listRecordings(): RecordingEntry[] {
  const folder = directory();
  if (!folder.exists) return [];
  const recordings: RecordingEntry[] = [];
  for (const file of folder.list()) {
    if (!(file instanceof File) || !file.name.endsWith('.csv') || activeUris.has(file.uri)) continue;
    const cached = recoveryCache.get(file.uri);
    if (cached && cached.bytes === file.size) { recordings.push({ ...cached }); continue; }
    let entry: RecordingEntry | null = null;
    try {
      const sidecar = new File(folder, file.name.replace(/\.csv$/, '.json'));
      if (sidecar.exists) {
        const saved = JSON.parse(sidecar.textSync()) as Partial<RecordingEntry> & { complete?: boolean };
        if (saved.complete && typeof saved.samples === 'number' && saved.samples >= 0 && saved.bytes === file.size && typeof saved.createdAt === 'string') {
          entry = { id: file.name.slice(0, -4), name: file.name, uri: file.uri, createdAt: saved.createdAt, samples: saved.samples, bytes: file.size, demo: saved.demo === true };
        }
      }
    } catch { /* Missing or interrupted metadata is reconstructed below. */ }
    if (!entry) entry = recoverEntry(file);
    recoveryCache.set(file.uri, entry);
    recordings.push({ ...entry });
  }
  return recordings.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function shareRecording(entry: RecordingEntry): Promise<void> {
  if (!entry.name.endsWith('.csv') || /[\\/]/.test(entry.name)) throw new Error('记录文件名无效');
  const file = new File(directory(), entry.name);
  if (!file.exists) throw new Error('记录文件已不存在');
  if (activeUris.has(file.uri)) throw new Error('请先停止记录再导出');
  if (!await Sharing.isAvailableAsync()) throw new Error('当前系统无法打开文件分享面板');
  // The user chooses the destination in the system sheet. The app never uploads.
  await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', UTI: 'public.comma-separated-values-text', dialogTitle: '导出脑电 CSV' });
}
