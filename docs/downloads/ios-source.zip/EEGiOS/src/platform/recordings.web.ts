export type RecordingMode = 'both' | 'raw' | 'filt';
export type RecordingEntry = {
  id: string;
  name: string;
  uri: string;
  createdAt: string;
  samples: number;
  bytes: number;
  demo: boolean;
};

// Browser preview is intentionally transient. This budget includes completed
// recordings; reaching it keeps existing files available for download.
const MEMORY_LIMIT = 100 * 1024 * 1024;
const records = new Map<string, { entry: RecordingEntry; blob: Blob }>();
const encoder = new TextEncoder();
let reservedBytes = 0;
const oneLine = (text: string) => text.replace(/[\r\n\u2028\u2029]/g, ' ');

function header(metadata: Record<string, unknown>, mode: RecordingMode, createdAt: string): string {
  const lines = ['# EEG iOS browser demonstration', `# createdAt: ${createdAt}`];
  for (const [key, value] of Object.entries(metadata)) {
    lines.push(`# ${oneLine(key)}: ${oneLine(typeof value === 'string' ? value : JSON.stringify(value) ?? String(value))}`);
  }
  lines.push('# unit: microvolt (uV)', '# time_s: seconds since the first recorded sample; device gaps are preserved',
    '# sample_index: unsigned 32-bit device index; wraps at 4294967296', '# missing_samples: omitted, never interpolated', `# recording_mode: ${mode}`);
  const columns = ['time_s', 'sample_index'];
  if (mode !== 'filt') for (let channel = 1; channel <= 8; channel++) columns.push(`raw_ch${channel}`);
  if (mode !== 'raw') for (let channel = 1; channel <= 8; channel++) columns.push(`filt_ch${channel}`);
  return `${lines.join('\n')}\n${columns.join(',')}\n`;
}

export class CsvRecorder {
  active = false;
  sampleCount = 0;
  private mode: RecordingMode = 'both';
  private entry: RecordingEntry | null = null;
  private chunks: Uint8Array<ArrayBuffer>[] = [];
  private origin: number | null = null;
  private lastTime = -Infinity;
  private bytes = 0;

  start(metadata: Record<string, unknown>, mode: RecordingMode): void {
    if (this.active) throw new Error('已有正在进行的记录');
    if (!['both', 'raw', 'filt'].includes(mode)) throw new Error('记录模式无效');
    const createdAt = new Date().toISOString();
    const bytes = encoder.encode(header(metadata, mode, createdAt));
    if (reservedBytes + bytes.byteLength > MEMORY_LIMIT) throw new Error('浏览器记录已达到 100 MB，请先下载已有 CSV，再刷新页面开始新记录');
    const id = `eeg_${metadata.demo === true ? 'demo_' : ''}${createdAt.replace(/[-:.]/g, '')}_${Math.random().toString(36).slice(2, 8)}`;
    this.mode = mode;
    this.chunks = [bytes];
    this.bytes = bytes.byteLength;
    reservedBytes += bytes.byteLength;
    this.origin = null;
    this.lastTime = -Infinity;
    this.sampleCount = 0;
    this.entry = { id, name: `${id}.csv`, uri: '', createdAt, samples: 0, bytes: this.bytes, demo: metadata.demo === true };
    this.active = true;
  }

  append(raw: number[][], filtered: number[][], sampleIndex: number, firstSampleTime: number, fs: number): void {
    if (!this.active) throw new Error('尚未开始记录');
    try {
      if (!Number.isFinite(fs) || fs <= 0 || !Number.isFinite(firstSampleTime)) throw new Error('记录采样率或时间无效');
      if (!Number.isInteger(sampleIndex) || sampleIndex < 0 || sampleIndex > 0xffffffff) throw new Error('设备样本序号无效');
      if (raw.length !== filtered.length || raw.some((row) => row.length !== 8) || filtered.some((row) => row.length !== 8)) throw new Error('记录必须包含对应的八通道数据');
      if (raw.length === 0) return;
      if (this.origin === null) this.origin = firstSampleTime;
      const start = firstSampleTime - this.origin;
      if (start < this.lastTime - 1e-9) throw new Error('记录时间倒退，已停止当前文件');
      const rows = new Array<string>(raw.length);
      for (let sample = 0; sample < raw.length; sample++) {
        const values: number[] = [start + sample / fs, (sampleIndex + sample) >>> 0];
        if (this.mode !== 'filt') values.push(...raw[sample]);
        if (this.mode !== 'raw') values.push(...filtered[sample]);
        rows[sample] = values.join(',');
      }
      const chunk = encoder.encode(`${rows.join('\n')}\n`);
      if (reservedBytes + chunk.byteLength > MEMORY_LIMIT) throw new Error('浏览器记录已达到 100 MB；当前片段已保留，请下载已有 CSV 后再刷新页面');
      this.chunks.push(chunk);
      this.bytes += chunk.byteLength;
      reservedBytes += chunk.byteLength;
      this.sampleCount += raw.length;
      this.lastTime = start + (raw.length - 1) / fs;
    } catch (error) {
      this.stop();
      throw error;
    }
  }

  stop(): RecordingEntry | null {
    if (!this.active || !this.entry) return null;
    this.active = false;
    const blob = new Blob(this.chunks, { type: 'text/csv;charset=utf-8' });
    const entry = { ...this.entry, samples: this.sampleCount, bytes: this.bytes, uri: URL.createObjectURL(blob) };
    records.set(entry.id, { entry, blob });
    this.chunks = [];
    this.entry = entry;
    return { ...entry };
  }
}

export function listRecordings(): RecordingEntry[] {
  return [...records.values()].map(({ entry }) => ({ ...entry })).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function shareRecording(entry: RecordingEntry): Promise<void> {
  const saved = records.get(entry.id);
  if (!saved) throw new Error('浏览器记录已不存在；网页刷新前请下载需要保留的 CSV');
  const anchor = document.createElement('a');
  anchor.href = saved.entry.uri;
  anchor.download = saved.entry.name;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}
