import { PermissionsAndroid, Platform } from 'react-native';
import { RX_UUID, SERVICE_UUID, STATUS_UUID, TX_UUID } from '../core/protocol';

export type DiscoveredDevice = { id: string; name: string; rssi: number };
export type BleCallbacks = {
  onDevice: (device: DiscoveredDevice) => void;
  onData: (bytes: Uint8Array) => void;
  onStatus: (data: Record<string, unknown>) => void;
  onLog: (message: string) => void;
  onDisconnect: () => void;
  onScanning: (active: boolean) => void;
};

type Manager = typeof import('react-native-ble-manager').default;
type Subscription = { remove(): void };
let nativeManager: Manager | undefined;
let nativeStart: Promise<void> | undefined;
let nativeCleanup: Promise<void> = Promise.resolve();
const uuid = (value: string) => value.toLowerCase();
const errorMessage = (error: unknown) => error instanceof Error ? error.message : String(error);

function loadManager(): Manager {
  // Expo Go does not contain this native module. Keep the demonstration usable
  // by loading it only when the user asks to scan or connect.
  if (nativeManager) return nativeManager;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports -- Lazy native loading keeps Expo Go demonstration available.
    nativeManager = (require('react-native-ble-manager') as { default: Manager }).default;
    if (!nativeManager) throw new Error('Missing BleManager');
    return nativeManager;
  } catch {
    throw new Error('真实蓝牙连接需要安装 EEG iOS 开发构建；Expo Go 可使用模拟设备。请按照使用说明在 Mac/Xcode 构建后连接。');
  }
}

function timeout<T>(operation: Promise<T>, milliseconds: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label}超时，请检查设备电量、距离和是否被其他上位机占用`)), milliseconds);
  });
  return Promise.race([operation, deadline]).finally(() => { if (timer) clearTimeout(timer); });
}

/** Foreground BLE transport. iOS background acquisition is not guaranteed. */
export class BleTransport {
  private manager?: Manager;
  private subscriptions: Subscription[] = [];
  private disposed = false;
  private scanning = false;
  private onlyEeg = true;
  private connecting = false;
  private ready = false;
  private peripheral: string | null = null;
  private generation = 0;
  private scanTimer?: ReturnType<typeof setTimeout>;
  private writeQueue: Promise<void> = Promise.resolve();
  private disconnectTask: Promise<void> | null = null;

  constructor(private readonly callbacks: BleCallbacks) {}

  private log(message: string): void { if (!this.disposed) this.callbacks.onLog(message); }

  private setScanning(active: boolean): void {
    if (this.scanning === active) return;
    this.scanning = active;
    if (!active && this.scanTimer) { clearTimeout(this.scanTimer); this.scanTimer = undefined; }
    if (!this.disposed) this.callbacks.onScanning(active);
  }

  private attachListeners(manager: Manager): void {
    if (this.subscriptions.length) return;
    this.subscriptions = [
      manager.onDiscoverPeripheral((device) => {
        if (this.disposed || !this.scanning) return;
        const name = device.name || device.advertising?.localName || '未命名 BLE 设备';
        const services = device.advertising?.serviceUUIDs ?? [];
        if (this.onlyEeg && !/eeg/i.test(name) && !services.some((service) => uuid(service) === uuid(SERVICE_UUID))) return;
        this.callbacks.onDevice({ id: device.id, name, rssi: device.rssi });
      }),
      manager.onStopScan(({ status }) => {
        if (!this.scanning) return;
        this.setScanning(false);
        if (status !== undefined && status !== 0 && status !== 10) this.log(`蓝牙扫描结束（状态 ${status}）`);
      }),
      manager.onDidUpdateState(({ state }) => {
        if (this.disposed || state === 'on' || state === 'unknown' || state === 'resetting') return;
        this.setScanning(false);
        this.log(state === 'unauthorized' ? '蓝牙权限未获授权，请在系统设置中允许此应用使用蓝牙' : '蓝牙不可用，请打开系统蓝牙');
        if (this.peripheral) void this.disconnect().catch((error) => this.log(errorMessage(error)));
      }),
      manager.onDisconnectPeripheral(({ peripheral }) => {
        if (this.disposed || this.peripheral !== peripheral) return;
        this.peripheral = null;
        this.ready = false;
        this.generation++;
        this.writeQueue = Promise.resolve();
        this.log('设备蓝牙连接已断开');
        this.callbacks.onDisconnect();
      }),
      manager.onDidUpdateValueForCharacteristic((event) => {
        if (this.disposed || !this.ready || event.peripheral !== this.peripheral || uuid(event.service) !== uuid(SERVICE_UUID)) return;
        if (uuid(event.characteristic) === uuid(TX_UUID)) {
          this.callbacks.onData(Uint8Array.from(event.value));
        } else if (uuid(event.characteristic) === uuid(STATUS_UUID)) {
          try {
            const text = new TextDecoder().decode(Uint8Array.from(event.value)).trim();
            const value: unknown = JSON.parse(text);
            if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('状态不是 JSON 对象');
            this.callbacks.onStatus(value as Record<string, unknown>);
          } catch { this.log('收到无法解析的设备状态；脑电数据接收继续'); }
        }
      }),
    ];
  }

  private async ensureManager(): Promise<Manager> {
    if (this.disposed) throw new Error('蓝牙会话已关闭');
    const manager = loadManager();
    // BleManager is a process-wide native singleton. A newly mounted session
    // must not scan/connect while a disposed session is still disconnecting.
    await nativeCleanup;
    if (this.disposed) throw new Error('蓝牙会话已关闭');
    this.manager = manager;
    this.attachListeners(manager);
    if (!nativeStart) {
      nativeStart = manager.start({ showAlert: false }).catch((error: unknown) => {
        nativeStart = undefined;
        throw new Error(`蓝牙模块初始化失败：${errorMessage(error)}。Expo Go 请使用模拟设备，真实连接需要开发构建。`);
      });
    }
    await nativeStart;
    if (this.disposed) throw new Error('蓝牙会话已关闭');
    if (Platform.OS === 'android') {
      const permissions = Number(Platform.Version) >= 31
        ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN, PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]
        : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
      const granted = await PermissionsAndroid.requestMultiple(permissions);
      if (permissions.some((permission) => granted[permission] !== PermissionsAndroid.RESULTS.GRANTED)) {
        throw new Error('请允许蓝牙扫描和连接权限后重试');
      }
    }
    // CoreBluetooth initially reports unknown while its central manager starts.
    let state = await manager.checkState();
    for (let attempt = 0; (state === 'unknown' || state === 'resetting') && attempt < 15; attempt++) {
      await new Promise<void>((resolve) => setTimeout(resolve, 100));
      state = await manager.checkState();
    }
    if (this.disposed) throw new Error('蓝牙会话已关闭');
    if (state !== 'on') {
      if (state === 'unauthorized') throw new Error('蓝牙权限未获授权，请在 iPhone「设置」中允许脑电采集使用蓝牙');
      if (state === 'unsupported') throw new Error('当前设备不支持 BLE；iOS 模拟器请使用模拟设备模式');
      throw new Error('蓝牙尚未就绪，请打开系统蓝牙后重试');
    }
    return manager;
  }

  async scan(onlyEeg: boolean): Promise<void> {
    if (this.peripheral || this.connecting || this.disconnectTask) throw new Error('请先断开当前设备再扫描');
    if (this.scanning) return;
    this.onlyEeg = onlyEeg;
    this.setScanning(true);
    const generation = this.generation;
    try {
      const manager = await this.ensureManager();
      if (generation !== this.generation || this.disposed) throw new Error('扫描已取消');
      // Software filtering also accepts firmware that advertises an EEG name
      // but leaves the service UUID out of the advertisement.
      await manager.scan({ serviceUUIDs: [], seconds: 10, allowDuplicates: true });
      if (!this.scanning) return;
      this.scanTimer = setTimeout(() => {
        this.setScanning(false);
        void manager.stopScan().catch((error: unknown) => this.log(`停止扫描失败：${errorMessage(error)}`));
      }, 10_500);
    } catch (error) { this.setScanning(false); throw error; }
  }

  private assertCurrent(id: string, generation: number): void {
    if (this.disposed || this.peripheral !== id || this.generation !== generation) throw new Error('连接操作已取消');
  }

  async connect(device: DiscoveredDevice): Promise<void> {
    if (this.connecting || this.disconnectTask) throw new Error('连接操作进行中，请稍后重试');
    if (this.peripheral) throw new Error('请先断开当前设备');
    this.connecting = true;
    const generation = ++this.generation;
    const id = device.id;
    try {
      const manager = await this.ensureManager();
      if (this.disposed || generation !== this.generation) throw new Error('连接操作已取消');
      this.setScanning(false);
      await timeout(manager.stopScan(), 3_000, '停止扫描');
      if (this.disposed || generation !== this.generation) throw new Error('连接操作已取消');
      this.peripheral = id;
      this.log(`正在连接 ${device.name}…`);
      await timeout(manager.connect(id), 20_000, '蓝牙连接');
      this.assertCurrent(id, generation);
      if (Platform.OS === 'android') {
        const mtu = await timeout(manager.requestMTU(id, 247), 8_000, 'MTU 协商');
        if (mtu < 42) throw new Error(`BLE MTU 仅 ${mtu}，无法接收完整的八通道数据包`);
      }
      const info = await timeout(manager.retrieveServices(id, [SERVICE_UUID]), 10_000, '服务发现');
      this.assertCurrent(id, generation);
      const characteristics = info.characteristics ?? [];
      const has = (target: string) => characteristics.some((item) => uuid(item.service) === uuid(SERVICE_UUID) && uuid(item.characteristic) === uuid(target));
      if (!has(RX_UUID) || !has(TX_UUID)) throw new Error('设备不提供 EEG 服务的 RX/TX 特征，请选择正确的采集板');
      const rx = characteristics.find((item) => uuid(item.service) === uuid(SERVICE_UUID) && uuid(item.characteristic) === uuid(RX_UUID));
      if (!rx?.properties.Write) throw new Error('设备 RX 特征不支持带响应写入，与采集协议不兼容');
      await timeout(manager.startNotification(id, SERVICE_UUID, TX_UUID), 8_000, '订阅脑电数据');
      this.assertCurrent(id, generation);
      if (has(STATUS_UUID)) {
        try { await timeout(manager.startNotification(id, SERVICE_UUID, STATUS_UUID), 5_000, '订阅设备状态'); }
        catch (error) { this.log(`可选状态通知不可用：${errorMessage(error)}`); }
      }
      this.assertCurrent(id, generation);
      this.ready = true;
      await this.send('INFO');
      this.assertCurrent(id, generation);
      this.log(`已连接 ${device.name}；iOS 在前台采集，锁屏或切到后台时请停止记录`);
    } catch (error) {
      if (this.generation === generation && this.peripheral === id) await this.disconnect().catch(() => undefined);
      throw error;
    } finally { this.connecting = false; }
  }

  send(command: string): Promise<void> {
    const value = command.trim();
    if (!value || value.length > 64 || /[^\x20-\x7e]/.test(value)) return Promise.reject(new Error('BLE 命令必须是单行 ASCII 文本'));
    const id = this.peripheral;
    const generation = this.generation;
    const manager = this.manager;
    if (!this.ready || !id || !manager || this.disposed || this.disconnectTask) return Promise.reject(new Error('请先连接并等待设备就绪'));
    const bytes = Array.from(`${value}\n`, (character) => character.charCodeAt(0));
    const operation = this.writeQueue.then(async () => {
      this.assertCurrent(id, generation);
      await timeout(manager.write(id, SERVICE_UUID, RX_UUID, bytes, 20), 5_000, `发送 ${value}`);
      this.assertCurrent(id, generation);
    }).catch(async (error: unknown) => {
      if (this.peripheral === id && this.generation === generation) {
        this.log(`命令发送失败，已断开以避免继续应用不完整配置：${errorMessage(error)}`);
        await this.disconnect().catch(() => undefined);
      }
      throw error;
    });
    // Keep errors on the returned promise, while avoiding an unhandled rejection
    // on the internal queue. Subsequent queued jobs fail their generation check.
    this.writeQueue = operation.catch(() => undefined);
    return operation;
  }

  disconnect(): Promise<void> {
    if (this.disconnectTask) return this.disconnectTask;
    const id = this.peripheral;
    const manager = this.manager;
    const hadScan = this.scanning;
    const hadConnection = id !== null;
    this.peripheral = null;
    this.ready = false;
    this.generation++;
    this.writeQueue = Promise.resolve();
    this.setScanning(false);
    // A second dispose after a completed disconnect must not stop a newer
    // session's scan on the process-wide manager.
    if (!id && !hadScan) return Promise.resolve();
    const task = (async () => {
      if (manager) {
        await timeout(manager.stopScan(), 2_000, '停止扫描').catch(() => undefined);
        if (id) {
          let markDisconnected: () => void = () => undefined;
          const disconnected = new Promise<void>((resolve) => { markDisconnected = resolve; });
          // On iOS disconnect() acknowledges cancelPeripheralConnection, before
          // CoreBluetooth's actual didDisconnect callback. Keep this dedicated
          // listener alive even when dispose removes the regular listeners.
          const listener = manager.onDisconnectPeripheral((event) => {
            if (event.peripheral === id) markDisconnected();
          });
          try {
            await timeout(manager.disconnect(id), 5_000, '断开连接');
            try { await timeout(disconnected, 5_000, '确认蓝牙断开'); }
            catch (error) {
              // Canceling a pending connection may emit didFailToConnect
              // instead. In that case no connected peripheral remains.
              if (await timeout(manager.isPeripheralConnected(id, []), 2_000, '查询连接状态')) throw error;
            }
          } finally { listener.remove(); }
        }
      }
    })().finally(() => {
      this.disconnectTask = null;
      if (hadConnection && !this.disposed) this.callbacks.onDisconnect();
    });
    this.disconnectTask = task;
    nativeCleanup = task.catch(() => undefined);
    return task;
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    void this.disconnect().catch(() => undefined);
    this.subscriptions.forEach((subscription) => subscription.remove());
    this.subscriptions = [];
  }
}
