export type DiscoveredDevice = { id: string; name: string; rssi: number };
export type BleCallbacks = {
  onDevice: (device: DiscoveredDevice) => void;
  onData: (bytes: Uint8Array) => void;
  onStatus: (data: Record<string, unknown>) => void;
  onLog: (message: string) => void;
  onDisconnect: () => void;
  onScanning: (active: boolean) => void;
};

const nativeRequired = () => new Error('浏览器仅支持模拟设备。真实 BLE 连接请在 iPhone 上安装 EEG iOS 开发构建；Expo Go 也不包含此蓝牙模块。');

export class BleTransport {
  constructor(private readonly callbacks: BleCallbacks) {}
  async scan(_onlyEeg: boolean): Promise<void> { this.callbacks.onScanning(false); throw nativeRequired(); }
  async connect(_device: DiscoveredDevice): Promise<void> { throw nativeRequired(); }
  async send(_command: string): Promise<void> { throw nativeRequired(); }
  async disconnect(): Promise<void> { this.callbacks.onScanning(false); }
  dispose(): void {}
}
