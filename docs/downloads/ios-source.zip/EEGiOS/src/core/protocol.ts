/** ESP32-S3 / ADS1299 protocol; byte-for-byte compatible with eeg_host.py. */
export const SERVICE_UUID = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
export const RX_UUID = '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
export const TX_UUID = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
export const STATUS_UUID = '6e400004-b5a3-f393-e0a9-e50e24dcca9e';
export const GAINS = [1, 2, 4, 6, 8, 12, 24] as const;
export const SAMPLE_RATES = [250, 500, 1000, 2000, 4000, 8000, 16000] as const;
export const CHANNEL_COLORS = [
  '#d62728', '#ff7f0e', '#bcbd22', '#2ca02c',
  '#17becf', '#1f77b4', '#9467bd', '#8c564b',
] as const;

export interface EegPacket {
  seq: number;
  channelCount: number;
  sampleCount: number;
  sampleIndex: number;
  leadOffP: number;
  leadOffN: number;
  flags: number;
  gain: number;
  sampleRate: number;
  /** Sample-major, CH1...CH8; all amplitudes are microvolts. */
  samples: number[][];
  byteCount: number;
  overflow: boolean;
  streaming: boolean;
}

const CRC_TABLE = Uint8Array.from({ length: 256 }, (_, input) => {
  let c = input;
  for (let i = 0; i < 8; i++) c = c & 0x80 ? ((c << 1) ^ 7) & 255 : (c << 1) & 255;
  return c;
});

/** CRC-8: polynomial 0x07, initial 0x00, no reflection or final XOR. */
export function crc8(data: Uint8Array): number {
  let crc = 0;
  for (const byte of data) crc = CRC_TABLE[crc ^ byte];
  return crc;
}

export function parsePacket(data: Uint8Array): EegPacket | null {
  if (data.length < 15 || data[0] !== 0xa5 || data[1] !== 0x5a) return null;
  const channelCount = data[4];
  const sampleCount = data[5];
  // Unlike the desktop, reject a different channel count before UI ingestion.
  if (channelCount !== 8 || sampleCount === 0) return null;
  const byteCount = 15 + sampleCount * channelCount * 3;
  if (data.length < byteCount || crc8(data.subarray(0, byteCount - 1)) !== data[byteCount - 1]) return null;
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const flags = data[12];
  // Preserve the desktop fallbacks for reserved code values.
  const gain = GAINS[data[13] & 7] ?? 24;
  const sampleRate = SAMPLE_RATES[(flags >>> 4) & 15] ?? 250;
  const scale = Math.fround(4.5 / (gain * 8388608) * 1e6);
  let offset = 14;
  const samples = Array.from({ length: sampleCount }, () =>
    Array.from({ length: channelCount }, () => {
      let raw = (data[offset] << 16) | (data[offset + 1] << 8) | data[offset + 2];
      if (raw & 0x800000) raw -= 0x1000000;
      offset += 3;
      return Math.fround(raw * scale);
    }),
  );
  return {
    seq: view.getUint16(2, true), channelCount, sampleCount,
    sampleIndex: view.getUint32(6, true), leadOffP: data[10], leadOffN: data[11],
    flags, gain, sampleRate, samples, byteCount,
    overflow: (flags & 1) !== 0, streaming: (flags & 2) !== 0,
  };
}
