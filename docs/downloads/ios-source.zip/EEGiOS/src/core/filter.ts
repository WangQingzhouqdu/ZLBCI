export interface FilterSettings {
  enabled: boolean;
  highPass: number;
  lowPass: number;
  order: number;
  notchHz: number;
  harmonics: number;
  notchQ: number;
}

/** Defaults from eeg_host.py, including its UI's two notch harmonics. */
export const DEFAULT_FILTER: FilterSettings = {
  enabled: true, highPass: 0.5, lowPass: 45, order: 4,
  notchHz: 50, harmonics: 2, notchQ: 30,
};

interface Section { b0: number; b1: number; b2: number; a1: number; a2: number }
type FilterType = 'bandpass' | 'highpass' | 'lowpass';

/** Streaming Butterworth + notch SOS, with independent double-precision channel state. */
export class EegFilter {
  description = '关闭';
  private sections: Section[] = [];
  private state: number[][][] = [];
  private initialized: boolean[] = [];

  constructor() { this.configure(250, DEFAULT_FILTER); }

  configure(sampleRate: number, settings: FilterSettings): void {
    if (!Number.isFinite(sampleRate) || sampleRate <= 0) throw new Error('采样率必须大于 0');
    if (![settings.highPass, settings.lowPass, settings.notchHz, settings.harmonics, settings.notchQ].every(Number.isFinite)) {
      throw new Error('滤波参数必须是有限数值');
    }
    if (!Number.isInteger(settings.order) || settings.order < 1 || settings.order > 8) throw new Error('滤波阶数应为 1–8');
    if (settings.notchQ <= 0) throw new Error('陷波 Q 值必须大于 0');
    const built: Section[] = [];
    const descriptions: string[] = [];
    if (settings.enabled) {
      const nyquist = sampleRate / 2;
      const hp = settings.highPass > 0 ? Math.min(settings.highPass, nyquist * 0.9) : 0;
      const lp = settings.lowPass > 0 && settings.lowPass < nyquist * 0.98 ? settings.lowPass : 0;
      if (hp > 0 && lp > hp) {
        built.push(...butterworth(sampleRate, settings.order, hp, lp, 'bandpass'));
        descriptions.push(`带通 ${hp}–${lp} Hz · ${settings.order} 阶`);
      } else if (hp > 0) {
        built.push(...butterworth(sampleRate, settings.order, hp, 0, 'highpass'));
        descriptions.push(`高通 ${hp} Hz · ${settings.order} 阶`);
      } else if (lp > 0) {
        built.push(...butterworth(sampleRate, settings.order, 0, lp, 'lowpass'));
        descriptions.push(`低通 ${lp} Hz · ${settings.order} 阶`);
      }
      if (settings.notchHz > 0) {
        const frequencies: number[] = [];
        const available = Math.ceil(nyquist * 0.95 / settings.notchHz) - 1;
        const count = Math.min(Math.max(1, Math.floor(settings.harmonics)), available);
        for (let k = 1; k <= count; k++) {
          const hz = settings.notchHz * k;
          built.push(notch(sampleRate, hz, settings.notchQ));
          frequencies.push(hz);
        }
        if (frequencies.length) descriptions.push(`陷波 ${frequencies.join('/')} Hz`);
      }
    }
    this.sections = built;
    this.description = settings.enabled ? descriptions.join(' + ') || '直通' : '关闭';
    this.reset();
  }

  reset(): void {
    this.state = [];
    this.initialized = [];
  }

  process(samples: number[][]): number[][] {
    if (!samples.length) return [];
    const channels = samples[0].length;
    if (samples.some((sample) => sample.length !== channels)) throw new Error('每个样本的通道数量必须一致');
    if (!this.sections.length) return samples.map((sample) => [...sample]);
    if (this.initialized.length !== channels) {
      this.initialized = Array(channels).fill(false);
      this.state = Array.from({ length: channels }, () => this.sections.map(() => [0, 0]));
    }
    return samples.map((sample) => sample.map((input, channel) => {
      if (!Number.isFinite(input)) {
        this.initialized[channel] = false;
        return NaN;
      }
      let value = input;
      if (!this.initialized[channel]) {
        let steadyInput = value;
        this.sections.forEach((section, index) => {
          const steadyOutput = steadyInput * (section.b0 + section.b1 + section.b2) / (1 + section.a1 + section.a2);
          this.state[channel][index][0] = steadyOutput - section.b0 * steadyInput;
          this.state[channel][index][1] = section.b2 * steadyInput - section.a2 * steadyOutput;
          steadyInput = steadyOutput;
        });
        this.initialized[channel] = true;
      }
      this.sections.forEach((section, index) => {
        const z = this.state[channel][index];
        const next = section.b0 * value + z[0];
        z[0] = section.b1 * value - section.a1 * next + z[1];
        z[1] = section.b2 * value - section.a2 * next;
        value = next;
      });
      return Math.fround(value);
    }));
  }
}

function notch(fs: number, hz: number, q: number): Section {
  const omega = 2 * Math.PI * hz / fs;
  const beta = Math.tan(omega / (2 * q));
  const gain = 1 / (1 + beta);
  const mid = -2 * gain * Math.cos(omega);
  return { b0: gain, b1: mid, b2: gain, a1: mid, a2: 2 * gain - 1 };
}

/** Analog Butterworth poles -> frequency transform -> prewarped bilinear transform. */
function butterworth(fs: number, order: number, hp: number, lp: number, type: FilterType): Section[] {
  const twoFs = 2 * fs;
  const warpedHp = hp > 0 ? twoFs * Math.tan(Math.PI * hp / fs) : 0;
  const warpedLp = lp > 0 ? twoFs * Math.tan(Math.PI * lp / fs) : 0;
  const analogPoles: Complex[] = [];
  for (let k = 0; k < order; k++) {
    const angle = Math.PI * (2 * k + 1 + order) / (2 * order);
    const prototype = new Complex(Math.cos(angle), Math.sin(angle));
    if (type === 'lowpass') analogPoles.push(prototype.scale(warpedLp));
    else if (type === 'highpass') analogPoles.push(new Complex(warpedHp).div(prototype));
    else {
      const half = prototype.scale((warpedLp - warpedHp) / 2);
      const delta = half.mul(half).sub(new Complex(warpedLp * warpedHp)).sqrt();
      analogPoles.push(half.add(delta), half.sub(delta));
    }
  }
  const poles = analogPoles.map((pole) => new Complex(twoFs).add(pole).div(new Complex(twoFs).sub(pole)));
  const pairs: [Complex, Complex | null][] = [];
  while (poles.length) {
    const pole = poles.shift()!;
    let other = -1;
    if (Math.abs(pole.im) < 1e-9) other = poles.findIndex((p) => Math.abs(p.im) < 1e-9);
    else {
      let closest = Infinity;
      poles.forEach((p, index) => {
        const distance = p.sub(pole.conjugate()).abs();
        if (distance < closest) { closest = distance; other = index; }
      });
    }
    pairs.push([pole, other >= 0 ? poles.splice(other, 1)[0] : null]);
  }
  const reference = type === 'lowpass' ? 0 : type === 'highpass' ? Math.PI : 2 * Math.atan(Math.sqrt(warpedHp * warpedLp) / twoFs);
  const z1 = new Complex(Math.cos(reference), -Math.sin(reference));
  const z2 = z1.mul(z1);
  pairs.sort(([p, q], [r, s]) => Math.max(p.abs(), q?.abs() ?? 0) - Math.max(r.abs(), s?.abs() ?? 0));
  return pairs.map(([p, q]) => {
    const a1 = -(p.re + (q?.re ?? 0));
    const a2 = q ? p.mul(q).re : 0;
    const b1 = type === 'lowpass' ? q ? 2 : 1 : type === 'highpass' ? q ? -2 : -1 : 0;
    const b2 = type === 'bandpass' ? -1 : q ? 1 : 0;
    const denominator = new Complex(1).add(z1.scale(a1)).add(z2.scale(a2));
    const numerator = new Complex(1).add(z1.scale(b1)).add(z2.scale(b2));
    const gain = denominator.abs() / numerator.abs();
    return { b0: gain, b1: b1 * gain, b2: b2 * gain, a1, a2 };
  });
}

class Complex {
  constructor(readonly re: number, readonly im = 0) {}
  add(p: Complex): Complex { return new Complex(this.re + p.re, this.im + p.im); }
  sub(p: Complex): Complex { return new Complex(this.re - p.re, this.im - p.im); }
  mul(p: Complex): Complex { return new Complex(this.re * p.re - this.im * p.im, this.re * p.im + this.im * p.re); }
  scale(value: number): Complex { return new Complex(this.re * value, this.im * value); }
  div(p: Complex): Complex {
    const d = p.re * p.re + p.im * p.im;
    return new Complex((this.re * p.re + this.im * p.im) / d, (this.im * p.re - this.re * p.im) / d);
  }
  abs(): number { return Math.hypot(this.re, this.im); }
  conjugate(): Complex { return new Complex(this.re, -this.im); }
  sqrt(): Complex {
    const magnitude = this.abs();
    return new Complex(Math.sqrt(Math.max(0, (magnitude + this.re) / 2)),
      (this.im < 0 ? -1 : 1) * Math.sqrt(Math.max(0, (magnitude - this.re) / 2)));
  }
}
