import type { EegPacket } from './protocol';

export interface PlotPoint { x: number; y: number }

/** Fixed-memory eight-channel ring. Plot coordinates cover the complete time window. */
export class WaveformBuffer {
  private capacity = 2;
  private channels: Float32Array[] = [];
  private writeIndex = 0;
  private filled = 0;

  constructor(capacity: number) { this.reset(capacity); }

  reset(capacity = this.capacity): void {
    if (!Number.isFinite(capacity) || capacity < 1) throw new Error('波形缓冲容量必须大于 0');
    this.capacity = Math.max(2, Math.floor(capacity));
    this.channels = Array.from({ length: 8 }, () => new Float32Array(this.capacity).fill(NaN));
    this.writeIndex = 0;
    this.filled = 0;
  }

  push(samples: number[][]): void {
    if (samples.some((sample) => sample.length !== 8)) throw new Error('波形数据必须包含 8 个通道');
    // A huge incoming batch must not spend time copying samples already outside the window.
    const start = Math.max(0, samples.length - this.capacity);
    for (let i = start; i < samples.length; i++) {
      for (let channel = 0; channel < 8; channel++) this.channels[channel][this.writeIndex] = samples[i][channel];
      this.writeIndex = (this.writeIndex + 1) % this.capacity;
    }
    this.filled = Math.min(this.capacity, this.filled + samples.length);
  }

  /** Add missing samples as a real blank span; never draw through a packet loss. */
  gap(count: number): void {
    if (!Number.isFinite(count) || count < 0) throw new Error('缺失样本数必须是非负数');
    const amount = Math.floor(count);
    if (amount >= this.capacity) {
      this.channels.forEach((channel) => channel.fill(NaN));
      this.writeIndex = 0;
      this.filled = this.capacity;
      return;
    }
    for (let i = 0; i < amount; i++) {
      for (const channel of this.channels) channel[this.writeIndex] = NaN;
      this.writeIndex = (this.writeIndex + 1) % this.capacity;
    }
    this.filled = Math.min(this.capacity, this.filled + amount);
  }

  /**
   * Read the ring directly, emitting each pixel bin's min/max in time order.
   * NaN points split finite runs, including gaps narrower than a pixel. No full
   * snapshot is allocated; ordinary output is at most two points per column.
   */
  plot(channel: number, columns: number): PlotPoint[] {
    if (!Number.isInteger(channel) || channel < 0 || channel >= 8) throw new Error('通道编号必须是 0–7');
    if (!Number.isFinite(columns) || columns < 1) return [];
    if (!this.filled) return [];
    const bins = Math.min(this.capacity, Math.max(1, Math.floor(columns)));
    const first = this.capacity - this.filled;
    const oldest = this.filled === this.capacity ? this.writeIndex : 0;
    const values = this.channels[channel];
    const at = (position: number) => values[(oldest + position - first) % this.capacity];
    const points: PlotPoint[] = [];
    const point = (position: number, y: number) => points.push({ x: position / (this.capacity - 1), y });
    let lastWasGap = false;
    for (let bin = Math.floor(first * bins / this.capacity); bin < bins; bin++) {
      const end = Math.min(this.capacity, Math.ceil((bin + 1) * this.capacity / bins));
      let i = Math.max(first, Math.ceil(bin * this.capacity / bins));
      while (i < end) {
        const value = at(i);
        if (!Number.isFinite(value)) {
          if (!lastWasGap) point(i, NaN);
          lastWasGap = true;
          i++;
          continue;
        }
        lastWasGap = false;
        let min = value;
        let max = value;
        let minIndex = i;
        let maxIndex = i;
        const start = i;
        i++;
        while (i < end && Number.isFinite(at(i))) {
          const next = at(i);
          if (next < min) { min = next; minIndex = i; }
          if (next > max) { max = next; maxIndex = i; }
          i++;
        }
        if (minIndex === maxIndex) {
          point(start, min);
          if (i - 1 !== start) point(i - 1, max);
        } else if (minIndex < maxIndex) {
          point(minIndex, min);
          point(maxIndex, max);
        } else {
          point(maxIndex, max);
          point(minIndex, min);
        }
      }
    }
    return points;
  }
}

export interface PacketAcceptance {
  accepted: boolean;
  gapSamples: number;
  lostPackets: number;
  discontinuity: boolean;
  /** Relative seconds since reset; keeps index resets/rate changes in separate contiguous segments. */
  firstSampleTime: number;
}

/** Track sample time independently of BLE notification arrival time. */
export class PacketTracker {
  private previous: { seq: number; index: number; count: number; rate: number; gain: number } | null = null;
  private nextTime = 0;

  reset(): void {
    this.previous = null;
    this.nextTime = 0;
  }

  accept(packet: EegPacket): PacketAcceptance {
    const rejected: PacketAcceptance = {
      accepted: false, gapSamples: 0, lostPackets: 0, discontinuity: false, firstSampleTime: this.nextTime,
    };
    if (!Number.isFinite(packet.sampleRate) || packet.sampleRate <= 0 ||
        !Number.isInteger(packet.sampleCount) || packet.sampleCount < 1) return rejected;
    let gapSamples = 0;
    let lostPackets = 0;
    let discontinuity = false;
    const previous = this.previous;
    if (previous) {
      const seqDistance = (packet.seq - previous.seq) & 0xffff;
      // BLE preserves order. Zero is a duplicate; the opposite half of the
      // sequence space is stale. Both checks remain valid at the 16-bit wrap.
      if (seqDistance === 0 || seqDistance >= 0x8000) return rejected;
      const expected = (previous.index + previous.count) >>> 0;
      const distance = (packet.sampleIndex - expected) >>> 0;
      const changed = previous.rate !== packet.sampleRate || previous.gain !== packet.gain;
      const indexReset = distance >= 0x10000000;
      if (changed || indexReset) {
        // Firmware START/reconfigure resets sidx but keeps seq. Treat as a new
        // segment, never a 2^32-sample gap. Caller should reset filters here.
        discontinuity = true;
      } else {
        gapSamples = distance;
        lostPackets = seqDistance - 1;
        discontinuity = gapSamples > 0 || lostPackets > 0;
        this.nextTime += gapSamples / packet.sampleRate;
      }
    }
    const firstSampleTime = this.nextTime;
    this.nextTime += packet.sampleCount / packet.sampleRate;
    this.previous = {
      seq: packet.seq, index: packet.sampleIndex, count: packet.sampleCount,
      rate: packet.sampleRate, gain: packet.gain,
    };
    return { accepted: true, gapSamples, lostPackets, discontinuity, firstSampleTime };
  }
}
