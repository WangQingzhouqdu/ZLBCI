import type { FilterSettings } from '../core/filter';
import type { DiscoveredDevice } from '../platform/ble';
import type { RecordingEntry } from '../platform/recordings';

export interface HardwareSettings {
  sampleRate: number;
  gain: number;
  mode: 'NORMAL' | 'SHORT' | 'TEST' | 'MVDD' | 'TEMP';
  srb1: boolean;
  bias: boolean;
  leadOff: boolean;
}

export const DEFAULT_HARDWARE: HardwareSettings = {
  sampleRate: 250, gain: 24, mode: 'NORMAL', srb1: true, bias: true, leadOff: false,
};

export interface SessionStats {
  packets: number;
  samples: number;
  lostSamples: number;
  lostPackets: number;
  invalidPackets: number;
  overflowPackets: number;
  packetRate: number;
  sampleRate: number;
  bytesPerSecond: number;
  elapsed: number;
}

export interface SessionSnapshot {
  revision: number;
  mode: 'hardware' | 'demo';
  connection: 'disconnected' | 'connecting' | 'connected';
  device: DiscoveredDevice | null;
  devices: DiscoveredDevice[];
  scanning: boolean;
  busy: boolean;
  streaming: boolean;
  starting: boolean;
  error: string | null;
  hardware: HardwareSettings;
  filter: FilterSettings;
  filterDescription: string;
  /** Zero means no sampling-rate/gain packet has yet been received from hardware. */
  actualFs: number;
  actualGain: number;
  leadOffP: number;
  leadOffN: number;
  deviceStatus: Record<string, unknown>;
  stats: SessionStats;
  windowSeconds: number;
  recording: boolean;
  recordedSamples: number;
  recordings: RecordingEntry[];
  logs: { time: string; message: string }[];
}
