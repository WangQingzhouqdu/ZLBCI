import { EegFilter, DEFAULT_FILTER, type FilterSettings } from '../core/filter';
import { PacketTracker, WaveformBuffer } from '../core/buffer';
import { parsePacket, type EegPacket } from '../core/protocol';
import type { DiscoveredDevice } from '../platform/ble';
import type { CsvRecorder, RecordingEntry, RecordingMode } from '../platform/recordings';
import { DEFAULT_HARDWARE, type HardwareSettings, type SessionSnapshot, type SessionStats } from './types';

export { DEFAULT_HARDWARE } from './types';
export type { HardwareSettings, SessionSnapshot } from './types';

interface TransportCallbacks {
  onDevice(device: DiscoveredDevice): void;
  onData(data: Uint8Array): void;
  onStatus(status: Record<string, unknown>): void;
  onLog(message: string): void;
  onDisconnect(): void;
  onScanning(scanning: boolean): void;
}

interface Transport {
  scan(onlyEeg: boolean): Promise<void>;
  connect(device: DiscoveredDevice): Promise<void>;
  disconnect(): Promise<void>;
  send(command: string): Promise<void>;
  dispose(): void | Promise<void>;
}

/** Native modules load only on init; the same state machine can be tested in Node. */
export interface SessionDependencies {
  createTransport(callbacks: TransportCallbacks): Transport;
  createRecorder(): Pick<CsvRecorder, 'active' | 'sampleCount' | 'start' | 'append' | 'stop'>;
  listRecordings(): RecordingEntry[];
  shareRecording(entry: RecordingEntry): Promise<void>;
  subscribeAppState(listener: (state: string) => void): () => void;
  setKeepAwake(enabled: boolean): Promise<void>;
  now?: () => number;
  commandDelayMs?: number;
}

const stats = (): SessionStats => ({
  packets: 0, samples: 0, lostSamples: 0, lostPackets: 0, invalidPackets: 0,
  overflowPackets: 0, packetRate: 0, sampleRate: 0, bytesPerSecond: 0, elapsed: 0,
});
const messageOf = (error: unknown) => error instanceof Error ? error.message : String(error);
const delay = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const DEMO_DEVICE: DiscoveredDevice = { id: 'demo', name: '演示 · 合成脑电', rssi: 0 };
const HARDWARE_RATES = [250, 500, 1000, 2000, 4000];
const HARDWARE_GAINS = [1, 2, 4, 6, 8, 12, 24];

async function nativeDependencies(): Promise<SessionDependencies> {
  const [ble, files, native, awake] = await Promise.all([
    import('../platform/ble'), import('../platform/recordings'), import('react-native'), import('expo-keep-awake'),
  ]);
  return {
    createTransport: callbacks => new ble.BleTransport(callbacks),
    createRecorder: () => new files.CsvRecorder(),
    listRecordings: files.listRecordings,
    shareRecording: files.shareRecording,
    subscribeAppState(listener) {
      const sub = native.AppState.addEventListener('change', listener);
      return () => sub.remove();
    },
    async setKeepAwake(enabled) {
      if (native.Platform.OS === 'web') return;
      if (enabled) await awake.activateKeepAwakeAsync('eeg-stream');
      else await awake.deactivateKeepAwake('eeg-stream');
    },
  };
}

export class EegSession {
  private state: SessionSnapshot;
  private snapshot: SessionSnapshot;
  private readonly listeners = new Set<() => void>();
  private readonly filter = new EegFilter();
  private readonly tracker = new PacketTracker();
  private readonly raw = new WaveformBuffer(2500);
  private readonly filtered = new WaveformBuffer(2500);
  private deps?: SessionDependencies;
  private ready?: Promise<void>;
  private recorder?: ReturnType<SessionDependencies['createRecorder']>;
  private transport?: Transport;
  private unsubscribeAppState?: () => void;
  private timer?: ReturnType<typeof setInterval>;
  private demoTimer?: ReturnType<typeof setInterval>;
  private disposed = false;
  private generation = 0;
  private operationEpoch = 0;
  private dirty = false;
  private accepting = false;
  private lastPacketAt = 0;
  private rateStart = 0;
  private ratePackets = 0;
  private rateSamples = 0;
  private rateBytes = 0;
  private demoIndex = 0;
  private demoSequence = 0;
  private streamFs = 0;
  private streamGain = 0;
  private awakeWanted = false;
  private awakeQueue: Promise<void> = Promise.resolve();
  private appState = 'active';

  constructor(dependencies?: SessionDependencies) {
    this.deps = dependencies;
    this.filter.configure(DEFAULT_HARDWARE.sampleRate, { ...DEFAULT_FILTER });
    this.state = {
      revision: 0, mode: 'hardware', connection: 'disconnected', device: null, devices: [],
      scanning: false, busy: false, streaming: false, starting: false, error: null,
      hardware: { ...DEFAULT_HARDWARE }, filter: { ...DEFAULT_FILTER }, filterDescription: this.filter.description,
      actualFs: 0, actualGain: 0, leadOffP: 0, leadOffN: 0, deviceStatus: {}, stats: stats(),
      windowSeconds: 10, recording: false, recordedSamples: 0, recordings: [], logs: [],
    };
    this.snapshot = this.state;
  }

  getSnapshot = (): SessionSnapshot => this.snapshot;
  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  };

  init(): void { void this.ensureReady().catch(error => this.setError(messageOf(error))); }

  private ensureReady(): Promise<void> {
    if (this.disposed) return Promise.reject(new Error('采集会话已关闭'));
    if (!this.ready) {
      this.ready = (async () => {
        this.deps ??= await nativeDependencies();
        if (this.disposed) throw new Error('采集会话已关闭');
        this.recorder = this.deps.createRecorder();
        this.unsubscribeAppState = this.deps.subscribeAppState(next => this.onAppState(next));
        this.rateStart = this.now();
        this.timer = setInterval(() => this.tick(), 100);
        this.refreshRecordings();
      })().catch(error => { this.ready = undefined; throw error; });
    }
    return this.ready;
  }

  private now(): number { return this.deps?.now?.() ?? Date.now(); }
  private patch(patch: Partial<SessionSnapshot>, immediate = false): void {
    this.state = { ...this.state, ...patch };
    this.dirty = true;
    if (immediate) this.emit();
  }
  private emit(): void {
    if (!this.dirty || this.disposed) return;
    this.dirty = false;
    this.state = { ...this.state, revision: this.state.revision + 1 };
    this.snapshot = this.state;
    for (const listener of this.listeners) listener();
  }
  private log(message: string): void {
    this.patch({ logs: [...this.state.logs.slice(-99), { time: new Date().toLocaleTimeString('zh-CN', { hour12: false }), message: message.slice(0, 2000) }] });
  }
  setError(message: string | null): void {
    if (message) this.log(message);
    this.patch({ error: message }, true);
  }

  private async withBusy(action: (guard: () => void) => Promise<void>): Promise<void> {
    const epoch = this.operationEpoch;
    const guard = () => {
      if (this.disposed || epoch !== this.operationEpoch) throw new Error('操作已取消');
    };
    await this.ensureReady();
    guard();
    if (this.state.busy) throw new Error('正在处理设备操作，请稍候');
    this.patch({ busy: true, error: null }, true);
    try { await action(guard); }
    catch (error) {
      if (!this.transport && this.state.mode === 'hardware') {
        this.patch({ connection: 'disconnected', device: null, actualFs: 0, actualGain: 0 });
      }
      throw error;
    }
    finally { this.patch({ busy: false }, true); }
  }

  private makeTransport(): Transport {
    const generation = ++this.generation;
    const current = () => generation === this.generation && !this.disposed;
    const transport = this.deps!.createTransport({
      onDevice: device => {
        if (!current()) return;
        const found = this.state.devices.findIndex(item => item.id === device.id);
        const devices = this.state.devices.slice();
        if (found >= 0) devices[found] = device;
        else if (devices.length < 100) devices.push(device);
        this.patch({ devices });
      },
      onData: data => {
        if (!current() || !this.accepting || this.state.mode !== 'hardware') return;
        try {
          const packet = parsePacket(data);
          if (!packet) this.patch({ stats: { ...this.state.stats, invalidPackets: this.state.stats.invalidPackets + 1 } });
          else this.ingest(packet);
        } catch (error) { this.failStream(`数据处理失败：${messageOf(error)}`); }
      },
      onStatus: status => {
        if (!current()) return;
        // Acknowledgements can be stale; only accepted data packets set streaming/rates.
        this.patch({ deviceStatus: { ...this.state.deviceStatus, ...status } });
      },
      onLog: message => { if (current()) this.log(message); },
      onDisconnect: () => {
        if (!current()) return;
        this.operationEpoch++;
        this.haltLocal();
        this.patch({ connection: 'disconnected', scanning: false, device: null, actualFs: 0, actualGain: 0 });
        this.log('蓝牙连接已断开；采集停止，记录已结束');
        this.emit();
      },
      onScanning: scanning => { if (current()) this.patch({ scanning }); },
    });
    this.transport = transport;
    return transport;
  }

  private async releaseTransport(): Promise<void> {
    ++this.generation;
    const transport = this.transport;
    this.transport = undefined;
    if (transport) {
      try { await transport.disconnect(); }
      finally { await transport.dispose(); }
    }
  }

  async scan(onlyEeg: boolean): Promise<void> {
    await this.withBusy(async guard => {
      if (this.state.connection !== 'disconnected') throw new Error('请先断开当前设备，再扫描');
      await this.releaseTransport();
      guard();
      this.patch({ mode: 'hardware', devices: [], deviceStatus: {} });
      const transport = this.makeTransport();
      await transport.scan(onlyEeg);
      guard();
    });
  }

  async connect(device: DiscoveredDevice): Promise<void> {
    await this.withBusy(async guard => {
      this.haltLocal();
      await this.releaseTransport();
      guard();
      this.resetStream();
      this.patch({ mode: 'hardware', connection: 'connecting', device, actualFs: 0, actualGain: 0, deviceStatus: {}, scanning: false });
      const transport = this.makeTransport();
      try {
        await transport.connect(device);
        guard();
        this.patch({ connection: 'connected' });
        await this.sendHardware(this.state.hardware, guard);
        guard();
        this.log(`已连接 ${device.name || device.id}；设置命令已发送，实际采样率/增益以数据包为准`);
      } catch (error) {
        await this.releaseTransport().catch(() => {});
        this.patch({ connection: 'disconnected', device: null, actualFs: 0, actualGain: 0 });
        throw error;
      }
    });
  }

  async disconnect(): Promise<void> {
    ++this.operationEpoch;
    this.haltLocal();
    const old = this.transport;
    ++this.generation;
    this.transport = undefined;
    this.patch({ connection: 'disconnected', scanning: false, device: null, actualFs: 0, actualGain: 0 }, true);
    if (old) {
      try { await old.send('STOP'); } catch { /* Closing the link is the fallback. */ }
      try { await old.disconnect(); }
      finally { await old.dispose(); }
    }
    this.log('已断开；CSV 记录保留在本机');
    this.emit();
  }

  async useDemo(): Promise<void> {
    await this.withBusy(async guard => {
      this.haltLocal();
      if (this.transport && this.state.connection === 'connected') {
        try { await this.transport.send('STOP'); } catch { /* Link closes below. */ }
      }
      await this.releaseTransport();
      guard();
      this.resetStream();
      this.patch({ mode: 'demo', connection: 'connected', device: DEMO_DEVICE, scanning: false,
        actualFs: this.state.hardware.sampleRate, actualGain: this.state.hardware.gain,
        deviceStatus: { demo: true, source: '本机合成信号，不来自脑电硬件' } });
      this.log('演示设备已就绪；点击开始采集，CSV 将明确标记 DEMO');
    });
  }

  async start(): Promise<void> {
    await this.withBusy(async guard => {
      if (this.appState === 'background') throw new Error('请回到前台后再开始采集');
      if (this.state.connection !== 'connected') throw new Error('请先连接脑电设备或开启演示');
      if (this.accepting) return;
      this.closeRecording();
      this.resetStream();
      this.accepting = true;
      this.lastPacketAt = this.now();
      this.patch({ starting: true, streaming: false });
      try {
        if (this.state.mode === 'demo') {
          this.log(this.state.hardware.mode === 'MVDD' || this.state.hardware.mode === 'TEMP'
            ? `演示 ${this.state.hardware.mode} 使用合成脑电，不模拟温度/电源物理量`
            : '开始演示采集 · 数据来自本机合成信号');
          this.demoTimer = setInterval(() => this.demoTick(), 40);
        } else {
          await this.transport!.send('START');
          guard();
          this.log('START 已发送，等待首个有效数据包（最多 5 秒）');
        }
      } catch (error) {
        this.haltLocal();
        await this.releaseTransport().catch(() => {});
        this.patch({ connection: 'disconnected', device: null });
        throw error;
      }
    });
  }

  async pause(): Promise<void> {
    await this.ensureReady();
    ++this.operationEpoch;
    this.haltLocal();
    try {
      if (this.state.mode === 'hardware' && this.state.connection === 'connected') await this.transport!.send('STOP');
      this.log('已暂停采集，当前记录已保存');
    } catch (error) {
      await this.releaseTransport().catch(() => {});
      this.patch({ connection: 'disconnected', device: null });
      throw new Error(`停止命令失败，已断开连接：${messageOf(error)}`);
    } finally { this.emit(); }
  }

  private validateHardware(settings: HardwareSettings): void {
    if (!HARDWARE_RATES.includes(settings.sampleRate) || !HARDWARE_GAINS.includes(settings.gain)
      || !['NORMAL', 'SHORT', 'TEST', 'MVDD', 'TEMP'].includes(settings.mode)
      || [settings.srb1, settings.bias, settings.leadOff].some(value => typeof value !== 'boolean')) {
      throw new Error('采集参数无效（采样率支持 250–4000 Hz）');
    }
  }

  private async sendHardware(settings: HardwareSettings, guard: () => void): Promise<void> {
    const commands = ['STOP', `SR:${settings.sampleRate}`, `GAIN:${settings.gain}`, `MODE:${settings.mode}`,
      `SRB1:${Number(settings.srb1)}`, `BIAS:${Number(settings.bias)}`, `LOFF:${Number(settings.leadOff)}`];
    for (const command of commands) {
      guard();
      if (!this.transport) throw new Error('设备连接已关闭');
      await this.transport.send(command);
      await delay(this.deps?.commandDelayMs ?? 150);
    }
    guard();
  }

  async applyHardware(settings: HardwareSettings): Promise<void> {
    this.validateHardware(settings);
    await this.withBusy(async guard => {
      this.haltLocal();
      this.patch({ hardware: { ...settings } });
      this.resetStream();
      if (this.state.mode === 'hardware' && this.state.connection === 'connected') {
        try { await this.sendHardware(settings, guard); }
        catch (error) {
          await this.releaseTransport().catch(() => {});
          this.patch({ connection: 'disconnected', device: null, actualFs: 0, actualGain: 0 });
          throw new Error(`配置未完整发送，已断开连接；重新连接后重试：${messageOf(error)}`);
        }
        this.log('配置命令已逐项发送；实际采样率/增益以接收的数据为准，请重新开始采集');
      } else if (this.state.mode === 'demo') {
        this.patch({ actualFs: settings.sampleRate, actualGain: settings.gain });
        this.log('演示采集配置已更新，请重新开始采集');
      } else this.log('已保存待发送配置；连接设备后自动发送');
    });
  }

  applyFilter(settings: FilterSettings): void {
    // Validate with a separate filter before changing recording or live state.
    const validation = new EegFilter();
    validation.configure(this.streamFs || this.state.hardware.sampleRate, settings);
    this.closeRecording();
    this.filter.configure(this.streamFs || this.state.hardware.sampleRate, settings);
    this.raw.reset();
    this.filtered.reset();
    this.patch({ filter: { ...settings }, filterDescription: this.filter.description });
    this.log('滤波设置已更新，波形历史已清空；此前记录已结束');
    this.emit();
  }

  async startRecording(mode: RecordingMode): Promise<void> {
    await this.ensureReady();
    if (!['both', 'raw', 'filt'].includes(mode)) throw new Error('无效的记录模式');
    if (!this.accepting || !this.state.streaming || this.state.starting) throw new Error('收到有效采集数据后才能开始记录');
    if (this.recorder!.active) return;
    this.recorder!.start({
      demo: this.state.mode === 'demo', device: this.state.device?.name || this.state.device?.id || 'EEG',
      sampleRate: this.state.actualFs, gain: this.state.actualGain, filter: this.state.filterDescription,
      requestedHardware: { ...this.state.hardware }, deviceStatus: { ...this.state.deviceStatus },
    }, mode);
    this.patch({ recording: true, recordedSamples: 0 }, true);
    this.log(this.state.mode === 'demo' ? '开始记录 DEMO 合成信号 CSV' : '开始记录硬件脑电 CSV');
  }

  stopRecording(): void { this.closeRecording(); this.emit(); }

  private closeRecording(): void {
    if (!this.recorder?.active) {
      if (this.state.recording) this.patch({ recording: false });
      return;
    }
    try {
      const entry = this.recorder.stop();
      if (entry) this.log(`记录已保存：${entry.name}（${entry.samples} 个样本）`);
      this.refreshRecordings();
    } catch (error) {
      const message = `CSV 保存失败：${messageOf(error)}`;
      this.log(message);
      this.patch({ error: message });
    } finally { this.patch({ recording: false, recordedSamples: this.recorder.sampleCount }); }
  }

  refreshRecordings(): void {
    if (!this.deps) return;
    try { this.patch({ recordings: this.deps.listRecordings() }, true); }
    catch (error) { this.setError(`读取记录列表失败：${messageOf(error)}`); }
  }

  async share(entry: RecordingEntry): Promise<void> {
    await this.ensureReady();
    // The iOS share sheet can take the app out of the foreground.
    if (this.accepting) await this.pause();
    else this.closeRecording();
    await this.deps!.shareRecording(entry);
  }

  setWindow(seconds: number): void {
    if (!Number.isFinite(seconds) || seconds < 1 || seconds > 20) throw new Error('显示时间窗需为 1–20 秒');
    const capacity = Math.max(2, Math.ceil((this.streamFs || this.state.hardware.sampleRate) * seconds));
    this.raw.reset(capacity);
    this.filtered.reset(capacity);
    this.patch({ windowSeconds: seconds }, true);
  }

  plot(channel: number, filtered: boolean, columns: number): { x: number; y: number }[] {
    return (filtered ? this.filtered : this.raw).plot(channel, columns);
  }

  private resetBuffers(fs: number): void {
    const capacity = Math.ceil(fs * this.state.windowSeconds);
    this.raw.reset(capacity);
    this.filtered.reset(capacity);
    this.filter.configure(fs, this.state.filter);
    this.patch({ filterDescription: this.filter.description });
  }

  private resetStream(): void {
    this.tracker.reset();
    this.streamFs = 0;
    this.streamGain = 0;
    this.demoIndex = 0;
    this.demoSequence = 0;
    this.ratePackets = this.rateSamples = this.rateBytes = 0;
    this.rateStart = this.now();
    this.resetBuffers(this.state.hardware.sampleRate);
    this.patch({ stats: stats(), leadOffP: 0, leadOffN: 0, streaming: false, starting: false });
  }

  private ingest(packet: EegPacket): void {
    if (!this.accepting) return;
    // Reject duplicate/stale packets before allowing their headers to change live state.
    const tracked = this.tracker.accept(packet);
    if (!tracked.accepted) return;
    const parametersChanged = !!this.streamFs && (packet.sampleRate !== this.streamFs || packet.gain !== this.streamGain);
    if (parametersChanged) {
      this.closeRecording();
      this.resetBuffers(packet.sampleRate);
      this.log('数据包采样率/增益发生变化；原记录已保存，滤波与波形重新开始');
    } else if (!this.streamFs) this.resetBuffers(packet.sampleRate);
    this.streamFs = packet.sampleRate;
    this.streamGain = packet.gain;
    this.lastPacketAt = this.now();
    if (tracked.discontinuity && tracked.gapSamples === 0 && tracked.lostPackets === 0 && !parametersChanged) {
      this.closeRecording();
      this.raw.reset();
      this.filtered.reset();
      this.filter.reset();
      this.log('设备样本序号发生跳变；记录已结束，时间线重新开始');
    } else if (tracked.gapSamples > 0 || tracked.lostPackets > 0) {
      this.raw.gap(tracked.gapSamples);
      this.filtered.gap(tracked.gapSamples);
      this.filter.reset();
    }
    const filtered = this.filter.process(packet.samples);
    this.raw.push(packet.samples);
    this.filtered.push(filtered);
    if (this.recorder?.active) {
      try { this.recorder.append(packet.samples, filtered, packet.sampleIndex, tracked.firstSampleTime, packet.sampleRate); }
      catch (error) {
        this.closeRecording();
        this.refreshRecordings();
        const message = `CSV 写入失败，已结束当前记录：${messageOf(error)}`;
        this.log(message);
        this.patch({ error: message });
      }
    }
    const previous = this.state.stats;
    this.ratePackets++;
    this.rateSamples += packet.sampleCount;
    this.rateBytes += packet.byteCount;
    this.patch({
      starting: false, streaming: packet.streaming, actualFs: packet.sampleRate, actualGain: packet.gain,
      leadOffP: packet.leadOffP, leadOffN: packet.leadOffN,
      recordedSamples: this.recorder?.sampleCount ?? this.state.recordedSamples,
      stats: { ...previous, packets: previous.packets + 1, samples: previous.samples + packet.sampleCount,
        lostSamples: previous.lostSamples + tracked.gapSamples, lostPackets: previous.lostPackets + tracked.lostPackets,
        overflowPackets: previous.overflowPackets + Number(packet.overflow),
        elapsed: previous.elapsed + (packet.sampleCount + tracked.gapSamples) / packet.sampleRate },
    });
    this.setAwake(packet.streaming);
    if (!packet.streaming) {
      this.haltLocal();
      this.log('设备数据包报告采集停止；当前记录已保存');
    }
  }

  private setAwake(enabled: boolean): void {
    if (this.awakeWanted === enabled) return;
    this.awakeWanted = enabled;
    // Serialize native calls so a slow activate cannot re-enable the lock after STOP.
    this.awakeQueue = this.awakeQueue.then(async () => { await this.deps?.setKeepAwake(enabled); })
      .catch(error => { if (!this.disposed) this.log(`屏幕常亮设置失败：${messageOf(error)}`); });
  }

  private haltLocal(): void {
    this.accepting = false;
    if (this.demoTimer) clearInterval(this.demoTimer);
    this.demoTimer = undefined;
    this.closeRecording();
    this.setAwake(false);
    this.patch({ streaming: false, starting: false,
      stats: { ...this.state.stats, packetRate: 0, sampleRate: 0, bytesPerSecond: 0 } });
    this.ratePackets = this.rateSamples = this.rateBytes = 0;
  }

  private failStream(message: string): void {
    this.haltLocal();
    this.setError(message);
    if (this.state.mode === 'hardware' && this.transport) {
      const transport = this.transport;
      void transport.send('STOP').catch(async error => {
        if (transport !== this.transport) return;
        await this.releaseTransport().catch(() => {});
        this.patch({ connection: 'disconnected', device: null });
        this.setError(`${message}；停止命令失败，已断开：${messageOf(error)}`);
      });
    }
  }

  private tick(): void {
    if (this.disposed) return;
    const now = this.now();
    if (this.accepting && this.state.mode === 'hardware') {
      const timeout = this.state.starting ? 5000 : 2000;
      if (now - this.lastPacketAt >= timeout) {
        this.failStream(this.state.starting ? '5 秒内未收到有效首包；已暂停，请检查设备后重试' : '数据已中断 2 秒；采集暂停，当前记录已保存');
      }
    }
    const duration = (now - this.rateStart) / 1000;
    if (duration >= 1) {
      this.patch({ stats: { ...this.state.stats, packetRate: this.ratePackets / duration,
        sampleRate: this.rateSamples / duration, bytesPerSecond: this.rateBytes / duration } });
      this.ratePackets = this.rateSamples = this.rateBytes = 0;
      this.rateStart = now;
    }
    this.emit();
  }

  private demoTick(): void {
    if (!this.accepting || this.state.mode !== 'demo') return;
    try {
      const fs = this.state.hardware.sampleRate;
      const count = Math.max(1, Math.round(fs * 0.04));
      const gaussian = () => Math.sqrt(-2 * Math.log(Math.max(Number.EPSILON, Math.random()))) * Math.cos(2 * Math.PI * Math.random());
      const samples = Array.from({ length: count }, (_, sample) => Array.from({ length: 8 }, (_, channel) => {
        const time = (this.demoIndex + sample) / fs;
        if (this.state.hardware.mode === 'SHORT') return 0.4 * gaussian();
        if (this.state.hardware.mode === 'TEST') return (Math.sin(2 * Math.PI * 0.9765625 * time) >= 0 ? 1875 : -1875) + 2 * gaussian();
        return 25 * Math.sin(2 * Math.PI * (9.5 + channel * 0.3) * time + channel * 0.5)
          + 7 * Math.sin(2 * Math.PI * 20 * time) + 9 * Math.sin(2 * Math.PI * 50 * time)
          + 15 * Math.sin(2 * Math.PI * 0.25 * time) + 3 * gaussian();
      }));
      this.ingest({ seq: this.demoSequence, channelCount: 8, sampleCount: count, sampleIndex: this.demoIndex,
        leadOffP: 0, leadOffN: 0, flags: 2, gain: this.state.hardware.gain, sampleRate: fs,
        samples, byteCount: 15 + count * 24, overflow: false, streaming: true });
      this.demoSequence = (this.demoSequence + 1) & 0xffff;
      this.demoIndex = (this.demoIndex + count) >>> 0;
    } catch (error) { this.failStream(`演示采集失败：${messageOf(error)}`); }
  }

  private onAppState(next: string): void {
    this.appState = next;
    // iOS permissions/control-center/share-sheet can briefly be inactive. Stop at background.
    if (next !== 'background' || (!this.accepting && !this.state.recording && !this.state.busy)) return;
    ++this.operationEpoch;
    this.haltLocal();
    this.log('应用已进入后台，采集暂停、记录已结束；返回前台后需手动重新开始');
    this.emit();
    if (this.transport && this.state.mode === 'hardware') {
      const transport = this.transport;
      void transport.send('STOP').catch(async () => {
        if (transport !== this.transport) return;
        await this.releaseTransport().catch(() => {});
        this.patch({ connection: 'disconnected', device: null }, true);
      });
    }
  }

  dispose(): void {
    if (this.disposed) return;
    ++this.operationEpoch;
    this.haltLocal();
    this.unsubscribeAppState?.();
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
    this.listeners.clear();
    this.disposed = true;
    const transport = this.transport;
    ++this.generation;
    this.transport = undefined;
    if (transport) {
      void transport.send('STOP').catch(() => {})
        .then(() => transport.disconnect()).finally(() => transport.dispose()).catch(() => {});
    }
  }
}

export const session = new EegSession();
