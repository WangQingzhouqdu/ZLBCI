# 脑电采集 · Android 公开源码包

这是资料中 v1.0.0 Android 客户端的精简源码，适用于 ESP32-S3 + ADS1299 八通道 BLE 采集协议。支持 Android 8.0 及以上。应用可以显示八通道波形、设置采集参数与滤波、记录并导出 CSV，也提供合成信号演示。

## 构建

使用 Android Studio 打开本目录，按工程 Gradle 配置准备工具链和 Android SDK。在 Windows 工程目录执行：

```powershell
.\gradlew.bat assembleDebug testDebugUnitTest lintDebug
```

macOS / Linux 可先 `chmod +x gradlew`，再执行 `./gradlew assembleDebug testDebugUnitTest lintDebug`。

调试 APK 位于 `app/build/outputs/apk/debug/`。此公开包移除了原工程的本机发行签名加载逻辑；发行构建需自行配置签名，未配置时不能把 unsigned APK 当作发行安装包。已有应用的覆盖升级需相同签名和包名，并提高 versionCode。

## 操作

1. 采集板上电并断开其他客户端；在设备页扫描，按系统提示允许蓝牙权限。Android 11 及以下扫描还需定位权限和系统定位。
2. 连接后先选择 250 SPS、24 倍增益，应用参数，在波形页开始采集。
3. 在记录页选择原始、滤波或两者，开始记录；停止并保存后通过系统文件选择器导出。
4. 没有板卡时可以开启模拟设备。模拟数据不表示真实生理测量。

CSV 的 `time_s` 是记录相对秒数，通道单位为 µV。数据默认保存在应用私有目录，卸载前应导出。修改采集或滤波参数会结束当前文件。Android UI 包含 8000/16000 SPS 选项，但实际允许范围与吞吐需由配套固件和链路共同确认。

## 协议与验证边界

服务 UUID：`6e400001-b5a3-f393-e0a9-e50e24dcca9e`；RX/TX/STATUS 使用 `6e400002/3/4` 同后缀。

提供的测试源码覆盖协议、滤波与记录逻辑；本次文档整理未重新执行应用编译或测试。原资料说明真实板卡 BLE 联调仍待完成，实际使用需验证连接、参数、持续吞吐和电极信号。

## 公开包调整

只包含源码、资源、测试、Gradle 配置与 wrapper；未包含签名材料、凭据、本机路径配置、构建缓存、验证日志或采集记录。除了发行签名加载逻辑和本 README / .gitignore，业务源码保持资料原样。
