plugins { id("com.android.application") }

android {
    namespace = "com.eeg.mobile"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.eeg.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    // Public source package: release signing must be configured locally by the builder.
    buildTypes.getByName("release") { isMinifyEnabled = false }
}
dependencies { testImplementation("junit:junit:4.13.2") }
