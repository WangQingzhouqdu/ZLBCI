package com.eeg.mobile.core

/** One firmware notification. Samples are sample-major, in microvolts. */
data class EegPacket(
    val seq: Int,
    val channelCount: Int,
    val sampleCount: Int,
    val sampleIndex: Long,
    val leadOffP: Int,
    val leadOffN: Int,
    val flags: Int,
    val gain: Int,
    val sampleRate: Int,
    val samples: Array<FloatArray>,
    val byteCount: Int
) {
    val overflow: Boolean get() = flags and 0x01 != 0
    val streaming: Boolean get() = flags and 0x02 != 0
}

/** ESP32-S3 / ADS1299 wire protocol, matching eeg_host.py. */
object EegProtocol {
    const val SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
    const val RX_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
    const val TX_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
    const val STATUS_UUID = "6e400004-b5a3-f393-e0a9-e50e24dcca9e"
    val GAINS = intArrayOf(1, 2, 4, 6, 8, 12, 24)
    val SAMPLE_RATES = intArrayOf(250, 500, 1000, 2000, 4000, 8000, 16000)

    private val crcTable = IntArray(256) { input ->
        var c = input
        repeat(8) { c = if (c and 0x80 != 0) ((c shl 1) xor 0x07) and 255 else (c shl 1) and 255 }
        c
    }

    fun crc8(data: ByteArray, length: Int = data.size): Int {
        require(length in 0..data.size) { "CRC length exceeds buffer" }
        var crc = 0
        for (i in 0 until length) crc = crcTable[crc xor (data[i].toInt() and 255)]
        return crc
    }

    fun parse(data: ByteArray): EegPacket? {
        if (data.size < 15) return null
        fun u8(i: Int): Int = data[i].toInt() and 255
        if (u8(0) != 0xa5 || u8(1) != 0x5a) return null
        val channels = u8(4)
        val count = u8(5)
        if (channels != 8 || count == 0) return null
        val needed = 14 + count * channels * 3 + 1
        if (data.size < needed || crc8(data, needed - 1) != u8(needed - 1)) return null
        val flags = u8(12)
        val gain = GAINS.getOrElse(u8(13) and 7) { 24 }
        val rate = SAMPLE_RATES.getOrElse((flags ushr 4) and 15) { 250 }
        // Preserve the desktop's float32 conversion and scaling convention.
        val scale = (4.5 / (gain * 8388608.0) * 1e6).toFloat()
        var offset = 14
        val samples = Array(count) {
            FloatArray(channels) {
                var raw = (u8(offset) shl 16) or (u8(offset + 1) shl 8) or u8(offset + 2)
                if (raw and 0x800000 != 0) raw -= 0x1000000
                offset += 3
                raw.toFloat() * scale
            }
        }
        var sampleIndex = 0L
        for (i in 0..3) sampleIndex = sampleIndex or (u8(6 + i).toLong() shl (8 * i))
        return EegPacket(
            u8(2) or (u8(3) shl 8), channels, count, sampleIndex,
            u8(10), u8(11), flags, gain, rate, samples, needed
        )
    }
}
