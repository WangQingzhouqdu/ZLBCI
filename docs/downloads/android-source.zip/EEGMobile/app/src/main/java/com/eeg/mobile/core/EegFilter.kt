package com.eeg.mobile.core

import kotlin.math.*

data class FilterSettings(
    val enabled: Boolean = true,
    val highPass: Double = 0.5,
    val lowPass: Double = 40.0,
    val order: Int = 4,
    val notchHz: Int = 50,
    val harmonics: Int = 3,
    val notchQ: Double = 30.0
)

/**
 * Streaming double-precision, transposed direct-form II SOS filter.
 * Butterworth poles are transformed from the analog prototype and bilinear
 * transformed with prewarping, as scipy.signal.butter does. A bandpass of
 * order N has 2N poles. Notches use scipy.signal.iirnotch's bandwidth formula.
 * Each channel starts at the steady state for its first sample.
 */
class EegFilter {
    var description: String = "关闭"
        private set

    private data class Section(val b0: Double, val b1: Double, val b2: Double, val a1: Double, val a2: Double)
    private var sections = emptyList<Section>()
    private var state = emptyArray<Array<DoubleArray>>()
    private var initialized = BooleanArray(0)

    init { configure(250, FilterSettings()) }

    fun configure(sampleRate: Int, settings: FilterSettings) {
        require(sampleRate > 0) { "采样率必须大于 0" }
        require(settings.highPass.isFinite() && settings.lowPass.isFinite()) { "滤波频率无效" }
        require(settings.order in 1..8) { "滤波阶数应为 1–8" }
        require(settings.notchQ.isFinite() && settings.notchQ > 0) { "陷波 Q 值必须大于 0" }
        sections = emptyList()
        if (!settings.enabled) {
            description = "关闭"
            reset()
            return
        }
        val nyquist = sampleRate / 2.0
        val hp = if (settings.highPass > 0) min(settings.highPass, nyquist * .9) else 0.0
        val lp = if (settings.lowPass > 0 && settings.lowPass < nyquist * .98) settings.lowPass else 0.0
        val built = mutableListOf<Section>()
        val descriptions = mutableListOf<String>()
        when {
            hp > 0 && lp > hp -> {
                built += butterworth(sampleRate, settings.order, hp, lp, "bandpass")
                descriptions += "带通 ${format(hp)}–${format(lp)} Hz · ${settings.order} 阶"
            }
            hp > 0 -> {
                built += butterworth(sampleRate, settings.order, hp, 0.0, "highpass")
                descriptions += "高通 ${format(hp)} Hz · ${settings.order} 阶"
            }
            lp > 0 -> {
                built += butterworth(sampleRate, settings.order, 0.0, lp, "lowpass")
                descriptions += "低通 ${format(lp)} Hz · ${settings.order} 阶"
            }
        }
        if (settings.notchHz > 0) {
            val frequencies = mutableListOf<Int>()
            // Frequencies at/above this threshold are skipped by the desktop.
            val available = ceil(nyquist * .95 / settings.notchHz).toInt() - 1
            val count = min(max(1, settings.harmonics), available)
            for (k in 1..count) {
                val f0 = settings.notchHz * k
                built += notch(sampleRate, f0.toDouble(), settings.notchQ)
                frequencies += f0
            }
            if (frequencies.isNotEmpty()) descriptions += "陷波 ${frequencies.joinToString("/")} Hz"
        }
        sections = built
        description = descriptions.joinToString(" + ").ifEmpty { "直通" }
        reset()
    }

    fun reset() {
        state = emptyArray()
        initialized = BooleanArray(0)
    }

    fun process(samples: Array<FloatArray>): Array<FloatArray> {
        if (samples.isEmpty()) return emptyArray()
        val channels = samples[0].size
        require(samples.all { it.size == channels }) { "每个样本的通道数量必须一致" }
        if (sections.isEmpty()) return Array(samples.size) { samples[it].copyOf() }
        if (initialized.size != channels) {
            initialized = BooleanArray(channels)
            state = Array(channels) { Array(sections.size) { DoubleArray(2) } }
        }
        return Array(samples.size) { i ->
            FloatArray(channels) { channel ->
                var value = samples[i][channel].toDouble()
                if (!value.isFinite()) {
                    initialized[channel] = false
                    Float.NaN
                } else {
                    if (!initialized[channel]) {
                        var steadyInput = value
                        for ((index, section) in sections.withIndex()) {
                            val steadyOutput = steadyInput * (section.b0 + section.b1 + section.b2) /
                                (1.0 + section.a1 + section.a2)
                            state[channel][index][0] = steadyOutput - section.b0 * steadyInput
                            state[channel][index][1] = section.b2 * steadyInput - section.a2 * steadyOutput
                            steadyInput = steadyOutput
                        }
                        initialized[channel] = true
                    }
                    for ((index, section) in sections.withIndex()) {
                        val z = state[channel][index]
                        val next = section.b0 * value + z[0]
                        z[0] = section.b1 * value - section.a1 * next + z[1]
                        z[1] = section.b2 * value - section.a2 * next
                        value = next
                    }
                    value.toFloat()
                }
            }
        }
    }

    private fun format(value: Double): String = if (value == floor(value)) value.toInt().toString() else value.toString()

    private fun notch(fs: Int, hz: Double, q: Double): Section {
        val omega = 2 * PI * hz / fs
        val beta = tan(omega / (2 * q))
        val gain = 1 / (1 + beta)
        val mid = -2 * gain * cos(omega)
        return Section(gain, mid, gain, mid, 2 * gain - 1)
    }

    private fun butterworth(fs: Int, order: Int, hp: Double, lp: Double, type: String): List<Section> {
        val twoFs = 2.0 * fs
        val warpedHp = if (hp > 0) twoFs * tan(PI * hp / fs) else 0.0
        val warpedLp = if (lp > 0) twoFs * tan(PI * lp / fs) else 0.0
        val analogPoles = mutableListOf<Complex>()
        for (k in 0 until order) {
            val angle = PI * (2 * k + 1 + order) / (2.0 * order)
            val prototype = Complex(cos(angle), sin(angle))
            when (type) {
                "lowpass" -> analogPoles += prototype * warpedLp
                "highpass" -> analogPoles += Complex(warpedHp) / prototype
                else -> {
                    val half = prototype * ((warpedLp - warpedHp) / 2)
                    val delta = (half * half - Complex(warpedLp * warpedHp)).sqrt()
                    analogPoles += half + delta
                    analogPoles += half - delta
                }
            }
        }
        val poles = analogPoles.map { (Complex(twoFs) + it) / (Complex(twoFs) - it) }.toMutableList()
        val pairs = mutableListOf<Pair<Complex, Complex?>>()
        // Conjugate pairs give real coefficients; an odd-order real pole uses
        // a first-order section. Sorting reduces excessive intermediate gain.
        while (poles.isNotEmpty()) {
            val pole = poles.removeAt(0)
            val other = if (abs(pole.im) < 1e-9) {
                poles.indexOfFirst { abs(it.im) < 1e-9 }
            } else {
                poles.indices.minByOrNull { (poles[it] - pole.conjugate()).abs() } ?: -1
            }
            pairs += pole to if (other >= 0) poles.removeAt(other) else null
        }
        val reference = when (type) {
            "lowpass" -> 0.0
            "highpass" -> PI
            else -> 2 * atan(sqrt(warpedHp * warpedLp) / twoFs)
        }
        val z1 = Complex(cos(reference), -sin(reference))
        val z2 = z1 * z1
        return pairs.sortedBy { max(it.first.abs(), it.second?.abs() ?: 0.0) }.map { (p, q) ->
            val a1 = -(p.re + (q?.re ?: 0.0))
            val a2 = if (q == null) 0.0 else (p * q).re
            val b1: Double
            val b2: Double
            when (type) {
                "lowpass" -> { b1 = if (q == null) 1.0 else 2.0; b2 = if (q == null) 0.0 else 1.0 }
                "highpass" -> { b1 = if (q == null) -1.0 else -2.0; b2 = if (q == null) 0.0 else 1.0 }
                else -> { b1 = 0.0; b2 = -1.0 }
            }
            val denominator = Complex(1.0) + z1 * a1 + z2 * a2
            val numerator = Complex(1.0) + z1 * b1 + z2 * b2
            val gain = denominator.abs() / numerator.abs()
            Section(gain, b1 * gain, b2 * gain, a1, a2)
        }
    }

    private data class Complex(val re: Double, val im: Double = 0.0) {
        operator fun plus(other: Complex) = Complex(re + other.re, im + other.im)
        operator fun minus(other: Complex) = Complex(re - other.re, im - other.im)
        operator fun times(other: Complex) = Complex(re * other.re - im * other.im, re * other.im + im * other.re)
        operator fun times(value: Double) = Complex(re * value, im * value)
        operator fun div(other: Complex): Complex {
            val d = other.re * other.re + other.im * other.im
            return Complex((re * other.re + im * other.im) / d, (im * other.re - re * other.im) / d)
        }
        fun abs() = hypot(re, im)
        fun conjugate() = Complex(re, -im)
        fun sqrt(): Complex {
            val magnitude = abs()
            val real = kotlin.math.sqrt(max(0.0, (magnitude + re) / 2))
            val imag = kotlin.math.sqrt(max(0.0, (magnitude - re) / 2))
            return Complex(real, if (im < 0) -imag else imag)
        }
    }
}
