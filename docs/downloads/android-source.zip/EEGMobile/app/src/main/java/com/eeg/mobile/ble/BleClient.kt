package com.eeg.mobile.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import java.util.ArrayDeque
import java.util.UUID

data class BleDevice(val address: String, val name: String, val rssi: Int, val isEeg: Boolean)

/**
 * Android BLE port of eeg_host.py. Every listener callback runs on a dedicated
 * worker thread; UI clients must post updates to the main thread. All GATT
 * transactions run serially and a timed-out transaction closes the connection
 * rather than risking a late acknowledgement being applied to another command.
 */
@SuppressLint("MissingPermission")
class BleClient(context: Context, private val listener: Listener) {
    interface Listener {
        fun onDevices(devices: List<BleDevice>)
        fun onState(state: String, message: String)
        fun onReady(name: String, address: String, mtu: Int)
        fun onData(data: ByteArray)
        fun onStatus(text: String)
        fun onError(message: String)
    }

    private val context = context.applicationContext
    private val thread = HandlerThread("EEG-BLE").apply { start() }
    private val handler = Handler(thread.looper)
    @Volatile private var closed = false
    @Volatile private var disposed = false
    private val adapter: BluetoothAdapter?
        get() = (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private var gatt: BluetoothGatt? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var statusCharacteristic: BluetoothGattCharacteristic? = null
    private var ready = false
    private var negotiatedMtu = 23
    private var deviceName = "EEG"
    private var deviceAddress = ""
    private val commands = ArrayDeque<ByteArray>()
    private var pendingCommand: ByteArray? = null
    private enum class Operation { CONNECT, MTU, DISCOVER, DATA_CCCD, STATUS_CCCD, WRITE }
    private var operation: Operation? = null
    private var operationTimeout: Runnable? = null
    private var shuttingDown = false
    private var shutdownDisposesClient = false
    private var shutdownStopWritten = false
    private var shutdownTimeout: Runnable? = null
    private var scanCallback: ScanCallback? = null
    private var scanner: BluetoothLeScanner? = null
    private var scanTimeout: Runnable? = null
    private var scanPublish: Runnable? = null
    private val devices = linkedMapOf<String, BleDevice>()

    fun scan(onlyEeg: Boolean = true) = post {
        if (gatt != null) {
            listener.onError("请先断开当前设备，再开始扫描")
            return@post
        }
        stopScanInternal(false)
        if (!checkBluetooth(scan = true)) return@post
        devices.clear()
        listener.onDevices(emptyList())
        val currentScanner = try { adapter?.bluetoothLeScanner } catch (e: Exception) {
            listener.onState("IDLE", "蓝牙不可用")
            listener.onError("无法访问 BLE 扫描器：${e.message}")
            return@post
        }
        if (currentScanner == null) {
            listener.onError("此设备不支持 BLE 扫描，或蓝牙尚未就绪")
            listener.onState("IDLE", "无法扫描")
            return@post
        }
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                post { if (scanCallback === this) acceptScanResult(result, onlyEeg) }
            }
            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                post { if (scanCallback === this) results.forEach { acceptScanResult(it, onlyEeg) } }
            }
            override fun onScanFailed(errorCode: Int) {
                post {
                    if (scanCallback !== this) return@post
                    stopScanInternal(false)
                    listener.onState("IDLE", "扫描失败")
                    listener.onError("蓝牙扫描失败（代码 $errorCode），请稍后重试")
                }
            }
        }
        scanCallback = callback
        scanner = currentScanner
        try {
            // Software filtering accepts either service UUID or names containing
            // EEG, including devices that omit the service UUID from advertising.
            currentScanner.startScan(null, ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0).build(), callback)
            listener.onState("SCANNING", "正在扫描附近设备…")
            scanTimeout = Runnable {
                if (scanCallback === callback) stopScanInternal(true)
            }.also { handler.postDelayed(it, 8_000) }
        } catch (e: Exception) {
            stopScanInternal(false)
            listener.onState("IDLE", "扫描失败")
            listener.onError("扫描失败：${e.message ?: "蓝牙不可用"}")
        }
    }

    fun stopScan() = post { stopScanInternal(true) }

    fun connect(address: String) = post {
        stopScanInternal(false)
        releaseGatt()
        if (!checkBluetooth(scan = false)) return@post
        if (!BluetoothAdapter.checkBluetoothAddress(address)) {
            listener.onState("DISCONNECTED", "设备地址无效")
            listener.onError("蓝牙地址无效：$address")
            return@post
        }
        deviceAddress = address
        deviceName = devices[address]?.name ?: "EEG"
        negotiatedMtu = 23
        listener.onState("CONNECTING", "正在连接 $deviceName…")
        try {
            val device = adapter!!.getRemoteDevice(address)
            deviceName = devices[address]?.name ?: device.name ?: "EEG"
            beginOperation(Operation.CONNECT, 25_000)
            // The handler overload keeps callbacks ordered on the BLE thread.
            gatt = device.connectGatt(context, false, callback,
                BluetoothDevice.TRANSPORT_LE, BluetoothDevice.PHY_LE_1M_MASK, handler)
            if (gatt == null) fail("无法创建蓝牙连接，请重试")
        } catch (e: Exception) {
            fail("连接失败：${e.message ?: "蓝牙不可用"}")
        }
    }

    /** Commands are UTF-8 lines, written WITH RESPONSE just like the desktop app. */
    fun sendCommand(command: String) = post {
        if (shuttingDown || !ready || gatt == null) {
            listener.onError("尚未连接设备，命令未发送")
            return@post
        }
        val line = command.trim()
        if (line.isEmpty() || line.contains('\n') || line.contains('\r')) {
            listener.onError("命令必须是非空的单行文本")
            return@post
        }
        val bytes = "$line\n".toByteArray(Charsets.UTF_8)
        if (bytes.size > negotiatedMtu - 3) {
            listener.onError("命令长度超过当前蓝牙 MTU，未发送")
            return@post
        }
        if (commands.size >= 64) {
            listener.onError("待发送命令过多，请等待设备响应")
            return@post
        }
        commands.addLast(bytes)
        writeNextCommand()
    }

    fun disconnect() = post {
        stopScanInternal(false)
        beginShutdown(disposeClient = false)
    }

    fun close() {
        if (closed) return
        closed = true
        handler.post {
            stopScanInternal(false)
            beginShutdown(disposeClient = true)
        }
    }

    private fun post(action: () -> Unit) {
        if (!closed) handler.post { if (!closed) action() }
    }

    // GATT acknowledgements must still be received during the bounded STOP
    // shutdown even though close() has already rejected all new public calls.
    private fun postCallback(action: () -> Unit) {
        if (!disposed) handler.post { if (!disposed) action() }
    }

    private fun beginShutdown(disposeClient: Boolean) {
        if (shuttingDown) {
            shutdownDisposesClient = shutdownDisposesClient || disposeClient
            return
        }
        shutdownDisposesClient = disposeClient
        if (!ready || gatt == null) {
            finishShutdown()
            return
        }
        shuttingDown = true
        ready = false
        commands.clear()
        shutdownStopWritten = false
        shutdownTimeout = Runnable { finishShutdown() }.also {
            handler.postDelayed(it, 1_500)
        }
        // An existing write is allowed to receive its own acknowledgement.
        // Queued START/settings are discarded and STOP is the next transaction.
        if (operation == null) writeShutdownStop()
    }

    private fun writeShutdownStop() {
        val current = gatt
        val characteristic = rx
        if (current == null || characteristic == null) {
            finishShutdown()
            return
        }
        shutdownStopWritten = true
        val bytes = "STOP\n".toByteArray(Charsets.UTF_8)
        pendingCommand = bytes
        beginOperation(Operation.WRITE, 1_500)
        try {
            val started = if (Build.VERSION.SDK_INT >= 33) {
                current.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                @Suppress("DEPRECATION")
                current.writeCharacteristic(characteristic)
            }
            if (!started) finishShutdown()
        } catch (_: Exception) { finishShutdown() }
    }

    private fun finishShutdown() {
        val disposeClient = shutdownDisposesClient
        releaseGatt()
        if (disposeClient) {
            disposed = true
            handler.removeCallbacksAndMessages(null)
            thread.quitSafely()
        } else if (!closed) listener.onState("DISCONNECTED", "已断开连接")
    }

    private fun checkBluetooth(scan: Boolean): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 31) {
            if (scan) listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else listOf(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (scan) listOf(Manifest.permission.ACCESS_FINE_LOCATION) else emptyList()
        if (needed.any { context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            listener.onState(if (scan) "IDLE" else "DISCONNECTED", "需要蓝牙权限")
            listener.onError(if (Build.VERSION.SDK_INT >= 31) "请允许“附近的设备”权限后重试" else "请允许位置权限后重试扫描")
            return false
        }
        try {
            val bt = adapter
            if (bt == null || !bt.isEnabled) {
                listener.onState(if (scan) "IDLE" else "DISCONNECTED", "蓝牙未开启")
                listener.onError(if (bt == null) "此设备不支持蓝牙" else "请先开启手机蓝牙")
                return false
            }
            if (scan && Build.VERSION.SDK_INT < 31) {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                val locationEnabled = if (Build.VERSION.SDK_INT >= 28) lm?.isLocationEnabled == true
                    else lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true ||
                        lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
                if (!locationEnabled) {
                    listener.onState("IDLE", "需要开启位置服务")
                    listener.onError("此 Android 版本需要开启系统位置服务才能扫描 BLE")
                    return false
                }
            }
        } catch (e: Exception) {
            listener.onState(if (scan) "IDLE" else "DISCONNECTED", "蓝牙不可用")
            listener.onError("无法访问蓝牙：${e.message}")
            return false
        }
        return true
    }

    private fun acceptScanResult(result: ScanResult, onlyEeg: Boolean) {
        try {
            val name = result.scanRecord?.deviceName ?: result.device.name ?: "(未命名)"
            val isEeg = name.contains("EEG", ignoreCase = true) ||
                result.scanRecord?.serviceUuids?.any { it.uuid == SERVICE_UUID } == true
            if (onlyEeg && !isEeg) return
            val address = result.device.address
            val previous = devices[address]
            devices[address] = BleDevice(address,
                if (name == "(未命名)" && previous != null) previous.name else name,
                result.rssi, isEeg || previous?.isEeg == true)
            // Repeated advertisements do not force a UI redraw per packet.
            if (scanPublish == null) {
                scanPublish = Runnable {
                    scanPublish = null
                    listener.onDevices(devices.values.sortedByDescending { it.rssi })
                }.also { handler.postDelayed(it, 250) }
            }
        } catch (_: SecurityException) {
            stopScanInternal(false)
            listener.onState("IDLE", "蓝牙权限已撤销")
            listener.onError("蓝牙权限已撤销，请重新允许后扫描")
        }
    }

    private fun stopScanInternal(announce: Boolean) {
        scanTimeout?.let { handler.removeCallbacks(it) }
        scanTimeout = null
        scanPublish?.let { handler.removeCallbacks(it) }
        scanPublish = null
        val oldCallback = scanCallback
        scanCallback = null
        if (oldCallback != null) {
            try { scanner?.stopScan(oldCallback) } catch (_: Exception) { }
            if (!closed) listener.onDevices(devices.values.sortedByDescending { it.rssi })
            if (announce && !closed) listener.onState("IDLE", "扫描完成：找到 ${devices.size} 个设备")
        }
        scanner = null
    }

    private fun beginOperation(next: Operation, timeoutMs: Long = 12_000) {
        check(operation == null) { "Overlapping GATT operations" }
        operation = next
        operationTimeout = Runnable {
            if (operation == next) fail("蓝牙操作超时（${operationLabel(next)}），请重新连接")
        }.also { handler.postDelayed(it, timeoutMs) }
    }

    private fun finishOperation() {
        operationTimeout?.let { handler.removeCallbacks(it) }
        operationTimeout = null
        operation = null
    }

    private fun requestMtu() {
        val current = gatt ?: return
        listener.onState("CONNECTING", "正在协商数据包大小…")
        beginOperation(Operation.MTU)
        try {
            if (!current.requestMtu(517)) {
                finishOperation()
                discoverServices()
            }
        } catch (e: Exception) { fail("MTU 协商失败：${e.message}") }
    }

    private fun discoverServices() {
        val current = gatt ?: return
        listener.onState("CONNECTING", "正在查找脑电服务…")
        beginOperation(Operation.DISCOVER)
        try {
            if (!current.discoverServices()) fail("无法开始发现 BLE 服务")
        } catch (e: Exception) { fail("服务发现失败：${e.message}") }
    }

    private fun subscribe(characteristic: BluetoothGattCharacteristic?, required: Boolean) {
        val current = gatt ?: return
        val descriptor = characteristic?.getDescriptor(CCCD_UUID)
        val properties = characteristic?.properties ?: 0
        val enableValue = when {
            properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 -> BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0 -> BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            else -> null
        }
        if (characteristic == null || descriptor == null || enableValue == null) {
            if (required) fail("设备的数据通道缺少通知功能或 CCCD 描述符") else becomeReady()
            return
        }
        listener.onState("CONNECTING", if (required) "正在订阅脑电数据…" else "正在订阅设备状态…")
        try {
            if (!current.setCharacteristicNotification(characteristic, true)) {
                if (required) fail("无法开启脑电数据通知") else becomeReady()
                return
            }
            beginOperation(if (required) Operation.DATA_CCCD else Operation.STATUS_CCCD)
            val started = if (Build.VERSION.SDK_INT >= 33) {
                current.writeDescriptor(descriptor, enableValue) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = enableValue
                @Suppress("DEPRECATION")
                current.writeDescriptor(descriptor)
            }
            if (!started) {
                finishOperation()
                if (required) fail("无法写入脑电通知配置") else becomeReady()
            }
        } catch (e: Exception) {
            // Permission loss is never an optional-channel failure.
            if (required || e is SecurityException) fail("订阅通知失败：${e.message}")
            else { finishOperation(); becomeReady() }
        }
    }

    private fun becomeReady() {
        if (closed || gatt == null || ready) return
        ready = true
        // Queue INFO before exposing readiness so it precedes any UI command.
        commands.addLast("INFO\n".toByteArray(Charsets.UTF_8))
        listener.onState("CONNECTED", "已连接 $deviceName · MTU $negotiatedMtu")
        listener.onReady(deviceName, deviceAddress, negotiatedMtu)
        writeNextCommand()
    }

    private fun writeNextCommand() {
        if (closed || !ready || operation != null || commands.isEmpty()) return
        val current = gatt ?: return
        val characteristic = rx ?: return
        val bytes = commands.removeFirst()
        pendingCommand = bytes
        beginOperation(Operation.WRITE)
        try {
            val started = if (Build.VERSION.SDK_INT >= 33) {
                current.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                @Suppress("DEPRECATION")
                current.writeCharacteristic(characteristic)
            }
            if (!started) fail("命令写入未能开始，请重新连接")
        } catch (e: Exception) { fail("命令发送失败：${e.message}") }
    }

    private fun releaseGatt() {
        val old = gatt
        gatt = null // Invalidate queued callbacks before disconnect()/close().
        ready = false
        rx = null
        statusCharacteristic = null
        commands.clear()
        pendingCommand = null
        shutdownTimeout?.let { handler.removeCallbacks(it) }
        shutdownTimeout = null
        shuttingDown = false
        shutdownStopWritten = false
        shutdownDisposesClient = false
        finishOperation()
        try { old?.disconnect() } catch (_: Exception) { }
        try { old?.close() } catch (_: Exception) { }
    }

    private fun fail(message: String) {
        if (shuttingDown) {
            finishShutdown()
            return
        }
        releaseGatt()
        if (!closed) {
            listener.onState("DISCONNECTED", "连接已断开")
            listener.onError(message)
        }
    }

    private fun received(current: BluetoothGatt, uuid: UUID, value: ByteArray) = postCallback {
        if (closed || gatt !== current || !ready) return@postCallback
        when (uuid) {
            TX_UUID -> listener.onData(value)
            STATUS_UUID -> listener.onStatus(value.toString(Charsets.UTF_8).trim())
        }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(current: BluetoothGatt, status: Int, newState: Int) = postCallback {
            if (gatt !== current) return@postCallback
            if (shuttingDown && (status != BluetoothGatt.GATT_SUCCESS || newState == BluetoothProfile.STATE_DISCONNECTED)) {
                finishShutdown()
                return@postCallback
            }
            if (status != BluetoothGatt.GATT_SUCCESS) {
                fail("蓝牙连接失败（GATT $status），请检查设备电量、距离及是否被电脑占用")
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                releaseGatt()
                listener.onState("DISCONNECTED", "设备已断开")
            } else if (newState == BluetoothProfile.STATE_CONNECTED && operation == Operation.CONNECT) {
                finishOperation()
                requestMtu()
            }
        }

        override fun onMtuChanged(current: BluetoothGatt, mtu: Int, status: Int) = postCallback {
            if (gatt !== current) return@postCallback
            if (status == BluetoothGatt.GATT_SUCCESS && mtu >= 23) negotiatedMtu = mtu
            if (operation != Operation.MTU) return@postCallback
            finishOperation()
            discoverServices()
        }

        override fun onServicesDiscovered(current: BluetoothGatt, status: Int) = postCallback {
            if (gatt !== current || operation != Operation.DISCOVER) return@postCallback
            finishOperation()
            if (status != BluetoothGatt.GATT_SUCCESS) {
                fail("BLE 服务发现失败（GATT $status）")
                return@postCallback
            }
            val service = current.getService(SERVICE_UUID)
            rx = service?.getCharacteristic(RX_UUID)
            val tx = service?.getCharacteristic(TX_UUID)
            statusCharacteristic = service?.getCharacteristic(STATUS_UUID)
            if (service == null || rx == null || tx == null) {
                fail("此设备不提供原上位机使用的 EEG BLE 服务")
                return@postCallback
            }
            if (rx!!.properties and BluetoothGattCharacteristic.PROPERTY_WRITE == 0) {
                fail("设备 RX 通道不支持带响应写入，与原上位机协议不兼容")
                return@postCallback
            }
            // A complete eight-channel sample requires 39 payload bytes; an
            // ATT notification additionally needs 3 bytes. Never call a link
            // usable when the minimum packet cannot fit its negotiated MTU.
            if (negotiatedMtu < 42) {
                fail("蓝牙 MTU 仅 $negotiatedMtu，无法接收完整八通道脑电包；请重启采集设备后重连")
                return@postCallback
            }
            subscribe(tx, true)
        }

        override fun onDescriptorWrite(current: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) = postCallback {
            if (gatt !== current || descriptor.uuid != CCCD_UUID) return@postCallback
            val expected = when (operation) {
                Operation.DATA_CCCD -> TX_UUID
                Operation.STATUS_CCCD -> STATUS_UUID
                else -> return@postCallback
            }
            if (descriptor.characteristic.uuid != expected) return@postCallback
            val required = operation == Operation.DATA_CCCD
            finishOperation()
            if (required && status != BluetoothGatt.GATT_SUCCESS) {
                fail("脑电通知订阅失败（GATT $status）")
            } else if (required) {
                subscribe(statusCharacteristic, false)
            } else {
                // Firmware without the optional status channel can still stream.
                becomeReady()
            }
        }

        override fun onCharacteristicWrite(current: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) = postCallback {
            if (gatt !== current || operation != Operation.WRITE || characteristic.uuid != RX_UUID) return@postCallback
            val command = pendingCommand?.toString(Charsets.UTF_8)?.trim().orEmpty()
            pendingCommand = null
            finishOperation()
            if (shuttingDown) {
                if (shutdownStopWritten) finishShutdown() else writeShutdownStop()
                return@postCallback
            }
            if (status != BluetoothGatt.GATT_SUCCESS) {
                // Drop the rest of a settings batch: a partially applied batch
                // must not silently proceed into START after an earlier failure.
                fail("命令 $command 发送失败（GATT $status），已断开连接")
            } else writeNextCommand()
        }

        override fun onCharacteristicChanged(current: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            received(current, characteristic.uuid, value.copyOf())
        }

        @Deprecated("Legacy Android callback")
        override fun onCharacteristicChanged(current: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            val value = characteristic.value?.copyOf() ?: return
            received(current, characteristic.uuid, value)
        }

        override fun onServiceChanged(current: BluetoothGatt) = postCallback {
            if (gatt === current) fail("设备服务已变化，请重新连接")
        }
    }

    private fun operationLabel(op: Operation) = when (op) {
        Operation.CONNECT -> "连接"
        Operation.MTU -> "MTU 协商"
        Operation.DISCOVER -> "发现服务"
        Operation.DATA_CCCD -> "订阅数据"
        Operation.STATUS_CCCD -> "订阅状态"
        Operation.WRITE -> "发送命令"
    }

    private companion object {
        val SERVICE_UUID: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val RX_UUID: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
        val TX_UUID: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val STATUS_UUID: UUID = UUID.fromString("6e400004-b5a3-f393-e0a9-e50e24dcca9e")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
