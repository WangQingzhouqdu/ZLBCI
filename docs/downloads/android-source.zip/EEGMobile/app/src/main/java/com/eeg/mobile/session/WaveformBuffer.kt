package com.eeg.mobile.session

import kotlin.math.max
import kotlin.math.min

/** Bounded 20 second display history, independent raw/filtered data. */
internal class WaveformBuffer {
    private var capacity = 5000
    private var raw = Array(8) { FloatArray(capacity) }
    private var filtered = Array(8) { FloatArray(capacity) }
    private var cursor = 0
    private var size = 0

    @Synchronized fun reset(sampleRate: Int) {
        capacity = (sampleRate.coerceIn(250, 16000) * 20)
        raw = Array(8) { FloatArray(capacity) }
        filtered = Array(8) { FloatArray(capacity) }
        cursor = 0
        size = 0
    }

    @Synchronized fun clear() { cursor = 0; size = 0 }

    @Synchronized fun push(input: Array<FloatArray>, output: Array<FloatArray>) {
        for (i in input.indices) {
            for (channel in 0..7) {
                raw[channel][cursor] = input[i][channel]
                filtered[channel][cursor] = output[i][channel]
            }
            cursor = (cursor + 1) % capacity
            size = min(size + 1, capacity)
        }
    }

    @Synchronized fun pushGap(samples: Long) {
        val count = min(samples.coerceAtLeast(0L), capacity.toLong()).toInt()
        for (i in 0 until count) {
            for (channel in 0..7) {
                raw[channel][cursor] = Float.NaN
                filtered[channel][cursor] = Float.NaN
            }
            cursor = (cursor + 1) % capacity
            size = min(size + 1, capacity)
        }
    }

    /** Returns channel-major data, retaining both extrema in each display bin. */
    @Synchronized fun snapshot(samples: Int, maxPoints: Int, showFiltered: Boolean): Array<FloatArray> {
        val count = samples.coerceIn(1, capacity)
        val available = min(size, count)
        val padding = count - available
        val limit = maxPoints.coerceIn(2, 10000)
        val source = if (showFiltered) filtered else raw
        val first = (cursor - available + capacity) % capacity
        if (count <= limit) return Array(8) { ch -> FloatArray(count) {
            if (it < padding) Float.NaN else source[ch][(first + it - padding) % capacity]
        } }
        val bins = max(1, limit / 2)
        return Array(8) { ch ->
            val output = FloatArray(bins * 2)
            for (b in 0 until bins) {
                val start = b * count / bins
                val end = (b + 1) * count / bins
                var lo = Float.POSITIVE_INFINITY
                var hi = Float.NEGATIVE_INFINITY
                var loIndex = start
                var hiIndex = start
                var missing = false
                for (i in start until end) {
                    if (i < padding) { missing = true; continue }
                    val value = source[ch][(first + i - padding) % capacity]
                    if (!value.isFinite()) { missing = true; continue }
                    if (value < lo) { lo = value; loIndex = i }
                    if (value > hi) { hi = value; hiIndex = i }
                }
                output[b * 2] = if (missing || !lo.isFinite()) Float.NaN else if (loIndex <= hiIndex) lo else hi
                output[b * 2 + 1] = if (missing || !hi.isFinite()) Float.NaN else if (loIndex <= hiIndex) hi else lo
            }
            output
        }
    }
}
