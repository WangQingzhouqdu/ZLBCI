package com.eeg.mobile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.*
import com.eeg.mobile.core.FilterSettings
import com.eeg.mobile.session.DeviceSettings
import com.eeg.mobile.session.EegService
import com.eeg.mobile.session.SessionSnapshot
import com.eeg.mobile.ui.WaveformView
import java.util.Locale

class MainActivity : Activity() {
    private val bg=0xff0a1220.toInt(); private val card=0xff121f32.toInt()
    private val ink=0xffedf4ff.toInt(); private val muted=0xff91a3bc.toInt(); private val accent=0xff40dfc4.toInt()
    private var svc:EegService?=null
    private var bound=false
    private var bindRequested=false
    private val handler=Handler(Looper.getMainLooper())
    private lateinit var root:LinearLayout
    private lateinit var body:FrameLayout
    private lateinit var connectionLabel:TextView
    private lateinit var sourceLabel:TextView
    private lateinit var messageLabel:TextView
    private val tabButtons=mutableListOf<TextView>()
    private var tab=0
    private var wave:WaveformView?=null
    private var stats:TextView?=null
    private var runButton:Button?=null
    private var recordButton:Button?=null
    private var recordStatus:TextView?=null
    private var recordingList:LinearLayout?=null
    private var deviceList:LinearLayout?=null
    private var details:TextView?=null
    private var leadLabels=mutableListOf<TextView>()
    private var lastDeviceKey=""
    private var lastRecordingKey=""
    private var lastSlowUi=0L
    private var windowSeconds=5.0
    private var amplitude=100.0
    private var filtered=true
    private var channels=BooleanArray(8) { true }
    private var pendingBluetooth:(()->Unit)?=null
    private var pendingBoundBluetooth:(()->Unit)?=null
    private var exportName:String?=null
    private var resumed=false
    private val refreshLoop=object:Runnable {
        override fun run() {
            if(!resumed)return
            if(tab==0) { wave?.let { view -> svc?.let { view.samples=it.waveform(windowSeconds,900); view.invalidate() } } }
            handler.postDelayed(this,50)
        }
    }
    private val connection=object:ServiceConnection {
        override fun onServiceConnected(name:ComponentName?,binder:IBinder?) {
            svc=(binder as EegService.LocalBinder).service; bound=true
            svc?.onChanged={refresh()}; svc?.setDisplay(filtered)
            showTab(tab); refresh()
            pendingExport?.let { (file,uri) -> svc?.exportRecording(file,uri); pendingExport=null }
            pendingBoundBluetooth?.let { action -> pendingBoundBluetooth=null; withBluetooth(action) }
        }
        override fun onServiceDisconnected(name:ComponentName?) { svc=null; bound=false; connectionLabel.text="服务已断开" }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs=getSharedPreferences("display",MODE_PRIVATE)
        windowSeconds=prefs.getFloat("window",5f).toDouble(); amplitude=prefs.getFloat("amplitude",100f).toDouble()
        filtered=prefs.getBoolean("filtered",true)
        val mask=prefs.getInt("channels",255); channels=BooleanArray(8){mask and (1 shl it)!=0}
        tab=savedInstanceState?.getInt("tab")?:0
        exportName=savedInstanceState?.getString("exportName")
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.setOnApplyWindowInsetsListener { v,insets ->
            if(Build.VERSION.SDK_INT>=30) { val edge=insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()); v.setPadding(dp(16)+edge.left,edge.top+dp(10),dp(16)+edge.right,edge.bottom+dp(8)) }
            else { @Suppress("DEPRECATION") v.setPadding(dp(16)+insets.systemWindowInsetLeft,insets.systemWindowInsetTop+dp(10),dp(16)+insets.systemWindowInsetRight,insets.systemWindowInsetBottom+dp(8)) }; insets
        }
        setContentView(root)
        val titleRow=row(); val names=column()
        names.addView(text("EEG  /  MOBILE",10,accent,true)); names.addView(text("脑电采集",25,ink,true))
        titleRow.addView(names,LinearLayout.LayoutParams(0,-2,1f))
        sourceLabel=text("离线",12,muted,true).apply { gravity=Gravity.CENTER; setPadding(dp(12),dp(7),dp(12),dp(7)); background=rounded(card,12) }
        titleRow.addView(sourceLabel); root.addView(titleRow)
        connectionLabel=text("未连接设备",13,muted).apply { setPadding(0,dp(8),0,dp(8)) }; root.addView(connectionLabel)
        body=FrameLayout(this); root.addView(body,LinearLayout.LayoutParams(-1,0,1f))
        messageLabel=text("准备就绪 · 支持 ESP32-S3 + ADS1299",11,muted).apply { maxLines=2; setPadding(0,dp(6),0,dp(6)) }; root.addView(messageLabel)
        val tabs=row().apply { background=rounded(card,14); setPadding(dp(4),dp(4),dp(4),dp(4)) }
        listOf("波形","设备","参数","记录").forEachIndexed { index,label ->
            val item=text(label,14,muted,true).apply { gravity=Gravity.CENTER; minHeight=dp(44); setOnClickListener{showTab(index)} }
            tabButtons+=item; tabs.addView(item,LinearLayout.LayoutParams(0,-2,1f))
        }; root.addView(tabs)
        showTab(tab)
    }
    override fun onStart() { super.onStart(); bindRequested=bindService(Intent(this,EegService::class.java),connection,BIND_AUTO_CREATE) }
    override fun onResume() { super.onResume(); resumed=true; handler.post(refreshLoop); svc?.onChanged={refresh()}; refresh() }
    override fun onPause() { resumed=false; handler.removeCallbacks(refreshLoop); saveDisplay(); super.onPause() }
    override fun onStop() { svc?.onChanged=null; if(bindRequested){unbindService(connection); bindRequested=false; bound=false}; svc=null; super.onStop() }
    override fun onSaveInstanceState(outState:Bundle) { outState.putInt("tab",tab);outState.putString("exportName",exportName); super.onSaveInstanceState(outState) }
    private fun saveDisplay() {
        getSharedPreferences("display",MODE_PRIVATE).edit().putFloat("window",windowSeconds.toFloat()).putFloat("amplitude",amplitude.toFloat()).putBoolean("filtered",filtered).putInt("channels",channels.indices.fold(0){m,i->if(channels[i])m or (1 shl i) else m}).apply()
    }
    private fun showTab(index:Int) {
        tab=index; body.removeAllViews(); wave=null;stats=null;runButton=null;recordButton=null;recordStatus=null;recordingList=null;deviceList=null;details=null;leadLabels.clear();lastDeviceKey="";lastRecordingKey=""
        tabButtons.forEachIndexed { i,v -> v.setTextColor(if(i==tab)bg else muted); v.background=if(i==tab)rounded(accent,10) else null }
        when(tab){0->buildWave();1->buildDevices();2->buildSettings();3->buildRecordings()}; refresh()
    }
    private fun buildWave() {
        val page=column();body.addView(page,FrameLayout.LayoutParams(-1,-1))
        stats=text("0 样本/s     丢样 0     CRC 0",12,muted).also { page.addView(it) }
        val frame=column().apply { background=rounded(card,16); setPadding(dp(8),dp(8),dp(8),dp(4)) }
        val labels=row();labels.addView(text("实时信号",13,ink,true),LinearLayout.LayoutParams(0,-2,1f));labels.addView(text("8 CHANNELS · μV",10,muted))
        frame.addView(labels)
        wave=WaveformView(this).apply { seconds=windowSeconds;amplitude=this@MainActivity.amplitude;visibleChannels=channels.copyOf() }
        frame.addView(wave,LinearLayout.LayoutParams(-1,0,1f))
        val frameParams=LinearLayout.LayoutParams(-1,0,1f);frameParams.topMargin=dp(10);frameParams.bottomMargin=dp(10);page.addView(frame,frameParams)
        val controls=row()
        controls.addView(button("${windowSeconds.toInt()} 秒",false){chooseWindow()},LinearLayout.LayoutParams(0,dp(44),1f))
        controls.addView(button(if(amplitude==0.0)"自动量程" else "±${amplitude.toInt()} μV",false){chooseAmplitude()},LinearLayout.LayoutParams(0,dp(44),1f))
        controls.addView(button(if(filtered)"滤波后" else "原始",false){filtered=!filtered;svc?.setDisplay(filtered);showTab(0)},LinearLayout.LayoutParams(0,dp(44),1f))
        page.addView(controls)
        val leadRow=row();(0..7).forEach { i->
            val label=text("${i+1}",11,accent,true).apply{gravity=Gravity.CENTER;minHeight=dp(32);setOnClickListener{channels[i]=!channels[i];wave?.visibleChannels=channels.copyOf();refresh()};contentDescription="通道 ${i+1} 显示开关"};leadLabels+=label;leadRow.addView(label,LinearLayout.LayoutParams(0,-2,1f))
        };page.addView(leadRow)
        val actions=row();runButton=button("开始采集"){toggleRun()};actions.addView(runButton,LinearLayout.LayoutParams(0,dp(49),1f))
        actions.addView(button("清空",false){svc?.clearDisplay()},LinearLayout.LayoutParams(dp(80),dp(49)));page.addView(actions)
    }
    private fun chooseWindow(){ val values=doubleArrayOf(1.0,2.0,5.0,10.0,20.0);AlertDialog.Builder(this).setTitle("显示时间窗").setItems(values.map{"${it.toInt()} 秒"}.toTypedArray()){_,i->windowSeconds=values[i];showTab(0)}.show() }
    private fun chooseAmplitude(){val values=doubleArrayOf(0.0,10.0,25.0,50.0,100.0,200.0,500.0,1000.0,2000.0,5000.0);AlertDialog.Builder(this).setTitle("每通道幅度量程").setItems(values.map{if(it==0.0)"自动" else "±${it.toInt()} μV"}.toTypedArray()){_,i->amplitude=values[i];showTab(0)}.show()}
    private fun toggleRun(){val s=svc?.snapshot()?:return;if(!s.connected){showTab(1);return};if(s.streaming)svc?.pauseAcquisition() else svc?.startAcquisition()}
    private fun buildDevices() {
        val page=scrollPage()
        section(page,"连接采集板","使用 BLE 直接连接 ESP32-S3，无需电脑中转。")
        val only=check("只显示 EEG 设备",true);page.addView(only)
        page.addView(button("扫描蓝牙设备"){withBluetooth { svc?.scan(only.isChecked) }})
        deviceList=column();page.addView(deviceList)
        page.addView(button("断开连接",false){svc?.disconnect()})
        section(page,"无硬件体验","模拟数据仅用于检查波形、滤波和文件记录，会始终标记为“模拟”。")
        page.addView(button("开启模拟设备",false){
            val action={ startService(Intent(this,EegService::class.java)); svc?.connectDemo();showTab(0) }
            if(svc?.snapshot()?.connected==true) AlertDialog.Builder(this).setTitle("切换到模拟设备？").setMessage("当前连接和记录将结束。").setPositiveButton("切换"){_,_->action()}.setNegativeButton("取消",null).show() else action()
        })
        section(page,"设备状态", "连接后可在波形页开始采集，在参数页配置采集板。")
        details=text("尚未连接",12,muted);page.addView(details)
    }
    private fun buildSettings() {
        val page=scrollPage();val snap=svc?.snapshot();val d=snap?.settings?:DeviceSettings();val f=snap?.filterSettings?:FilterSettings(lowPass=45.0,harmonics=2)
        section(page,"采集参数","应用时会暂停采集并结束当前记录。高采样率可能受手机蓝牙吞吐限制。")
        val sr=spinner(page,"采样率 / SPS",listOf("250","500","1000","2000","4000","8000","16000"),d.sampleRate.toString())
        val gain=spinner(page,"PGA 增益",listOf("1","2","4","6","8","12","24"),d.gain.toString())
        val modes=listOf("NORMAL","SHORT","TEST","MVDD","TEMP");val modeNames=listOf("正常电极输入","输入短路 / 本底噪声","内部方波测试","电源电压 MVDD","芯片温度")
        val mode=spinner(page,"输入模式",modeNames,modeNames[modes.indexOf(d.mode).coerceAtLeast(0)])
        val srb=check("共模参考 SRB1",d.srb1);val bias=check("偏置驱动 BIAS_OUT",d.bias);val lead=check("导联脱落检测",d.leadOff)
        page.addView(srb);page.addView(bias);page.addView(lead)
        page.addView(button("应用采集参数") { svc?.applyDeviceSettings(DeviceSettings(sr.selectedItem.toString().toInt(),gain.selectedItem.toString().toInt(),modes[mode.selectedItemPosition],srb.isChecked,bias.isChecked,lead.isChecked));toast("采集参数已提交；设备返回的数据将确认实际采样率和增益") })
        section(page,"实时滤波","Butterworth 带通 / 高低通 + 工频陷波。0 表示关闭对应截止频率。")
        val enabled=check("启用实时滤波",f.enabled);page.addView(enabled)
        val hp=number(page,"高通下限 / Hz",f.highPass);val lp=number(page,"低通上限 / Hz",f.lowPass)
        val order=spinner(page,"Butterworth 阶数",listOf("2","4","6","8"),f.order.toString())
        val notch=spinner(page,"工频陷波",listOf("关闭","50 Hz","60 Hz"),if(f.notchHz==0)"关闭" else "${f.notchHz} Hz")
        val harmonics=spinner(page,"陷波谐波数",listOf("1","2","3","4","5"),f.harmonics.toString())
        page.addView(button("应用滤波") {
            val high=hp.text.toString().toDoubleOrNull();val low=lp.text.toString().toDoubleOrNull()
            if(high==null||low==null||!high.isFinite()||!low.isFinite()||high<0||low<0||high>200||low>2000||(high>0&&low>0&&low<=high)){toast("请输入有效截止频率：高通 0–200，低通 0–2000 Hz，低通须大于高通");return@button}
            svc?.applyFilterSettings(FilterSettings(enabled.isChecked,high,low,order.selectedItem.toString().toInt(),intArrayOf(0,50,60)[notch.selectedItemPosition],harmonics.selectedItem.toString().toInt(),30.0));toast("滤波配置已应用")
        })
        details=text(snap?.filterDescription?:"",12,muted);page.addView(details)
    }
    private fun buildRecordings() {
        val page=scrollPage();section(page,"记录与导出","CSV 保存到手机本地。导出时可选择“下载”文件夹；不会上传数据。")
        val mode=spinner(page,"保存内容",listOf("原始 + 滤波","仅原始","仅滤波"),"原始 + 滤波")
        recordButton=button("开始记录") { val s=svc?.snapshot()?:return@button; if(s.recording)svc?.stopRecording() else svc?.startRecording(listOf("both","raw","filt")[mode.selectedItemPosition]) };page.addView(recordButton)
        recordStatus=text("开始采集后，可记录 CSV。",13,muted).apply{setPadding(0,dp(12),0,dp(8))};page.addView(recordStatus)
        section(page,"已保存记录","点击文件可导出；卸载应用前请先导出需要保留的记录。")
        recordingList=column();page.addView(recordingList)
        section(page,"应用信息","脑电采集 1.0.0\nESP32-S3 + ADS1299 · 8 通道 BLE\n支持原始 µV、滤波信号和设备采样序号。")
    }
    private fun refresh() {
        val s=svc?.snapshot()?:return
        val now=SystemClock.elapsedRealtime();val slowUpdate=now-lastSlowUi>=1000
        if(slowUpdate)lastSlowUi=now
        sourceLabel.put(if(s.demo)"模拟数据" else if(s.connected)"BLE 实时" else "离线")
        sourceLabel.setTextColor(if(s.demo)0xffffc56b.toInt() else if(s.connected)accent else muted)
        connectionLabel.put(when { s.connection=="SCANNING"->"正在扫描周围的 BLE 设备…";s.connection=="CONNECTING"->"正在连接设备…";s.connected->"${s.deviceName}  ·  ${s.sampleRate} SPS  ·  ×${s.gain}";else->"未连接设备 · ESP32-S3 + ADS1299" })
        messageLabel.put(s.lastMessage.ifBlank { "准备就绪" })
        stats?.put(String.format(Locale.US,"%.0f 样本/s   丢样 %d   CRC %d   %.1f KB/s",s.samplesPerSecond,s.lostSamples,s.badPackets,s.bytesPerSecond/1024))
        runButton?.put(if(!s.connected)"连接设备" else if(s.streaming)"暂停采集" else "开始采集")
        if(s.streaming) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wave?.let { it.leadEnabled=s.settings.leadOff;it.leadP=s.leadOffP;it.leadN=s.leadOffN }
        leadLabels.forEachIndexed { i,label -> val bad=s.settings.leadOff&&((s.leadOffP or s.leadOffN) and (1 shl i)!=0); label.put("${if(bad)"!" else ""}${i+1}"); label.setTextColor(if(!channels[i])0xff42536a.toInt() else if(bad)0xffff7c83.toInt() else accent);val description="通道 ${i+1}，${if(!channels[i])"隐藏" else if(bad)"导联脱落" else if(s.settings.leadOff)"接触正常" else "未启用导联检测"}";if(label.contentDescription!=description)label.contentDescription=description }
        recordButton?.put(if(s.recording)"停止记录并保存" else "开始记录")
        recordButton?.isEnabled=s.streaming||s.recording
        if(slowUpdate||!s.recording||recordStatus?.text?.startsWith("●")!=true)recordStatus?.put(if(s.recording)"● 记录中 · ${s.recordedRows} 样本\n${s.recordingName}" else if(s.recordingName.isNotBlank())"已保存 · ${s.recordedRows} 样本\n${s.recordingName}" else "开始采集后，可记录 CSV。")
        if(tab==1) {
            if(slowUpdate||details?.text=="尚未连接")details?.put("${if(s.connected)"已连接" else "未连接"} · MTU ${s.mtu}\n${s.receivedSamples} 样本 · ${s.lostSamples} 丢样 · ${s.badPackets} 校验失败\n${s.deviceStatus}")
            val key=s.devices.joinToString { "${it.address}/${it.rssi}" }+s.connected
            if(key!=lastDeviceKey) {lastDeviceKey=key;deviceList?.removeAllViews();if(s.devices.isEmpty())deviceList?.addView(text("扫描结果将在这里显示",12,muted).apply{setPadding(0,dp(18),0,dp(18))})
                s.devices.forEach { device->deviceList?.addView(button("${device.name}   ${device.rssi} dBm\n${device.address}",false){withBluetooth { startService(Intent(this,EegService::class.java));svc?.connect(device.address);showTab(0) }}) }
            }
        }
        if(tab==2)details?.put(s.filterDescription)
        if(tab==3) {
            val files=svc?.listRecordings().orEmpty().filterNot { s.recording&&it.name==s.recordingName };val key=files.joinToString{it.name+it.length()}+s.recording
            if(key!=lastRecordingKey){lastRecordingKey=key;recordingList?.removeAllViews();if(files.isEmpty())recordingList?.addView(text("暂无记录",13,muted))
                files.forEach { file->
                    val current=s.recording&&s.recordingName==file.name
                    recordingList?.addView(button("${file.name}\n${String.format(Locale.US,"%.1f KB",file.length()/1024.0)} · ${if(current)"记录中" else "导出 CSV"}",false){if(current){toast("请先停止记录再导出")}else{exportName=file.name;val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,file.name);startActivityForResult(intent,300)}})
                }
            }
        }
    }
    private fun withBluetooth(action:()->Unit) {
        if(svc==null){pendingBoundBluetooth=action;return}
        if(!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){toast("此设备不支持蓝牙低功耗，可使用模拟设备");return}
        val required=if(Build.VERSION.SDK_INT>=31) arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if(required.any{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}) {
            pendingBluetooth=action
            val permissions=required.toMutableList();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permissions+=Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(permissions.toTypedArray(),200);return
        }
        val adapter=getSystemService(BluetoothManager::class.java)?.adapter
        if(adapter==null){toast("未发现蓝牙适配器");return}
        if(!adapter.isEnabled){pendingBluetooth=action;startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),201);return}
        if(Build.VERSION.SDK_INT<=30) {
            val location=getSystemService(android.location.LocationManager::class.java)
            val on=if(Build.VERSION.SDK_INT>=28)location.isLocationEnabled else location.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)||location.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)
            if(!on){AlertDialog.Builder(this).setTitle("扫描需要开启系统定位").setMessage("Android 11 及以下要求打开定位才能扫描 BLE；应用不采集地理位置。").setPositiveButton("打开设置"){_,_->startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))}.setNegativeButton("取消",null).show();return}
        }
        action()
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==200){val action=pendingBluetooth;pendingBluetooth=null;val required=if(Build.VERSION.SDK_INT>=31)arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT)else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION);if(required.all{checkSelfPermission(it)==PackageManager.PERMISSION_GRANTED}){if(action!=null)withBluetooth(action)}else toast("蓝牙权限未获授权，可在应用设置中开启或使用模拟设备")}
    }
    @Deprecated("Platform result API")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==201){val action=pendingBluetooth;pendingBluetooth=null;if(resultCode==RESULT_OK&&action!=null)withBluetooth(action)}
        if(requestCode==300&&resultCode==RESULT_OK){val name=exportName;val uri=data?.data;if(name!=null&&uri!=null){if(svc!=null)svc?.exportRecording(name,uri)else{pendingExport=name to uri}}};exportName=if(requestCode==300)null else exportName
    }
    private var pendingExport:Pair<String,Uri>?=null
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun TextView.put(value:String){if(text.toString()!=value)text=value}
    private fun column()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
    private fun row()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun rounded(color:Int,radius:Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(radius).toFloat()}
    private fun text(value:String,size:Int,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=value;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(typeface,Typeface.BOLD)}
    private fun button(value:String,primary:Boolean=true,action:()->Unit)=Button(this).apply{
        text=value;textSize=13f;isAllCaps=false;minHeight=dp(48);minimumHeight=dp(48);setPadding(dp(10),dp(6),dp(10),dp(6));setTextColor(if(primary)bg else ink)
        backgroundTintList=ColorStateList.valueOf(if(primary)accent else card);setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4);bottomMargin=dp(4)}
    }
    private fun check(label:String,checked:Boolean)=CheckBox(this).apply{text=label;textSize=13f;setTextColor(ink);isChecked=checked;buttonTintList=ColorStateList.valueOf(accent);minHeight=dp(44)}
    private fun scrollPage():LinearLayout {val scroll=ScrollView(this).apply{isFillViewport=true};val page=column().apply{setPadding(0,dp(4),0,dp(12))};scroll.addView(page);body.addView(scroll);return page}
    private fun section(page:LinearLayout,title:String,subtitle:String){page.addView(text(title,19,ink,true).apply{setPadding(0,dp(18),0,dp(7))});page.addView(text(subtitle,12,muted).apply{setPadding(0,0,0,dp(9));setLineSpacing(dp(3).toFloat(),1f)})}
    private fun spinner(page:LinearLayout,label:String,options:List<String>,selected:String):Spinner {
        page.addView(text(label,12,muted).apply{setPadding(0,dp(8),0,0)})
        val result=Spinner(this);result.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options);result.setSelection(options.indexOf(selected).coerceAtLeast(0));page.addView(result,LinearLayout.LayoutParams(-1,dp(48)));return result
    }
    private fun number(page:LinearLayout,label:String,value:Double):EditText {page.addView(text(label,12,muted).apply{setPadding(0,dp(8),0,0)});return EditText(this).apply{setSingleLine();inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;setText(value.toString());setTextColor(ink);page.addView(this,LinearLayout.LayoutParams(-1,dp(48)))} }
    private fun toast(message:String){Toast.makeText(this,message,Toast.LENGTH_LONG).show()}
}
