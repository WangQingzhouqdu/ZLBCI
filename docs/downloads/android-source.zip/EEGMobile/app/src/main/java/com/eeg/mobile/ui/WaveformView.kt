package com.eeg.mobile.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.max

class WaveformView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val emptySamples = FloatArray(0)
    private val colors = intArrayOf(0xff40dfc4.toInt(),0xff62b5ff.toInt(),0xffbc9fff.toInt(),0xffffc56b.toInt(),0xffed89b6.toInt(),0xff8ed58c.toInt(),0xff76d8eb.toInt(),0xffe4b2ff.toInt())
    var samples: Array<FloatArray> = Array(8) { FloatArray(0) }
    var visibleChannels = BooleanArray(8) { true }
    var seconds = 5.0
    var amplitude = 100.0
    var leadP = 0
    var leadN = 0
    var leadEnabled = false
    var emptyLabel = "连接设备或开启模拟，查看八通道波形"

    init { contentDescription = "八通道实时脑电波形，单位微伏" }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 43f * density
        val right = width - 12f * density
        val top = 14f * density
        val bottom = height - 27f * density
        val visible = (0..7).filter { visibleChannels[it] }
        if (visible.isEmpty() || bottom <= top || right <= left) return
        val row = (bottom - top) / visible.size
        paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        paint.textSize = 10f * density
        paint.strokeWidth = density
        for (i in 0..5) {
            val x = left + (right-left)*i/5f
            paint.color = 0xff213147.toInt()
            canvas.drawLine(x, top, x, bottom, paint)
            paint.color = 0xff8293aa.toInt()
            paint.textAlign = when(i) { 0 -> Paint.Align.LEFT; 5 -> Paint.Align.RIGHT; else -> Paint.Align.CENTER }
            val label = if(i==5) "0 s" else "−${String.format(java.util.Locale.US,if(seconds<5)"%.1f" else "%.0f", seconds*(5-i)/5)}"
            canvas.drawText(label,x,height-8f*density,paint)
        }
        visible.forEachIndexed { index, channel ->
            val cy = top + row*(index+0.5f)
            paint.color = 0xff263750.toInt()
            canvas.drawLine(left,cy,right,cy,paint)
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = 10f*density
            paint.color = if(leadEnabled && ((leadP or leadN) and (1 shl channel))!=0) 0xffff7c83.toInt() else colors[channel]
            canvas.drawText("CH${channel+1}",4f*density,cy-2f*density,paint)
            val data = samples.getOrNull(channel) ?: emptySamples
            var range = amplitude
            if(range<=0) { var peak=0.0; for(value in data)if(value.isFinite())peak=max(peak,abs(value).toDouble()); range=max(10.0,peak*1.15) }
            paint.textSize = 7f*density
            paint.color = 0xff8192aa.toInt()
            canvas.drawText(if(amplitude<=0) "自动" else "±${amplitude.toInt()}",4f*density,cy+11f*density,paint)
            if(data.size>1) {
                canvas.save()
                canvas.clipRect(left,top+row*index,right,top+row*(index+1))
                path.reset()
                var drawing=false
                data.forEachIndexed { i,v ->
                    val x = left+(right-left)*i/(data.size-1)
                    val y = cy-(v/range*row*0.42).toFloat()
                    if(v.isFinite()) { if(!drawing) path.moveTo(x,y) else path.lineTo(x,y); drawing=true } else drawing=false
                }
                paint.color=colors[channel]; paint.style=Paint.Style.STROKE; paint.strokeWidth=1.2f*density
                canvas.drawPath(path,paint)
                paint.style=Paint.Style.FILL
                canvas.restore()
            }
        }
        if(samples.all { channel -> channel.none { it.isFinite() } }) {
            paint.textAlign=Paint.Align.CENTER; paint.textSize=11f*density; paint.color=0xff9eafc4.toInt()
            canvas.drawText(emptyLabel,width/2f,height/2f,paint)
        }
    }
}
