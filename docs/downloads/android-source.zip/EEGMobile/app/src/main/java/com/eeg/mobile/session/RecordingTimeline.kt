package com.eeg.mobile.session

import kotlin.math.max

/** Device indices preserve real losses; resets and pauses anchor to the local monotonic clock. */
internal class RecordingTimeline {
    private var lastIndex: Long? = null
    private var lastCount = 0
    private var nextTime = 0.0

    fun reset() { lastIndex = null; lastCount = 0; nextTime = 0.0 }
    fun startSegment() { lastIndex = null }

    fun beginPacket(index: Long, count: Int, sampleRate: Int, arrivalElapsedSeconds: Double): Double {
        val dt = 1.0 / sampleRate
        val arrivalAnchor = max(nextTime, arrivalElapsedSeconds - count * dt)
        val previous = lastIndex
        val start = if (previous == null) arrivalAnchor else {
            val expected = (previous + lastCount) and 0xffffffffL
            val gap = (index - expected) and 0xffffffffL
            if (gap < (1L shl 28)) nextTime + gap * dt else arrivalAnchor
        }.coerceAtLeast(0.0)
        nextTime = start + count * dt
        lastIndex = index
        lastCount = count
        return start
    }
}
