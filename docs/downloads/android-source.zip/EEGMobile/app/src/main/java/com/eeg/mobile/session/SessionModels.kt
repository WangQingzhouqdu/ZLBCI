package com.eeg.mobile.session

import com.eeg.mobile.ble.BleDevice
import com.eeg.mobile.core.FilterSettings

data class DeviceSettings(
    val sampleRate: Int = 250,
    val gain: Int = 24,
    val mode: String = "NORMAL",
    val srb1: Boolean = true,
    val bias: Boolean = true,
    val leadOff: Boolean = false
)

data class SessionSnapshot(
    val connection: String = "IDLE",
    val deviceName: String = "未连接设备",
    val demo: Boolean = false,
    val connected: Boolean = false,
    val streaming: Boolean = false,
    val sampleRate: Int = 250,
    val gain: Int = 24,
    val receivedSamples: Long = 0,
    val lostSamples: Long = 0,
    val badPackets: Long = 0,
    val packetsPerSecond: Double = 0.0,
    val samplesPerSecond: Double = 0.0,
    val bytesPerSecond: Double = 0.0,
    val leadOffP: Int = 0,
    val leadOffN: Int = 0,
    val mtu: Int = 0,
    val recording: Boolean = false,
    val recordedRows: Long = 0,
    val recordingName: String = "",
    val lastMessage: String = "连接 EEG 设备，或使用演示模式",
    val deviceStatus: String = "",
    val devices: List<BleDevice> = emptyList(),
    val filterDescription: String = "",
    val settings: DeviceSettings = DeviceSettings(),
    val filterSettings: FilterSettings = FilterSettings(lowPass = 45.0, harmonics = 2)
)
