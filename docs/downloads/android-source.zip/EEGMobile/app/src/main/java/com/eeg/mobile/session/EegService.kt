package com.eeg.mobile.session

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.eeg.mobile.ble.BleClient
import com.eeg.mobile.ble.BleDevice
import com.eeg.mobile.core.EegFilter
import com.eeg.mobile.core.EegPacket
import com.eeg.mobile.core.EegProtocol
import com.eeg.mobile.core.FilterSettings
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** Acquisition, filtering and CSV writing continue independently of the Activity. */
class EegService : Service() {
    inner class LocalBinder : Binder() { val service: EegService get() = this@EegService }
    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private val filter = EegFilter()
    private val history = WaveformBuffer()
    private val random = Random()
    @Volatile private var current = SessionSnapshot()
    @Volatile var onChanged: (() -> Unit)? = null
    @Volatile private var showFiltered = true
    @Volatile private var foreground = false
    @Volatile private var destroyed = false
    @Volatile private var bound = false
    @Volatile private var bleGeneration = 0L
    private var ble: BleClient? = null
    private val queuedPackets = AtomicInteger(0)
    private val droppedPackets = AtomicLong(0)
    private val exportExecutor = Executors.newSingleThreadExecutor { task -> Thread(task, "EEG CSV export") }
    private val activeExports = AtomicInteger(0)
    private var reportedDrops = 0L
    private var notificationPending = false
    private var lastNotificationTime = 0L
    private var lastSampleIndex: Long? = null
    private var lastSampleCount = 0
    private var acceptingData = false
    private var lastReceivedAt = 0L
    private var awaitingFirstPacket = false
    private var windowSamples = 0L
    private var windowPackets = 0L
    private var windowBytes = 0L
    private var windowTime = 0L
    private var demoIndex = 0L
    private var demoSequence = 0
    private var nextDemoAt = 0L
    private var writer: BufferedWriter? = null
    private var recordingFile: File? = null
    private var recordingMode = "both"
    private var recordingStartedAt = 0L
    private val recordTimeline = RecordingTimeline()
    private var lastFlushAt = 0L

    override fun onCreate() {
        super.onCreate()
        workerThread = HandlerThread("EEG acquisition")
        workerThread.start()
        worker = Handler(workerThread.looper)
        restoreSettings()
        filter.configure(current.sampleRate, current.filterSettings)
        current = current.copy(filterDescription = filter.description)
        windowTime = SystemClock.elapsedRealtime()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "脑电采集连接", NotificationManager.IMPORTANCE_LOW)
        )
        worker.postDelayed(rateTick, 1000)
    }

    override fun onBind(intent: Intent?): IBinder { bound = true; return binder }
    override fun onRebind(intent: Intent?) { bound = true; super.onRebind(intent) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.eeg.mobile.CONNECT") ensureForeground()
        return START_NOT_STICKY
    }

    override fun onUnbind(intent: Intent?): Boolean {
        bound = false
        onChanged = null
        if (!foreground) worker.postDelayed({
            if (bound || foreground || destroyed) return@postDelayed
            if (current.demo) {
                acceptingData = false
                worker.removeCallbacks(demoTick)
                stopRecordingInternal()
                update(current.copy(streaming = false, lastMessage = "演示已在退出界面后暂停"))
            }
            if (activeExports.get() == 0) stopSelf()
        }, 1200)
        return true
    }

    override fun onDestroy() {
        destroyed = true
        onChanged = null
        ble?.close()
        exportExecutor.shutdown()
        main.removeCallbacksAndMessages(null)
        worker.removeCallbacks(demoTick)
        worker.removeCallbacks(rateTick)
        worker.post {
            stopRecordingInternal()
            workerThread.quitSafely()
        }
        super.onDestroy()
    }

    fun snapshot(): SessionSnapshot = current
    fun waveform(windowSeconds: Double, maxPoints: Int = 1200): Array<FloatArray> =
        history.snapshot((windowSeconds.coerceIn(0.1, 20.0) * current.sampleRate).toInt(), maxPoints, showFiltered)

    fun scan(onlyEeg: Boolean = true) = dispatch {
        if (current.connected || current.connection == "CONNECTING") {
            message("请先断开当前连接，再扫描设备")
        } else {
            if (ble == null) replaceBle()
            update(current.copy(devices = emptyList(), connection = "SCANNING", demo = false))
            ble?.scan(onlyEeg)
        }
    }

    fun connect(address: String) {
        if (!ensureForeground()) return
        dispatch {
            endSource()
            replaceBle()
            resetCounters()
            update(current.copy(connection = "CONNECTING", connected = false, demo = false,
                deviceName = address, deviceStatus = "", lastMessage = "正在连接 $address"))
            ble?.connect(address)
        }
    }

    fun connectDemo() = dispatch {
        endSource()
        bleGeneration++
        ble?.close()
        ble = null
        stopForegroundSafely()
        resetCounters()
        update(current.copy(connection = "CONNECTED", connected = true, demo = true,
            deviceName = "演示 · 合成信号", deviceStatus = "演示数据，不来自脑电硬件", mtu = 0,
            lastMessage = "演示设备已就绪；点击启动采集"))
    }

    fun disconnect() = dispatch {
        endSource()
        bleGeneration++
        ble?.close()
        ble = null
        update(current.copy(connection = "DISCONNECTED", connected = false, streaming = false,
            packetsPerSecond = 0.0, samplesPerSecond = 0.0, bytesPerSecond = 0.0,
            lastMessage = "已断开连接，记录文件保留在本机"))
        stopForegroundSafely()
        stopSelf()
    }

    fun startAcquisition() = dispatch {
        if (!current.connected) { message("请先连接设备"); return@dispatch }
        if (acceptingData) return@dispatch
        filter.reset()
        history.clear()
        lastSampleIndex = null
        recordTimeline.startSegment()
        acceptingData = true
        awaitingFirstPacket = true
        lastReceivedAt = SystemClock.elapsedRealtime()
        if (current.demo) {
            demoIndex = 0
            nextDemoAt = SystemClock.uptimeMillis()
            worker.post(demoTick)
            update(current.copy(streaming = true, lastMessage = demoDescription()))
        } else {
            ble?.sendCommand("START")
            update(current.copy(streaming = true, lastMessage = "启动命令已发送，等待设备数据"))
        }
    }

    fun pauseAcquisition() = dispatch {
        acceptingData = false
        worker.removeCallbacks(demoTick)
        if (current.connected && !current.demo) ble?.sendCommand("STOP")
        recordTimeline.startSegment()
        lastSampleIndex = null
        try { writer?.flush() } catch (error: Exception) {
            stopRecordingInternal()
            message("CSV 写入失败，记录已停止：${error.message}")
            update(current.copy(streaming = false))
            return@dispatch
        }
        update(current.copy(streaming = false, lastMessage = "已暂停采集"))
    }

    fun applyDeviceSettings(settings: DeviceSettings) = dispatch {
        require(settings.sampleRate in SAMPLE_RATES) { "不支持的采样率" }
        require(settings.gain in GAINS) { "不支持的增益" }
        require(settings.mode in MODES) { "不支持的输入模式" }
        if (settings == current.settings) return@dispatch
        val wasRecording = writer != null
        stopRecordingInternal()
        if (acceptingData) {
            acceptingData = false
            worker.removeCallbacks(demoTick)
            if (!current.demo) ble?.sendCommand("STOP")
        }
        lastSampleIndex = null
        history.reset(settings.sampleRate)
        filter.configure(settings.sampleRate, current.filterSettings)
        update(current.copy(settings = settings, sampleRate = settings.sampleRate, gain = settings.gain,
            streaming = false, filterDescription = filter.description,
            lastMessage = if (wasRecording) "配置已更新，原记录已保存；请重新启动采集/记录" else "配置已更新；请启动采集"))
        saveSettings()
        if (current.connected && !current.demo) sendDeviceSettings(settings)
    }

    fun applyFilterSettings(settings: FilterSettings) = dispatch {
        val wasRecording = writer != null
        stopRecordingInternal()
        filter.configure(current.sampleRate, settings)
        history.clear()
        update(current.copy(filterSettings = settings, filterDescription = filter.description,
            lastMessage = if (wasRecording) "滤波已更新；之前的记录已保存，请重新开始记录" else "滤波已更新，波形历史已清空"))
        saveSettings()
    }

    fun setDisplay(filtered: Boolean) {
        showFiltered = filtered
        getSharedPreferences("acquisition", MODE_PRIVATE).edit().putBoolean("display_filtered", filtered).apply()
        requestNotification()
    }
    fun clearDisplay() = dispatch { history.clear(); message("已清空显示历史，采集与记录继续") }

    fun startRecording(mode: String) = dispatch {
        require(mode in setOf("raw", "filt", "both")) { "记录模式必须为 raw/filt/both" }
        if (!current.connected) { message("请先连接设备后再开始记录"); return@dispatch }
        if (writer != null) return@dispatch
        val directory = File(filesDir, "recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val file = File(directory, "eeg_${if (current.demo) "demo_" else ""}$stamp.csv")
        val output = file.bufferedWriter(Charsets.UTF_8, 131072)
        try {
            val state = current
            output.appendLine("# device: ${state.deviceName.replace('\n', ' ').replace('\r', ' ')}")
            output.appendLine("# created: ${Date()}")
            output.appendLine("# demo: ${state.demo}")
            output.appendLine("# fs: ${state.sampleRate}")
            output.appendLine("# gain: ${state.gain}")
            output.appendLine("# n_channels: 8")
            output.appendLine("# input_mode: ${state.settings.mode}")
            output.appendLine("# reference: ${if (state.settings.srb1) "SRB1 common reference" else "differential"}")
            output.appendLine("# bias: ${state.settings.bias}")
            output.appendLine("# lead_off_detection: ${state.settings.leadOff}")
            output.appendLine("# filter: ${state.filterDescription}")
            output.appendLine("# columns_unit: microvolt (uV)")
            output.appendLine("# time_origin_unix_s: ${System.currentTimeMillis() / 1000.0}")
            output.appendLine("# time_s: elapsed seconds since recording start; pause/reset reanchors to monotonic arrival time")
            output.appendLine("# sample_index: unsigned 32-bit device index; may restart after START and wraps at 4294967296")
            output.appendLine("# loss: missing sample indices retain time gaps; no missing values are fabricated")
            output.append("time_s,sample_index")
            if (mode != "filt") for (i in 1..8) output.append(",raw_ch$i")
            if (mode != "raw") for (i in 1..8) output.append(",filt_ch$i")
            output.appendLine()
            output.flush()
        } catch (error: Exception) {
            output.close()
            throw error
        }
        writer = output
        recordingFile = file
        recordingMode = mode
        recordingStartedAt = SystemClock.elapsedRealtime()
        recordTimeline.reset()
        lastFlushAt = recordingStartedAt
        update(current.copy(recording = true, recordedRows = 0, recordingName = file.name,
            lastMessage = if (current.streaming) "正在记录到 ${file.name}" else "记录已准备，启动采集后写入数据"))
    }

    fun stopRecording() = dispatch {
        if (stopRecordingInternal()) {
            message(if (current.recordingName.isEmpty()) "没有正在进行的记录" else "记录已保存：${current.recordingName}")
        }
    }

    fun listRecordings(): List<File> = File(filesDir, "recordings").listFiles()
        ?.filter { it.isFile && it.extension.equals("csv", true) }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun exportRecording(uri: Uri) = dispatch {
        check(stopRecordingInternal()) { "记录文件刷新失败，导出已取消" }
        val source = recordingFile?.takeIf { it.exists() } ?: listRecordings().firstOrNull()
        requireNotNull(source) { "还没有可导出的 CSV，请先记录数据" }
        exportClosedFile(source, uri)
    }

    fun exportRecording(fileName: String, uri: Uri) = dispatch {
        require(fileName == File(fileName).name && fileName.endsWith(".csv", true)) { "记录文件名无效" }
        val directory = File(filesDir, "recordings").canonicalFile
        val source = File(directory, fileName).canonicalFile
        require(source.parentFile == directory && source.isFile) { "找不到选择的 CSV 记录" }
        if (source == recordingFile?.canonicalFile) check(stopRecordingInternal()) { "记录文件刷新失败，导出已取消" }
        exportClosedFile(source, uri)
    }

    private fun exportClosedFile(source: File, uri: Uri) {
        // Starting while the Activity is visible lets a slow document provider
        // finish even when the Activity temporarily unbinds during export.
        startService(Intent(this, EegService::class.java))
        activeExports.incrementAndGet()
        message("正在导出 ${source.name}…")
        exportExecutor.execute {
            val result = try {
                val output = contentResolver.openOutputStream(uri, "wt") ?: error("无法打开导出位置")
                output.use { destination -> source.inputStream().use { it.copyTo(destination) } }
                "CSV 已导出：${source.name}"
            } catch (error: Exception) { "CSV 导出失败：${error.message}" }
            activeExports.decrementAndGet()
            dispatch {
                message(result)
                if (!bound && !foreground && activeExports.get() == 0) stopSelf()
            }
        }
    }

    private fun dispatch(action: () -> Unit) {
        if (destroyed) return
        worker.post {
            try { action() } catch (error: Exception) {
                message("操作失败：${error.message ?: error.javaClass.simpleName}")
            }
        }
    }

    private fun update(state: SessionSnapshot) { current = state; requestNotification() }
    private fun message(text: String) = update(current.copy(lastMessage = text))

    private fun requestNotification() {
        if (destroyed) return
        main.post {
            if (!notificationPending) {
                notificationPending = true
                val delay = max(0L, 200L - (SystemClock.uptimeMillis() - lastNotificationTime))
                main.postDelayed({
                    notificationPending = false
                    lastNotificationTime = SystemClock.uptimeMillis()
                    onChanged?.invoke()
                }, delay)
            }
        }
    }

    private fun ensureForeground(): Boolean {
        if (foreground) return true
        return try {
            val intent = Intent().setClassName(packageName, "com.eeg.mobile.MainActivity")
            val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val notification = Notification.Builder(this, CHANNEL)
                .setContentTitle("EEG 脑电采集")
                .setContentText("蓝牙连接保持中 · 点击返回采集界面")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentIntent(pending).setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(NOTIFICATION_ID, notification)
            foreground = true
            true
        } catch (error: Exception) {
            dispatch { message("无法启动后台蓝牙采集：${error.message}") }
            stopSelf()
            false
        }
    }

    private fun stopForegroundSafely() {
        if (foreground) { stopForeground(STOP_FOREGROUND_REMOVE); foreground = false }
    }

    private fun replaceBle() {
        val generation = ++bleGeneration
        ble?.close()
        ble = BleClient(this, object : BleClient.Listener {
            private fun event(action: () -> Unit) = dispatch { if (generation == bleGeneration) action() }
            override fun onDevices(devices: List<BleDevice>) = event { update(current.copy(devices = devices.toList())) }
            override fun onState(state: String, message: String) = event {
                if (state == "DISCONNECTED") {
                    endSource()
                    update(current.copy(connection = state, connected = false, streaming = false, lastMessage = message))
                    stopForegroundSafely()
                    stopSelf()
                } else update(current.copy(connection = state, lastMessage = message))
            }
            override fun onReady(name: String, address: String, mtu: Int) = event {
                update(current.copy(connection = "CONNECTED", deviceName = name.ifBlank { address },
                    connected = true, demo = false, streaming = false, mtu = mtu, lastMessage = "设备已连接，请启动采集"))
                ble?.sendCommand("STOP")
                sendDeviceSettings(current.settings)
            }
            override fun onData(data: ByteArray) {
                if (generation != bleGeneration || destroyed) return
                if (queuedPackets.incrementAndGet() > MAX_QUEUED_PACKETS) {
                    queuedPackets.decrementAndGet()
                    droppedPackets.incrementAndGet()
                    return
                }
                val copied = data.copyOf()
                worker.post {
                    queuedPackets.decrementAndGet()
                    if (generation != bleGeneration || current.demo) return@post
                    try {
                        val packet = EegProtocol.parse(copied)
                        if (packet == null) update(current.copy(badPackets = current.badPackets + 1))
                        else if (acceptingData) ingest(packet)
                    } catch (error: Exception) {
                        update(current.copy(badPackets = current.badPackets + 1, lastMessage = "数据处理错误：${error.message}"))
                    }
                }
            }
            override fun onStatus(text: String) = event { receiveStatus(text) }
            override fun onError(message: String) = event { this@EegService.message(message) }
        })
    }

    private fun sendDeviceSettings(settings: DeviceSettings) {
        listOf("SR:${settings.sampleRate}", "GAIN:${settings.gain}", "MODE:${settings.mode}",
            "SRB1:${if (settings.srb1) 1 else 0}", "BIAS:${if (settings.bias) 1 else 0}",
            "LOFF:${if (settings.leadOff) 1 else 0}").forEach { ble?.sendCommand(it) }
    }

    private fun receiveStatus(text: String) {
        var state = current.copy(deviceStatus = text.take(2000))
        try {
            val status = JSONObject(text)
            // INFO and configuration acknowledgements can be queued before START.
            // Packet flags and the no-data watchdog determine acquisition state.
            state = state.copy(leadOffP = status.optInt("loffp", state.leadOffP),
                leadOffN = status.optInt("loffn", state.leadOffN), mtu = status.optInt("mtu", state.mtu))
        } catch (_: Exception) { /* Some firmware emits plain-text command acknowledgements. */ }
        update(state)
    }

    private fun endSource() {
        acceptingData = false
        awaitingFirstPacket = false
        worker.removeCallbacks(demoTick)
        stopRecordingInternal()
        lastSampleIndex = null
        filter.reset()
    }

    private fun resetCounters() {
        history.reset(current.settings.sampleRate)
        filter.configure(current.settings.sampleRate, current.filterSettings)
        demoIndex = 0
        demoSequence = 0
        lastSampleIndex = null
        windowSamples = 0; windowPackets = 0; windowBytes = 0
        windowTime = SystemClock.elapsedRealtime()
        reportedDrops = droppedPackets.get()
        update(current.copy(streaming = false, receivedSamples = 0, lostSamples = 0, badPackets = 0,
            packetsPerSecond = 0.0, samplesPerSecond = 0.0, bytesPerSecond = 0.0,
            leadOffP = 0, leadOffN = 0, sampleRate = current.settings.sampleRate,
            gain = current.settings.gain, filterDescription = filter.description))
    }

    private fun ingest(packet: EegPacket) {
        lastReceivedAt = SystemClock.elapsedRealtime()
        awaitingFirstPacket = false
        if (packet.sampleRate != current.sampleRate || packet.gain != current.gain) {
            val wasRecording = writer != null
            stopRecordingInternal()
            history.reset(packet.sampleRate)
            filter.configure(packet.sampleRate, current.filterSettings)
            lastSampleIndex = null
            update(current.copy(sampleRate = packet.sampleRate, gain = packet.gain,
                settings = current.settings.copy(sampleRate = packet.sampleRate, gain = packet.gain),
                filterDescription = filter.description,
                lastMessage = if (wasRecording) "设备采样率/增益已变化，记录已自动保存" else "已同步设备采样率/增益"))
        }
        var lost = current.lostSamples
        lastSampleIndex?.let { last ->
            val expected = (last + lastSampleCount) and INDEX_MASK
            val gap = (packet.sampleIndex - expected) and INDEX_MASK
            if (gap != 0L) {
                if (gap < (1L shl 28)) { lost += gap; history.pushGap(gap) }
                else { history.clear(); message("设备样本计数已重置；时间线重新对齐") }
                filter.reset()
            }
        }
        lastSampleIndex = packet.sampleIndex
        lastSampleCount = packet.sampleCount
        val filtered = filter.process(packet.samples)
        history.push(packet.samples, filtered)
        if (writer != null) {
            try { writeSamples(packet, filtered) } catch (error: Exception) {
                stopRecordingInternal()
                message("CSV 写入失败，记录已停止：${error.message}")
            }
        }
        windowSamples += packet.sampleCount
        windowPackets++
        windowBytes += packet.byteCount
        update(current.copy(streaming = packet.streaming, receivedSamples = current.receivedSamples + packet.sampleCount,
            lostSamples = lost, leadOffP = packet.leadOffP, leadOffN = packet.leadOffN))
        if (!packet.streaming) {
            acceptingData = false
            stopRecordingInternal()
            message("设备报告已停止采集；记录已停止，可重新启动")
        }
    }

    private fun writeSamples(packet: EegPacket, filtered: Array<FloatArray>) {
        val output = writer ?: return
        val dt = 1.0 / packet.sampleRate
        val start = recordTimeline.beginPacket(packet.sampleIndex, packet.sampleCount, packet.sampleRate,
            (SystemClock.elapsedRealtime() - recordingStartedAt) / 1000.0)
        val block = StringBuilder(packet.sampleCount * 160)
        for (i in 0 until packet.sampleCount) {
            block.append(start + i * dt).append(',').append((packet.sampleIndex + i) and INDEX_MASK)
            if (recordingMode != "filt") for (value in packet.samples[i]) block.append(',').append(value)
            if (recordingMode != "raw") for (value in filtered[i]) block.append(',').append(value)
            block.append('\n')
        }
        output.write(block.toString())
        val now = SystemClock.elapsedRealtime()
        if (now - lastFlushAt >= 1000) { output.flush(); lastFlushAt = now }
        current = current.copy(recordedRows = current.recordedRows + packet.sampleCount)
    }

    private fun stopRecordingInternal(): Boolean {
        val output = writer
        writer = null
        var failure: Exception? = null
        if (output != null) {
            try { output.flush() } catch (error: Exception) { failure = error }
            try { output.close() } catch (error: Exception) { failure = error }
        }
        if (current.recording) update(current.copy(recording = false))
        if (failure != null) message("记录停止，但文件保存失败：${failure.message}")
        return failure == null
    }

    private val rateTick = object : Runnable {
        override fun run() {
            if (destroyed) return
            val now = SystemClock.elapsedRealtime()
            val elapsed = max(1L, now - windowTime) / 1000.0
            update(current.copy(packetsPerSecond = windowPackets / elapsed,
                samplesPerSecond = windowSamples / elapsed, bytesPerSecond = windowBytes / elapsed))
            val dropped = droppedPackets.get()
            if (dropped > reportedDrops) {
                message("处理队列丢弃 ${dropped - reportedDrops} 个数据包；丢样由样本序号统计")
                reportedDrops = dropped
            }
            val timeout = if (awaitingFirstPacket) 5000L else 1500L
            if (current.connected && !current.demo && acceptingData && now - lastReceivedAt > timeout) {
                acceptingData = false
                ble?.sendCommand("STOP")
                stopRecordingInternal()
                update(current.copy(streaming = false,
                    lastMessage = "数据中断：超过 ${if (awaitingFirstPacket) "5" else "1.5"} 秒未收到有效数据，已暂停并停止记录；检查设备后重新启动"))
            }
            windowPackets = 0; windowSamples = 0; windowBytes = 0; windowTime = now
            worker.postDelayed(this, 1000)
        }
    }

    private val demoTick = object : Runnable {
        override fun run() {
            if (destroyed || !current.demo || !current.connected || !acceptingData) return
            try {
                val fs = current.sampleRate
                val count = max(1, fs / 25)
                val samples = Array(count) { i ->
                    val time = (demoIndex + i).toDouble() / fs
                    FloatArray(8) { ch ->
                        when (current.settings.mode) {
                            "SHORT" -> (random.nextGaussian() * 0.4).toFloat()
                            "TEST" -> ((if (sin(2 * PI * 0.9765625 * time) >= 0) 1875.0 else -1875.0) + random.nextGaussian() * 2).toFloat()
                            else -> (25 * sin(2 * PI * (9.5 + ch * 0.3) * time + ch * 0.5) +
                                7 * sin(2 * PI * 20 * time) + 9 * sin(2 * PI * 50 * time) +
                                15 * sin(2 * PI * 0.25 * time) + 3 * random.nextGaussian()).toFloat()
                        }
                    }
                }
                val packet = EegPacket(demoSequence, 8, count, demoIndex, 0, 0, 2,
                    current.gain, fs, samples, 14 + count * 24 + 1)
                ingest(packet)
                demoIndex = (demoIndex + count) and INDEX_MASK
                demoSequence = (demoSequence + 1) and 0xffff
                nextDemoAt += 40
                val now = SystemClock.uptimeMillis()
                if (nextDemoAt < now - 200) nextDemoAt = now + 40
                worker.postAtTime(this, max(now + 1, nextDemoAt))
            } catch (error: Exception) {
                acceptingData = false
                stopRecordingInternal()
                update(current.copy(streaming = false, lastMessage = "演示已停止：${error.message}"))
            }
        }
    }

    private fun demoDescription(): String = when (current.settings.mode) {
        "MVDD", "TEMP" -> "演示采集中 · ${current.settings.mode} 未模拟物理量，显示合成脑电（与桌面版一致）"
        "TEST" -> "演示采集中 · 合成 ±1875 µV / 0.9765625 Hz 方波"
        "SHORT" -> "演示采集中 · 合成本底噪声"
        else -> "演示采集中 · 合成脑电，不来自硬件"
    }

    private fun restoreSettings() {
        val prefs = getSharedPreferences("acquisition", MODE_PRIVATE)
        try {
            val device = DeviceSettings(
                prefs.getInt("sample_rate", 250).takeIf { it in SAMPLE_RATES } ?: 250,
                prefs.getInt("gain", 24).takeIf { it in GAINS } ?: 24,
                prefs.getString("mode", "NORMAL")?.takeIf { it in MODES } ?: "NORMAL",
                prefs.getBoolean("srb1", true), prefs.getBoolean("bias", true), prefs.getBoolean("lead_off", false))
            val filters = FilterSettings(prefs.getBoolean("filter_enabled", true),
                prefs.getString("high_pass", "0.5")!!.toDouble(), prefs.getString("low_pass", "45.0")!!.toDouble(),
                prefs.getInt("filter_order", 4), prefs.getInt("notch_hz", 50), prefs.getInt("harmonics", 2),
                prefs.getString("notch_q", "30.0")!!.toDouble())
            filter.configure(device.sampleRate, filters)
            current = current.copy(settings = device, sampleRate = device.sampleRate, gain = device.gain,
                filterSettings = filters, filterDescription = filter.description)
            history.reset(device.sampleRate)
            showFiltered = prefs.getBoolean("display_filtered", true)
        } catch (_: Exception) { current = SessionSnapshot() }
    }

    private fun saveSettings() {
        val device = current.settings
        val filters = current.filterSettings
        getSharedPreferences("acquisition", MODE_PRIVATE).edit()
            .putInt("sample_rate", device.sampleRate).putInt("gain", device.gain).putString("mode", device.mode)
            .putBoolean("srb1", device.srb1).putBoolean("bias", device.bias).putBoolean("lead_off", device.leadOff)
            .putBoolean("filter_enabled", filters.enabled).putString("high_pass", filters.highPass.toString())
            .putString("low_pass", filters.lowPass.toString()).putInt("filter_order", filters.order)
            .putInt("notch_hz", filters.notchHz).putInt("harmonics", filters.harmonics)
            .putString("notch_q", filters.notchQ.toString()).apply()
    }

    companion object {
        private const val CHANNEL = "eeg_acquisition"
        private const val NOTIFICATION_ID = 101
        private const val MAX_QUEUED_PACKETS = 256
        private const val INDEX_MASK = 0xffffffffL
        private val SAMPLE_RATES = setOf(250, 500, 1000, 2000, 4000, 8000, 16000)
        private val GAINS = setOf(1, 2, 4, 6, 8, 12, 24)
        private val MODES = setOf("NORMAL", "SHORT", "TEST", "MVDD", "TEMP")
    }
}
