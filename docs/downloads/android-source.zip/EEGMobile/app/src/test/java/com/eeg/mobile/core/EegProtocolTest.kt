package com.eeg.mobile.core

import org.junit.Assert.*
import org.junit.Test

class EegProtocolTest {
    @Test fun crcStandardVectorAndBounds() {
        assertEquals(0xf4, EegProtocol.crc8("123456789".toByteArray()))
        assertEquals(0, EegProtocol.crc8(byteArrayOf()))
        assertEquals(0xf4, EegProtocol.crc8("123456789extra".toByteArray(), 9))
        try { EegProtocol.crc8(byteArrayOf(1), 2); fail("Out-of-buffer CRC accepted") }
        catch (_: IllegalArgumentException) { }
    }

    @Test fun signed24BitUnsignedCountersFlagsAndScaling() {
        val data = packet(seq = 65535, index = 0xffffffffL, flags = 0x63, gainCode = 6,
            values = intArrayOf(-8388608, -1, 0, 1, 8388607, 123456, -654321, 0))
        val packet = requireNotNull(EegProtocol.parse(data))
        assertEquals(65535, packet.seq)
        assertEquals(0xffffffffL, packet.sampleIndex)
        assertEquals(8, packet.channelCount)
        assertEquals(1, packet.sampleCount)
        assertEquals(24, packet.gain)
        assertEquals(16000, packet.sampleRate)
        assertEquals(0x81, packet.leadOffP)
        assertEquals(0x42, packet.leadOffN)
        assertTrue(packet.streaming)
        assertTrue(packet.overflow)
        assertEquals(39, packet.byteCount)
        assertArrayEquals(floatArrayOf(-187500f, -0.022351742f, 0f, 0.022351742f,
            187499.98f, 2759.4566f, -14625.214f, 0f), packet.samples[0], 0.003f)
        val wrapped = requireNotNull(EegProtocol.parse(packet(seq = 0, index = 0)))
        assertEquals(1, (wrapped.seq - packet.seq) and 0xffff)
        assertEquals(1L, (wrapped.sampleIndex - packet.sampleIndex) and 0xffffffffL)
    }

    @Test fun everyGainAndSampleRateCodeMatchesDesktop() {
        for (code in 0..7) {
            val decoded = requireNotNull(EegProtocol.parse(packet(gainCode = code)))
            assertEquals(intArrayOf(1, 2, 4, 6, 8, 12, 24, 24)[code], decoded.gain)
        }
        for (code in 0..15) {
            val decoded = requireNotNull(EegProtocol.parse(packet(flags = code shl 4)))
            assertEquals(intArrayOf(250, 500, 1000, 2000, 4000, 8000, 16000).getOrElse(code) { 250 }, decoded.sampleRate)
        }
    }

    @Test fun malformedNotificationsAreRejectedAndSamplesStaySampleMajor() {
        val full = packet(values = IntArray(24) { it - 10 })
        for (length in 0 until full.size) assertNull("length=$length", EegProtocol.parse(full.copyOf(length)))
        assertNull(EegProtocol.parse(full.copyOf().apply { this[0] = 0 }))
        assertNull(EegProtocol.parse(full.copyOf().apply { this[4] = 7 }))
        assertNull(EegProtocol.parse(full.copyOf().apply { this[5] = 0 }))
        assertNull(EegProtocol.parse(full.copyOf().apply { this[20] = (this[20].toInt() xor 1).toByte() }))
        assertNull(EegProtocol.parse(full.copyOf().apply { this[lastIndex] = (this[lastIndex].toInt() xor 1).toByte() }))
        val decoded = requireNotNull(EegProtocol.parse(full + byteArrayOf(99, 100)))
        assertEquals(3, decoded.samples.size)
        assertEquals(full.size, decoded.byteCount)
        assertEquals(0f, decoded.samples[1][2], 0f)
        assertTrue(decoded.samples[2][7] > decoded.samples[0][0])
    }

    @Test fun unsignedSampleCountSupportsFullByteRange() {
        for (count in intArrayOf(127, 128, 255)) {
            val bytes = packet(values = IntArray(count * 8) { it - 1000 })
            val decoded = requireNotNull(EegProtocol.parse(bytes))
            assertEquals(count, decoded.sampleCount)
            assertEquals(count, decoded.samples.size)
            assertEquals(15 + count * 24, decoded.byteCount)
            assertTrue(decoded.samples.last().last() > decoded.samples.first().first())
            assertNull(EegProtocol.parse(bytes.copyOf(bytes.size - 1)))
        }
    }

    /** Fixture encoder uses a bitwise CRC independent of production's table. */
    private fun packet(seq: Int = 12, index: Long = 42, flags: Int = 2, gainCode: Int = 6,
                       values: IntArray = IntArray(8)): ByteArray {
        val bytes = ByteArray(15 + values.size * 3)
        bytes[0] = 0xa5.toByte(); bytes[1] = 0x5a
        bytes[2] = seq.toByte(); bytes[3] = (seq ushr 8).toByte()
        bytes[4] = 8; bytes[5] = (values.size / 8).toByte()
        for (i in 0..3) bytes[6 + i] = (index ushr (8 * i)).toByte()
        bytes[10] = 0x81.toByte(); bytes[11] = 0x42
        bytes[12] = flags.toByte(); bytes[13] = gainCode.toByte()
        for ((i, value) in values.withIndex()) {
            bytes[14 + i * 3] = (value shr 16).toByte()
            bytes[15 + i * 3] = (value shr 8).toByte()
            bytes[16 + i * 3] = value.toByte()
        }
        var crc = 0
        for (b in bytes.dropLast(1)) {
            crc = crc xor (b.toInt() and 255)
            repeat(8) { crc = if (crc and 128 != 0) ((crc shl 1) xor 7) and 255 else (crc shl 1) and 255 }
        }
        bytes[bytes.lastIndex] = crc.toByte()
        return bytes
    }
}
