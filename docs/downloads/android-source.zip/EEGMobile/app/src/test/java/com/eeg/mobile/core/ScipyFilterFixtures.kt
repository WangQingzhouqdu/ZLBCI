package com.eeg.mobile.core

// Generated independently with SciPy 1.15.3; values include desktop float32 input/output.
internal object ScipyFilterFixtures {
    data class Case(val name: String, val fs: Int, val settings: FilterSettings, val expected: FloatArray)
    val indices = intArrayOf(0, 1, 2, 3, 4, 7, 10, 20, 30, 63, 100, 127, 200, 255, 511, 1000, 2047, 4095)
    val cases = listOf(
        Case("default", 250, FilterSettings(highPass = 0.5, lowPass = 40.0, order = 4, notchHz = 50, harmonics = 3), floatArrayOf(-3.49132279e-10f, 0.328415781f, 1.91997266f, 5.13904333f, 8.74799252f, 19.5039482f, 24.7702713f, -38.4175034f, 20.5058784f, 11.4949694f, -13.8503561f, 2.66393948f, -15.5395184f, 23.0081139f, 27.5837727f, -16.6124363f, -33.929348f, -33.7168808f)),
        Case("highpass", 500, FilterSettings(highPass = 1.0, lowPass = 0.0, order = 6, notchHz = 60, harmonics = 3), floatArrayOf(-9.02673492e-11f, 12.0936918f, 14.1307325f, 9.32774448f, 4.50947094f, 11.2667055f, 20.6192455f, -6.98185587f, -40.8031006f, 39.4629745f, 17.9762707f, -25.9795074f, 11.8008022f, 27.5628738f, 45.6672478f, 12.150919f, -8.67974949f, -8.46652603f)),
        Case("lowpass_odd", 250, FilterSettings(highPass = 0.0, lowPass = 30.0, order = 3, notchHz = 0, harmonics = 1), floatArrayOf(757.0f, 757.455505f, 759.234985f, 762.208679f, 765.358521f, 778.354797f, 784.891052f, 717.966064f, 770.27124f, 767.407715f, 729.200134f, 743.563721f, 729.200134f, 770.270752f, 779.012573f, 729.200134f, 713.598389f, 717.947571f)),
        Case("bandpass_odd", 1000, FilterSettings(highPass = 1.0, lowPass = 120.0, order = 3, notchHz = 60, harmonics = 3), floatArrayOf(-4.88853402e-12f, 0.209779888f, 1.29915988f, 3.87361407f, 7.62023783f, 14.2930365f, 7.55870771f, 16.2805805f, 23.517725f, -37.7747879f, -13.8483267f, 42.2683983f, -9.60389519f, -12.7540283f, 27.0925655f, -12.0109968f, 19.2077827f, -13.8998575f)),
        Case("narrow_high_rate", 16000, FilterSettings(highPass = 0.5, lowPass = 40.0, order = 8, notchHz = 50, harmonics = 3), floatArrayOf(-4.73303544e-07f, -4.73010942e-07f, -4.7271979e-07f, -4.72430088e-07f, -4.72141807e-07f, -4.71284778e-07f, -4.70433434e-07f, -4.65401484e-07f, -3.89253898e-07f, 4.13798662e-05f, 0.00178737997f, 0.0112726884f, 0.270114064f, 1.13159776f, 11.9549828f, -2.94695449f, 20.6710739f, 25.3150406f)),
        Case("notch_only", 500, FilterSettings(highPass = 0.0, lowPass = 0.0, order = 4, notchHz = 50, harmonics = 4), floatArrayOf(757.0f, 769.039001f, 772.00415f, 767.902893f, 763.4776f, 771.553711f, 785.492859f, 765.508484f, 724.374512f, 784.304443f, 756.212097f, 739.199829f, 756.289673f, 764.570496f, 781.229309f, 756.371033f, 732.211914f, 723.252197f)),
    )
}
