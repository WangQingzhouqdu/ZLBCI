package com.eeg.mobile.session

import org.junit.Assert.*
import org.junit.Test

class SessionDataTest {
    @Test fun displayRetainsPeaksAndValleysWhenDecimating() {
        val ring = WaveformBuffer()
        val values = Array(100) { FloatArray(8) }
        values[12][0] = 200f
        values[16][0] = -150f
        val filtered = Array(100) { FloatArray(8) { 3f } }
        ring.push(values, filtered)
        val display = ring.snapshot(100, 8, false)
        assertEquals(8, display[0].size)
        assertTrue(display[0].any { it == 200f })
        assertTrue(display[0].any { it == -150f })
        assertTrue(ring.snapshot(100, 8, true)[0].all { it == 3f })
    }

    @Test fun displayWrapKeepsNewestSamplesInChronologicalOrder() {
        val ring = WaveformBuffer()
        ring.reset(250)
        val values = Array(5500) { i -> FloatArray(8) { i.toFloat() } }
        ring.push(values, values)
        assertArrayEquals(floatArrayOf(5497f, 5498f, 5499f), ring.snapshot(3, 20, false)[0], 0f)
        assertEquals(5000, ring.snapshot(9000, 10000, false)[0].size)
        assertEquals(500f, ring.snapshot(9000, 10000, false)[0].first(), 0f)
        ring.clear()
        assertTrue(ring.snapshot(30, 20, false)[0].all { it.isNaN() })
    }

    @Test fun missingHistoryAndDeviceGapsRemainBlankOnTheCorrectTimeAxis() {
        val ring = WaveformBuffer()
        val values = Array(100) { FloatArray(8) { 5f } }
        ring.push(values, values)
        val window = ring.snapshot(1000, 2000, false)[0]
        assertEquals(1000, window.size)
        assertTrue(window.take(900).all { it.isNaN() })
        assertTrue(window.drop(900).all { it == 5f })
        ring.pushGap(20)
        ring.push(Array(1) { FloatArray(8) { 8f } }, Array(1) { FloatArray(8) { 8f } })
        val latest = ring.snapshot(22, 100, false)[0]
        assertEquals(5f, latest.first(), 0f)
        assertTrue(latest.slice(1..20).all { it.isNaN() })
        assertEquals(8f, latest.last(), 0f)
        ring.pushGap(100000000L)
        assertTrue(ring.snapshot(5000, 1200, true)[0].all { it.isNaN() })
    }

    @Test fun timestampsPreserveLossAndUnsignedWrap() {
        val timeline = RecordingTimeline()
        assertEquals(0.0, timeline.beginPacket(0xfffffffcL, 4, 250, 0.016), 1e-9)
        assertEquals(0.016, timeline.beginPacket(0, 4, 250, 0.04), 1e-9)
        // Indices4..8 were lost: the next row keeps the real5-sample time gap.
        assertEquals(0.052, timeline.beginPacket(9, 4, 250, 0.09), 1e-9)
    }

    @Test fun pauseAndDeviceResetNeverCreateMultiDayTimestampJumps() {
        val timeline = RecordingTimeline()
        timeline.beginPacket(800, 10, 250, 0.04)
        assertEquals(0.96, timeline.beginPacket(0, 10, 250, 1.0), 1e-9)
        timeline.startSegment()
        assertEquals(9.96, timeline.beginPacket(0, 10, 250, 10.0), 1e-9)
        // Early notification cannot make a resumed block overlap previous rows.
        timeline.startSegment()
        assertEquals(10.0, timeline.beginPacket(0, 10, 250, 9.0), 1e-9)
    }
}
