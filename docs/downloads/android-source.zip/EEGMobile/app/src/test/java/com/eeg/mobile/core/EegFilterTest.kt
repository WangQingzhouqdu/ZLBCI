package com.eeg.mobile.core

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class EegFilterTest {
    @Test fun matchesDesktopScipyGoldenVectors() {
        for (fixture in ScipyFilterFixtures.cases) {
            val filter = EegFilter()
            filter.configure(fixture.fs, fixture.settings)
            val input = signal(fixture.fs, 4096)
            val output = filter.process(input)
            for ((j, index) in ScipyFilterFixtures.indices.withIndex()) {
                assertEquals("${fixture.name} sample $index", fixture.expected[j], output[index][0], 0.003f)
            }
            assertTrue("${fixture.name} non-finite sample", output.all { it[0].isFinite() })
        }
    }

    @Test fun chunkingDoesNotChangeOutputAndResetRestoresStartup() {
        val input = signal(250, 1500)
        val whole = EegFilter().process(input)
        val streaming = EegFilter()
        val chunkSizes = intArrayOf(1, 7, 40, 251, 13, 1, 511, 676)
        var offset = 0
        for (size in chunkSizes) {
            val output = streaming.process(input.copyOfRange(offset, offset + size))
            output.forEachIndexed { i, sample -> assertArrayEquals(whole[offset + i], sample, 0f) }
            offset += size
        }
        assertEquals(input.size, offset)
        streaming.reset()
        assertArrayEquals(whole[0], streaming.process(arrayOf(input[0]))[0], 0f)
    }

    @Test fun steadyStateInitializationRemovesLargeDcOnAllEightChannels() {
        val input = Array(1000) { FloatArray(8) { channel -> (channel - 4) * 100000f } }
        val output = EegFilter().process(input)
        assertTrue(output.all { row -> row.all { abs(it) < .01f } })
        val filter = EegFilter()
        filter.configure(250, FilterSettings(highPass = 0.0, lowPass = 30.0, notchHz = 0))
        val dc = filter.process(input)
        for (i in input.indices) assertArrayEquals(input[i], dc[i], .01f)
    }

    @Test fun responsePassesAlphaAndRejectsMainsAndHighFrequencies() {
        fun gain(hz: Double): Double {
            val filter = EegFilter()
            val input = Array(6000) { floatArrayOf(sin(2 * PI * hz * it / 250).toFloat()) }
            val output = filter.process(input)
            val power = output.drop(3000).sumOf { it[0].toDouble().pow(2) }
            return sqrt(2 * power / 3000)
        }
        assertTrue(gain(10.0) in .98..1.02)
        assertTrue(gain(50.0) < .001)
        assertTrue(gain(100.0) < .001)
        assertTrue(gain(.05) < .01)
    }

    @Test fun disabledFilterCopiesRawSamplesAndNonFiniteInputDoesNotPoisonChannel() {
        val filter = EegFilter()
        filter.configure(250, FilterSettings(enabled = false))
        val input = arrayOf(floatArrayOf(42f))
        val result = filter.process(input)
        assertArrayEquals(input[0], result[0], 0f)
        result[0][0] = 99f
        assertEquals(42f, input[0][0], 0f)
        assertTrue(filter.process(emptyArray()).isEmpty())
        filter.configure(250, FilterSettings())
        val recovered = filter.process(arrayOf(floatArrayOf(Float.NaN), floatArrayOf(1000f), floatArrayOf(1001f)))
        assertTrue(recovered[0][0].isNaN())
        assertEquals(0f, recovered[1][0], .001f)
        assertTrue(recovered[2][0].isFinite())
    }

    private fun signal(fs: Int, count: Int) = Array(count) { i ->
        val t = i.toDouble() / fs
        floatArrayOf((750 + 35 * sin(2 * PI * 10 * t) + 12 * sin(2 * PI * 50 * t) +
            7 * cos(2 * PI * 60 * t) + 4 * sin(2 * PI * 100 * t)).toFloat())
    }
}
